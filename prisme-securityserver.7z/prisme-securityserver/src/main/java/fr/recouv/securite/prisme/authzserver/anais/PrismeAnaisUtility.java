package fr.recouv.securite.prisme.authzserver.anais;

/**
 * PrismeAnaisUtility.
 */
public class PrismeAnaisUtility {

	/**
	 * Extrait un code Application depuis un CN ou un ClientId.
	 * 
	 * @param entry String
	 * @return String codeApplication
	 */
	public final static String extractCodeApplication(String entry) {
		if (entry == null || "".equals(entry)) {
			return "";
		}
		final int posDebCn = entry.indexOf("cn=");
		if (posDebCn != -1) {
			entry = entry.substring(posDebCn + 3, entry.indexOf(","));
		}
		return entry.replace("USR_READ_NAT_APP_", "");
	}

	/**
	 * Construit un CN complet depuis un code Application.
	 * 
	 * @param codeApplication
	 *            String
	 * @return String CN complet
	 */
	public final static String constructCN(String codeApplication) {
		if (codeApplication == null || "".equals(codeApplication)) {
			return "";
		}
		StringBuffer sb = new StringBuffer();
		sb.append("cn=USR_READ_NAT_APP_").append(codeApplication)
				.append(",ou=").append(codeApplication)
				.append(",ou=Applications,ou=Technique,dc=recouv");
		return sb.toString();
	}
}
