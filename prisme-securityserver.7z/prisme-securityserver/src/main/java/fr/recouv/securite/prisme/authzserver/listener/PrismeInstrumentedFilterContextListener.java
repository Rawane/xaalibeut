/**
 * 
 */
package fr.recouv.securite.prisme.authzserver.listener;


/**
 * @author CER4495267
 *
 */

public class PrismeInstrumentedFilterContextListener {/*extends InstrumentedFilterContextListener {

    public static final MetricRegistry METRIC_REGISTRY = new MetricRegistry();

    @Override
    protected MetricRegistry getMetricRegistry() {
        return METRIC_REGISTRY;
    }*/

}
