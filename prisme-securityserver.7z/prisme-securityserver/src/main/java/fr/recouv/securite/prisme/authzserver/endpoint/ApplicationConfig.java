package fr.recouv.securite.prisme.authzserver.endpoint;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

import com.codahale.metrics.jersey2.InstrumentedResourceMethodApplicationListener;

import fr.recouv.securite.prisme.authzserver.listener.PrismeMetricsServletContextListener;

@ApplicationPath("endpoint")
public class ApplicationConfig extends ResourceConfig {

	public ApplicationConfig() {
		packages("fr.recouv.securite.prisme.authzserver.endpoint");
		 register(new InstrumentedResourceMethodApplicationListener(
				PrismeMetricsServletContextListener.METRIC_REGISTRY));

	}
}
