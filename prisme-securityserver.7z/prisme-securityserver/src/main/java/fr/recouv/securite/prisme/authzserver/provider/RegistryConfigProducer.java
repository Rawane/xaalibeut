package fr.recouv.securite.prisme.authzserver.provider;

import java.security.interfaces.RSAPublicKey;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAuthenticator;
import fr.recouv.securite.prisme.authzserver.request.PrismeRegistryRequest;
import fr.recouv.securite.prisme.authzserver.response.PrismeRegistryServerResponse;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.config.bean.Config;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.response.PrismeResponse;
import fr.recouv.securite.prisme.commun.message.types.PrismeRegistryType;
import fr.recouv.securite.prisme.commun.security.service.JWTTokenService;
import fr.recouv.securite.prisme.logger.PrismeLogger;

public class RegistryConfigProducer implements PrismeRegistryServerProvider {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			RegistryConfigProducer.class).build();

	private PrismeRegistryRequest registryRequest;

	public RegistryConfigProducer(PrismeRegistryRequest registryRequest) {
		this.registryRequest = registryRequest;
	}

	@Override
	public PrismeResponse compose() throws PrismeSystemException {

		Config config = new Config();
		config.nodeId = this.registryRequest
				.getParam(PrismeParams.REGISTRY.NODE_ID);
		config.client_id = this.registryRequest
				.getParam(PrismeParams.REGISTRY.CLIENT_ID);
		config.version = this.registryRequest
				.getParam(PrismeParams.REGISTRY.NODE_VERSION);

		config.authenticator = this.registryRequest
				.getParam(PrismeParams.REGISTRY.AUTHENTICATOR);
		config.authorizer = this.registryRequest
				.getParam(PrismeParams.REGISTRY.AUTHORIZER);
		config.authz_endpoint = this.registryRequest
				.getParam(PrismeParams.REGISTRY.AUTHZ_ENDPOINT);

		config.http_client = this.registryRequest
				.getParam(PrismeParams.REGISTRY.HTTP_CLIENT);
		config.identity_store = this.registryRequest
				.getParam(PrismeParams.REGISTRY.IDENTITY_STORE);
		config.jmx_activated = this.registryRequest
				.getParam(PrismeParams.REGISTRY.JMX_ACTIVATED);

		config.permissions_store = this.registryRequest
				.getParam(PrismeParams.REGISTRY.PERMISSIONS_STORE);

		config.populate_endpoint = this.registryRequest
				.getParam(PrismeParams.REGISTRY.POPULATE_ENDPOINT);
		config.provider_permissions_loader = this.registryRequest
				.getParam(PrismeParams.REGISTRY.PROVIDER_LOADER);

		config.registry_endpoint = this.registryRequest
				.getParam(PrismeParams.REGISTRY.REGISTRY_ENDPOINT);
		config.security_options = this.registryRequest
				.getParam(PrismeParams.REGISTRY.SECURITY_OPTIONS);
		config.token_endpoint = this.registryRequest
				.getParam(PrismeParams.REGISTRY.TOKEN_ENDPOINT);

		config.token_store = this.registryRequest
				.getParam(PrismeParams.REGISTRY.TOKEN_STORE);

		config.registry_date = new Date();
		config.pss_nodeId = PrismeContexteDescriptor.nodeId();

		// Authentification Client_id + Client_secret sur Anais
		PrismeAnaisAuthenticator.authenticateClient(
				this.registryRequest.getParam(PrismeParams.CLIENT_ID),
				this.registryRequest.getParam(PrismeParams.CLIENT_SECRET));

		// Recuperer Cle Public PSS
		String publicKeyPSS = "invalid_public_key_pss";
		if (PrismeContexteDescriptor.getPublicKeyFile() != null) {
			try {
				publicKeyPSS = JWTTokenService
						.getPublicKey(PrismeContexteDescriptor
								.getPublicKeyFile());
			} catch (PrismeInvalidTokenException e) {
				_logger.error("Erreur dans la recuperation de la PublicKey PSS : " + e.getMessage(), e);
				throw new PrismeSystemException(ExceptionCode.SECURITY,
						"Erreur dans la recuperation de la PublicKey PSS : " + e.getMessage());
			}
		}

		// Recuperer Cle Public Client
		String publicKeyClientOnPSS = "ok";
		try {
			if (!"invalid_public_key".equals(this.registryRequest
					.getParam(PrismeParams.REGISTRY.PUBLIC_KEY_CLIENT))) {
				RSAPublicKey publicKeyClient = JWTTokenService
						.getPublicKey(this.registryRequest
								.getParam(PrismeParams.REGISTRY.PUBLIC_KEY_CLIENT));
				// Enregistrer Cle Public dans KeyStore
				PrismeContexteDescriptor.getKeyStore().put(
						config.client_id, publicKeyClient);
			}
		} catch (PrismeInvalidTokenException e) {
			_logger.error("Erreur dans enregistrement de la PublicKey Client : " + e.getMessage(), e);
			publicKeyClientOnPSS = "Exception " + e.getMessage();
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur dans enregistrement de la PublicKey Client : " + e.getMessage());
		}

		// Enregistrement config
		try {
			PrismeSecurityServer.registryStore().add(config.nodeId, config);
		} catch (PrismeException e) {
			_logger.error("Erreur dans enregistrement de la configuration : " + e.getMessage(), e);
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur dans enregistrement de la configuration : " + e.getMessage());
		}

		// Envoi reponse OK
		PrismeResponse response = PrismeRegistryServerResponse
				.response(HttpServletResponse.SC_OK)
				.setParam(PrismeParams.REGISTRY.TYPE,
						PrismeRegistryType.CONFIG.toString())
				.setParam(PrismeParams.REGISTRY.PUBLIC_KEY_PSS,
						publicKeyPSS)
				.setParam(PrismeParams.REGISTRY.PUBLIC_KEY_CLIENT_ON_PSS,
						publicKeyClientOnPSS)
				.buildJSONMessage();
		return response;
	}
}
