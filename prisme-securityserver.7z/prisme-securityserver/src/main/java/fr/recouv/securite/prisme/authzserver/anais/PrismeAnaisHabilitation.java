package fr.recouv.securite.prisme.authzserver.anais;

import java.util.List;

import javax.naming.NamingException;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisAppKeyPrisme;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.api.anais.api.source.model.primary.HawaiOldTechnicalSupportAccessRightInstance;
import fr.recouv.securite.prisme.authzserver.bo.Application;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisHabilitation : <br>
 * Fournit les methodes pour lister les habilitations sur applications et le
 * detail des applications.
 */
public class PrismeAnaisHabilitation {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisHabilitation.class).build();

	private static String CONTEXT_NAME = "reader";

	/**
	 * Liste les Habilitations sur Application suivant AnaisUser.
	 * 
	 * @param anaisUser
	 *            AnaisUser
	 * @return List HawaiOldTechnicalSupportAccessRightInstance
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static List<HawaiOldTechnicalSupportAccessRightInstance> listeHabilitationsSurApplication(
			final AnaisUser anaisUser) throws PrismeSystemException {
		LOGGER.debug(">>> Liste Habilitations sur Application, userId:"
				+ anaisUser.getUid().value());
		try {
			// Recuperation List Habilitations
			final List<HawaiOldTechnicalSupportAccessRightInstance> list = HawaiOldTechnicalSupportAccessRightInstance.build
					.getList(CONTEXT_NAME).by(anaisUser).execute();
			// Retour List Habilitations
			return list;
		} catch (AnaisExceptionFailure e) {
			LOGGER.error("Exception AnaisExceptionFailure : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la récupération des habilitations sur applications.");
		} catch (AnaisExceptionServerCommunication e) {
			LOGGER.error("Exception AnaisExceptionServerCommunication : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la récupération des habilitations sur applications.");
		} catch (NamingException e) {
			LOGGER.error("Exception NamingException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la récupération des habilitations sur applications.");
		}
	}

	/**
	 * Recupere le TechnicalAccount d'une Habilitation sur Application.
	 * 
	 * @param cn
	 *            String
	 * @return AnaisTechnicalAccount
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static AnaisTechnicalAccount getTechnicalAccount(final String cn)
			throws PrismeSystemException {
		LOGGER.debug(">>> Detail Application, cn:" + cn);
		try {
			// Recuperation TechnicalAccount par dn
			AnaisTechnicalAccount technicalAccount = PrismeAnaisTechnicalAccount
					.byDN(Application.resolveDN(cn));
			if (technicalAccount == null) {
				final HawaiOldTechnicalSupportAccessRightInstance ari = HawaiOldTechnicalSupportAccessRightInstance.build
						.get(CONTEXT_NAME).by(AnaisCN.set(cn)).execute();
				if (ari != null && ari.getRdn() != null) {
					// Recuperation TechnicalAccount par rdn hawai
					technicalAccount = PrismeAnaisTechnicalAccount
							.byAnaisDescription(ari.getRdn().value());
				}
			}
			// Retour TechnicalAccount
			return technicalAccount;
		} catch (AnaisExceptionFailure e) {
			LOGGER.error("Exception AnaisExceptionFailure : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la récupération du detail de l'application.");
		} catch (AnaisExceptionServerCommunication e) {
			LOGGER.error("Exception AnaisExceptionServerCommunication : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la récupération du detail de l'application.");
		} catch (NamingException e) {
			LOGGER.error("Exception NamingException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la récupération du detail de l'application.");
		} catch (PrismeSystemException e) {
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la détermination du DN pour l'application.");
		}
	}

	/**
	 * Sauvegarde la cle publique d'un TechnicalAccount.
	 * 
	 * @param technicalAccount
	 *            AnaisTechnicalAccount
	 * @param publicKey
	 *            String
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static void saveTechnicalAccount(
			final AnaisTechnicalAccount technicalAccount, final String publicKey)
			throws PrismeSystemException {
		LOGGER.debug(">>> Save Application, dn:"
				+ technicalAccount.getRdn().value());
		try {
			// Enregistrement cle Publique
			technicalAccount.setKeyPrisme(AnaisAppKeyPrisme.set(publicKey));
			PrismeAnaisTechnicalAccount.save(technicalAccount);
		} catch (AnaisExceptionFailure e) {
			LOGGER.error("Exception AnaisExceptionFailure : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de l'enregistrement de la clé publique de l'application.");
		} catch (AnaisExceptionServerCommunication e) {
			LOGGER.error("Exception AnaisExceptionServerCommunication : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de l'enregistrement de la clé publique de l'application.");
		} catch (NamingException e) {
			LOGGER.error("Exception NamingException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de l'enregistrement de la clé publique de l'application.");
		}
	}
}
