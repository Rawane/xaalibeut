package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * FormDeEnCryptor.
 */
public class FormDeEnCryptor implements Serializable {

	/** serialVersionUID. */
	private static final long serialVersionUID = -5770743248493252828L;

	// decrypt
	@JsonProperty
	private String accessTokenValue;

	// encrypt
	@JsonProperty
	private String jwtid;

	@JsonProperty
	private String idStore;

	@JsonProperty
	private String issuer;

	@JsonProperty
	private String subject;

	@JsonProperty
	private String scope;

	@JsonProperty
	private String issueTime;

	@JsonProperty
	private String expirationTime;

	/**
	 * Constructeur simple.
	 */
	public FormDeEnCryptor() {
		// Constructeur simple
	}

	/**
	 * @return the accessTokenValue
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getAccessTokenValue() {
		return this.accessTokenValue;
	}

	/**
	 * @param accessTokenValue
	 *            the accessTokenValue to set
	 */
	public final void setAccessTokenValue(String accessTokenValue) {
		this.accessTokenValue = accessTokenValue;
	}

	/**
	 * @return the jwtid
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getJwtid() {
		return this.jwtid;
	}

	/**
	 * @param jwtid
	 *            the jwtid to set
	 */
	public final void setJwtid(String jwtid) {
		this.jwtid = jwtid;
	}

	/**
	 * @return the idStore
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getIdStore() {
		return this.idStore;
	}

	/**
	 * @param idStore
	 *            the idStore to set
	 */
	public final void setIdStore(String idStore) {
		this.idStore = idStore;
	}

	/**
	 * @return the issuer
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getIssuer() {
		return this.issuer;
	}

	/**
	 * @param issuer
	 *            the issuer to set
	 */
	public final void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	/**
	 * @return the subject
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getSubject() {
		return this.subject;
	}

	/**
	 * @param subject
	 *            the subject to set
	 */
	public final void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the scope
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getScope() {
		return this.scope;
	}

	/**
	 * @param scope
	 *            the scope to set
	 */
	public final void setScope(String scope) {
		this.scope = scope;
	}

	/**
	 * @return the issueTime
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getIssueTime() {
		return this.issueTime;
	}

	/**
	 * @param issueTime
	 *            the issueTime to set
	 */
	public final void setIssueTime(String issueTime) {
		this.issueTime = issueTime;
	}

	/**
	 * @return the expirationTime
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getExpirationTime() {
		return this.expirationTime;
	}

	/**
	 * @param expirationTime
	 *            the expirationTime to set
	 */
	public final void setExpirationTime(String expirationTime) {
		this.expirationTime = expirationTime;
	}
}
