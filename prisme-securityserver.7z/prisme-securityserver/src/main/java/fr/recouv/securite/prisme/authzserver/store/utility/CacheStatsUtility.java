package fr.recouv.securite.prisme.authzserver.store.utility;

import net.minidev.json.JSONObject;

import org.infinispan.Cache;
import org.infinispan.lifecycle.ComponentStatus;
import org.infinispan.stats.Stats;

import com.google.common.cache.CacheStats;
import com.google.common.cache.LoadingCache;

/**
 * Generation Stats des Caches format JSON.
 */
public class CacheStatsUtility {

	/**
	 * getStatsFromGuavaCache.
	 * 
	 * @param cache
	 *            LoadingCache
	 * @param expireAfterWrite
	 *            long
	 * @return String
	 */
	public static String getStatsFromGuavaCache(LoadingCache<?, ?> cache,
			long expireAfterWrite) {
		JSONObject response = new JSONObject();
		if (cache != null) {
			CacheStats cacheStats = cache.stats();
			if (cacheStats != null) {
				response.put("size", cache.asMap().size());
				response.put("expireAfterWrite", expireAfterWrite);
				response.put("hitCount", cacheStats.hitCount());
				response.put("missCount", cacheStats.missCount());
				response.put("loadSuccessCount", cacheStats.loadSuccessCount());
				response.put("loadExceptionCount",
						cacheStats.loadExceptionCount());
				response.put("totalLoadTime", cacheStats.totalLoadTime());
				response.put("evictionCount", cacheStats.evictionCount());
			}
		}
		return response.toJSONString();
	}

	/**
	 * getStatsFromInfiniSpanCache.
	 * 
	 * @param cache
	 *            Cache
	 * @param name
	 *            String
	 * @param cacheValidity
	 *            int
	 * @return String
	 */
	public static String getStatsFromInfiniSpanCache(Cache<?, ?> cache,
			String name, int cacheValidity) {
		JSONObject response = new JSONObject();
		JSONObject detail = new JSONObject();
		if (cache == null) {
			detail.put("status", "NOT RUNNING");
			response.put(name, detail);
		} else {
			ComponentStatus status = cache.getAdvancedCache().getStatus();
			detail.put("status", status.name());
			detail.put("cacheValidity", cacheValidity);
			detail.put("allowInvocations",
					String.valueOf(status.allowInvocations()));
			detail.put("isStopping", String.valueOf(status.isStopping()));
			detail.put("isTerminated", String.valueOf(status.isTerminated()));
			detail.put("needToDestroyFailedCache",
					String.valueOf(status.needToDestroyFailedCache()));
			detail.put("needToInitializeBeforeStart",
					String.valueOf(status.needToInitializeBeforeStart()));
			detail.put("startAllowed", String.valueOf(status.startAllowed()));
			detail.put("startingUp", String.valueOf(status.startingUp()));
			detail.put("stopAllowed", String.valueOf(status.stopAllowed()));
			if (!"TERMINATED".equals(status.name())) {
				Stats cacheStats = cache.getAdvancedCache().getStats();
				detail.put("averageReadTime", cacheStats.getAverageReadTime());
				detail.put("averageRemoveTime", cacheStats.getAverageRemoveTime());
				detail.put("averageWriteTime", cacheStats.getAverageWriteTime());
				detail.put("evictions", cacheStats.getEvictions());
				detail.put("retrievals", cacheStats.getRetrievals());
				detail.put("hits", cacheStats.getHits());
				detail.put("misses", cacheStats.getMisses());
				detail.put("numberOfEntries",
						cacheStats.getCurrentNumberOfEntries());
				detail.put("totalNumberOfEntries",
						cacheStats.getTotalNumberOfEntries());
				detail.put("removeHits", cacheStats.getRemoveHits());
				detail.put("removeMisses", cacheStats.getRemoveMisses());
				detail.put("timeSinceReset", cacheStats.getTimeSinceReset());
				detail.put("timeSinceStart", cacheStats.getTimeSinceStart());
			}
			response.put(cache.getAdvancedCache().getName(), detail);
		}
		return response.toJSONString();
	}
}
