package fr.recouv.securite.prisme.authzserver.anais;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;

import com.google.common.base.Splitter;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisDescription;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.providers.bean.PermissionsCollection;
import fr.recouv.securite.prisme.commun.providers.bean.PermissionsData;
import fr.recouv.securite.prisme.commun.utils.StringUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisPermissions : recupere les Permissions dans Anais.
 */
public class PrismeAnaisPermissions {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisPermissions.class).build();

	/**
	 * getDescription.
	 * 
	 * @param codeApplication
	 *            String
	 * @param codeOrg
	 *            String
	 * @param libDroit
	 *            String
	 * @return String description
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static String getDescription(final String codeApplication,
			final String codeOrg, final String libDroit) throws PrismeSystemException {
		LOGGER.debug("> recuperation description, codeApplication: " + codeApplication
				+ ", codeOrg: " + codeOrg + ", libDroit: " + libDroit);
		try {
			AnaisAccessRightInstance accessRightCible = null;
			// Recuperation List AnaisAccessRightInstance
			List<AnaisAccessRightInstance> listeAccessRight = PrismeAnaisAccessRightInstance
					.getAccessRightByAppCodeOrgLibDroit(codeApplication, codeOrg, libDroit);
			// Boucle liste
			for (AnaisAccessRightInstance accessRight : listeAccessRight) {
				if (accessRight != null
						&& StringUtility.isNotNullOrEmpty(accessRight.getOrgCode().value())
						&& accessRight.getCn().value().equals(libDroit)) {
					// Recuperation Instance
					accessRightCible = accessRight;
					// Sortie
					break;
				}
			}
			// Si instance null
			if (accessRightCible == null) {
				LOGGER.error("Erreur lors de la récupération de la description de l'application (application inconnue).");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur lors de la récupération de la description de l'application (application inconnue).");
			}
			LOGGER.debug("description vide ? " + StringUtility.isNullOrEmpty(accessRightCible.getDescription().value()));
			// Retour description
			return accessRightCible.getDescription().value(); 
		} catch (AnaisExceptionFailure e) {
			LOGGER.error("AnaisExceptionFailure: " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application.");
		} catch (NamingException e) {
			LOGGER.error("NamingException: " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application.");
		} catch (AnaisExceptionServerCommunication e) {
			LOGGER.error("AnaisExceptionServerCommunication: " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application.");
		}
	}

	/**
	 * getPermissionsData.
	 * 
	 * @param codeApplication
	 *            String
	 * @param codeOrg
	 *            String
	 * @param libDroit
	 *            String
	 * @return PermissionsData
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static PermissionsData getPermissionsData(final String codeApplication,
			final String codeOrg, final String libDroit) throws PrismeSystemException {
		try {
			// Recuperation description
			String description = getDescription(codeApplication, codeOrg, libDroit);
			// Si description vide
			if (StringUtility.isNullOrEmpty(description)) {
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur lors de la récupération des permissions de l'application (champ description vide).");
			}
			// Parse JSON
			JSONParser parser = new JSONParser(JSONParser.MODE_JSON_SIMPLE);
			JSONObject jsonObject = (JSONObject) parser.parse(description);
			JSONArray jsonArray = (JSONArray) jsonObject.get("listeActionsUnitaire");
			List<String> listeActionsUnitaire = new ArrayList<String>();
			for(int i = 0; i < jsonArray.size(); i++){
				listeActionsUnitaire.add((String) jsonArray.get(i));
			}
			// Parse en PermissionData
			PermissionsData pData = new PermissionsData(codeOrg, codeApplication, libDroit);
			pData.putAll(listeActionsUnitaire);
			// Retour
			return pData;
		} catch (ParseException e) {
			LOGGER.error("ParseException: " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération des permissions de l'application.");
		}
	}

	/**
	 * saveDescription.
	 * 
	 * @param codeApplication
	 *            String
	 * @param codeOrg
	 *            String
	 * @param metiersNatRef
	 *            String
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static void saveDescription(final String codeApplication,
			final String codeOrg, final String metiersNatRef) throws PrismeSystemException {
		try {
			LOGGER.debug("> save description, cn: " + codeApplication + ", codeOrg: " + codeOrg);

			// Parse metiersNatRef
			if (StringUtility.isNullOrEmpty(metiersNatRef)) {
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur lors du chargement du fichier MetiersNatRef.");
			}
			Map<String, String> mapFile = Splitter.on("\n").omitEmptyStrings()
					.trimResults().withKeyValueSeparator("=").split(metiersNatRef);
			// Conversion
			PermissionsCollection collection = new PermissionsCollection();
			for (final Map.Entry<String, String> entry : mapFile.entrySet()) {
				collection.put(codeOrg, codeApplication, entry.getKey(), entry.getValue().split(","));
			}

			// Parcours collection
			for (PermissionsData pData : collection.getAll()) {
				JSONObject json = new JSONObject();
				json.put("listeActionsUnitaire", pData.getAll());
				// Recuperation List AnaisAccessRightInstance
				List<AnaisAccessRightInstance> listeAccessRight = PrismeAnaisAccessRightInstance
						.getAccessRightByAppCodeOrgLibDroit(pData.getCodeApp(),
								pData.getCodeOrg(), pData.getLibDroit());
				for (AnaisAccessRightInstance accessRight : listeAccessRight) {
					// Si accessRight et codeOrg et libDroit
					if (accessRight != null
							&& StringUtility.isNotNullOrEmpty(accessRight.getOrgCode().value())
							&& accessRight.getCn().value().equals(pData.getLibDroit())) {
						// Save Description
						accessRight.setDescription(AnaisDescription.set(json
								.toJSONString()));
						PrismeAnaisAccessRightInstance.save(accessRight);
					}
				}
			}
		} catch (AnaisExceptionFailure e) {
			LOGGER.error("AnaisExceptionFailure: " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application.");
		} catch (NamingException e) {
			LOGGER.error("NamingException: " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application.");
		} catch (AnaisExceptionServerCommunication e) {
			LOGGER.error("AnaisExceptionServerCommunication: " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application.");
		}
	}
}
