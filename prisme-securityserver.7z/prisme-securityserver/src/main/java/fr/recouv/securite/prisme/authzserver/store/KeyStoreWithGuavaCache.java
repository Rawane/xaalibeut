package fr.recouv.securite.prisme.authzserver.store;

import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisTechnicalAccount;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.security.utility.RSAPublicKeyUtility;
import fr.recouv.securite.prisme.commun.store.IKeyStore;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * KeyStoreWithGuavaCache. <br>
 * 
 * Cache Local de RSAPublicKeyClient, egalement stockée dans Anais. <br>
 * Insertion cle : <br>
 * - Stockage cle local <br>
 * - Si Anais different, stockage sur Anais <br>
 * Recuperation cle : <br>
 * - Depuis cache local <br>
 * - Si absent, recuperation depuis Anais <br>
 */
public class KeyStoreWithGuavaCache implements IKeyStore, IStore {

	private static final PrismeLogger logger = new PrismeLogger().in(
			KeyStoreWithGuavaCache.class).build();

	// Cache <String(client_id), RSAPublicKey>
	private static LoadingCache<String, RSAPublicKey> cache;

	private static final long expireAfterWrite = 72000;

	/**
	 * Constructeur.
	 */
	public KeyStoreWithGuavaCache() {
		// Init cache
		cache = CacheBuilder.newBuilder().recordStats()
				.expireAfterWrite(72000, TimeUnit.SECONDS)
				.build(new CacheLoader<String, RSAPublicKey>() {
					@Override
					public RSAPublicKey load(String clientId)
							throws PrismeSystemException {
						return getRSAPublicKeyFromAnais(clientId);
					}
				});
	}

	@Override
	public List<EntryCache> list() {
		List<EntryCache> liste = new ArrayList<EntryCache>();
		for (String key : cache.asMap().keySet()) {
			liste.add(new EntryCache(key, (RSAPublicKey) cache.asMap().get(key)));
		}
		return liste;
	}

	@Override
	public String stats() {
		return CacheStatsUtility
				.getStatsFromGuavaCache(cache, expireAfterWrite);
	}

	@Override
	public int size() {
		if (cache != null) {
			return cache.asMap().size();
		}
		return 0;
	}


	@Override
	public void remove(final String key) {
		cache.invalidate(key);
	}

	@Override
	public void removeAll() {
		cache.invalidateAll();
	}

	@Override
	public RSAPublicKey get(String clientId) throws PrismeSystemException {
		try {
			// Recuperation depuis cache
			logger.debug("Recuperation cle par id:" + clientId);
			return cache.get(clientId);
		} catch (ExecutionException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de l'application sur Anais.");
		}
	}

	@Override
	public void put(String clientId, RSAPublicKey localPublicKey)
			throws PrismeSystemException {
		try {
			// Recuperation Anais
			AnaisTechnicalAccount technicalAccount = PrismeAnaisTechnicalAccount
					.byDN(clientId);
			// Si techAccount null, exception
			if (technicalAccount == null) {
				logger.error("Exception lors de la recuperation Anais : application inconnue");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur Anais dans le chargement de l'application.");
			}
			String anaisPK = technicalAccount.getKeyPrisme().value();
			// Convertion RSAPublicKey Local en String
			String stringLocalPK = RSAPublicKeyUtility
					.convertRSAPublicKey(localPublicKey);
			// Si enregistrement Anais different de l'actuel
			if (!anaisPK.equals(stringLocalPK)) {
				// Lancement exception
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"PublicKey Client sur Anais differente");
			}
			// Mise en cache
			logger.debug("Enregistrement cle par id:" + clientId);
			cache.put(clientId, localPublicKey);
		} catch (NamingException e) {
			logger.error("NamingException - Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"NamingException : " + e.getMessage());
		} catch (AnaisExceptionFailure e) {
			logger.error("AnaisExceptionFailure - Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"AnaisExceptionFailure : " + e.getMessage());
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("AnaisExceptionServerCommunication - Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"AnaisExceptionServerCommunication : " + e.getMessage());
		} catch (PrismeInvalidTokenException e) {
			logger.error("PrismeInvalidTokenException - Exception lors du traitement de la RSAPublicKey : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"PrismeInvalidTokenException - Erreur RSAPublicKey : "
							+ e.getMessage());
		}
	}

	/**
	 * Enrichissement RSAPublicKey.
	 * 
	 * @param clientId
	 *            String
	 * @return RSAPublicKey
	 * @throws PrismeSystemException
	 *             exception
	 */
	private static RSAPublicKey getRSAPublicKeyFromAnais(String clientId)
			throws PrismeSystemException {

		logger.debug("Enrichissement RSAPublicKey pour:" + clientId);
		try {
			// Recuperation Anais
			AnaisTechnicalAccount technicalAccount = PrismeAnaisTechnicalAccount
					.byDN(clientId);
			// Si techAccount null, exception
			if (technicalAccount == null) {
				logger.error("Exception lors de la recuperation Anais : application inconnue");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur Anais dans le chargement de l'application.");
			}
			String anaisPK = technicalAccount.getKeyPrisme().value();
			RSAPublicKey publicKey = RSAPublicKeyUtility
					.convertToRSAPublicKey(anaisPK);
			// Retour
			return publicKey;
		} catch (NamingException e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (AnaisExceptionFailure e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (PrismeInvalidTokenException e) {
			logger.error("Exception lors du traitement de la RSAPublicKey : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur RSAPublicKey : " + e.getMessage());
		}
	}
}
