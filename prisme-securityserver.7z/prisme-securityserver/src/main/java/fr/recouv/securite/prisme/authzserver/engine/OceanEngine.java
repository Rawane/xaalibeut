package fr.recouv.securite.prisme.authzserver.engine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.google.common.base.Joiner;
import com.google.common.collect.FluentIterable;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAccessRightInstance;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisApplication;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisUser;
import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.authzserver.store.KeyStoreOceanWithGuavaCache;
import fr.recouv.securite.prisme.authzserver.store.StoreManager;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.OceanToken;
import fr.recouv.securite.prisme.commun.token.engine.IEngine;
import fr.recouv.securite.prisme.commun.utils.ScopeUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * OceanEngine. Moteur de traitement d un jeton ocean vers un jeton d acces.
 * 
 */
public class OceanEngine implements IEngine {

	private static final String ERROR_USER = "Erreur Anais dans le chargement de l'utilisateur.";
	private static final String ERROR_ACCESRIGHT = "Erreur Anais dans le chargement des droits de l'utilisateur.";
	private static final String ERROR_APPLICATION = "Erreur Anais dans le chargement de l'application.";

	private static final PrismeLogger _logger = new PrismeLogger().in(
			OceanEngine.class).build();

	private String subject;
	private String issuer;
	private String audience;
	private String idStore;
	private String scope;

	private KeyStoreOceanWithGuavaCache keyStore = StoreManager.keyStoreOcean;

	@Override
	public IEngine parse(PrismeTokenRequest prismeRequest)
			throws PrismeSystemException {

		String clientId = prismeRequest.getParam(PrismeParams.CLIENT_ID);
		String key = keyStore.get(clientId);
		// - oceanToken
		OceanToken oceanToken = OceanToken.set(
				prismeRequest.getParam(PrismeParams.ASSERTION)).withKey(key)
				.decrypt();
		
		// - Subject
		this.subject = oceanToken.getSubject();
		// - Issuer
		this.issuer = clientId;

		// - Audience (scope request)
		// - Scope Response
		this.buildAudienceAndScope(prismeRequest.getParam(PrismeParams.SCOPE),
				oceanToken);

		// - Id Store
		try {
			this.idStore = ScopeUtility.encodeIdStore(this.subject,
					this.issuer, "[" + this.audience + "]");
		} catch (IOException e) {
			_logger.error("Erreur generation id store Ocean : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur generation id store Ocean");
		}
		return this;
	}

	/**
	 * Construit les chaines d audience et de scope.
	 * 
	 * @param param
	 * @param oceanToken
	 * 
	 * @throws PrismeSystemException
	 */
	private void buildAudienceAndScope(String param, OceanToken oceanToken)
			throws PrismeSystemException {
		this.scope = "";

		String api_label = "";
		List<AnaisOrgCode> listOfOrgCode = new ArrayList<AnaisOrgCode>();

		this.audience = param;
		String scopeDecoded = PrismeRequestScope.decode(param);

		// re-alignement du scope.
		for (final String s : scopeDecoded.split(PrismeRequestScope.SCOPE_SEPARATOR)) {
			String[] result = s.split(PrismeRequestScope.SEPARATOR);
			api_label = result[1];
			listOfOrgCode.add(AnaisOrgCode.set(result[0]));
		}

		AnaisUser anaisUser = loadAnaisUser(oceanToken);
		AnaisApplication application = loadAnaisApplication(api_label);

		List<AnaisAccessRightInstance> listAnaisHabilitation = null;
		if (isLoadedWithAll(listOfOrgCode)) {
			listAnaisHabilitation = loadAccessRightsWithoutCodeOrgList(
					anaisUser, application);
		} else {
			listAnaisHabilitation = loadAccessRightsWithCodeOrgList(
					listOfOrgCode, anaisUser, application);
		}

		List<String> assemblage = new ArrayList<String>();
		for (AnaisAccessRightInstance ar : listAnaisHabilitation) {
			assemblage.add(ar.getOrgCode().value()
					+ PrismeRequestScope.SEPARATOR
					+ ar.getApplicationCode().value()
					+ PrismeRequestScope.SEPARATOR + ar.getCn().value());
		}

		this.scope = Joiner.on(PrismeRequestScope.SCOPE_SEPARATOR).join(
				FluentIterable.from(assemblage).toList());
	}

	/**
	 * Interroge Anais pour determiner les habilitations de l utilisateur
	 * (subjet) pour une liste restrictive organismes
	 * 
	 * @param listOfOrgCode
	 * @param anaisUser
	 * @param anaisApplication
	 * @return une liste d objets de type AnaisAccessRightInstance representant
	 *         une habilitation dans anais
	 * 
	 * @throws PrismeSystemException
	 */
	private List<AnaisAccessRightInstance> loadAccessRightsWithCodeOrgList(
			List<AnaisOrgCode> listOfOrgCode, AnaisUser anaisUser,
			AnaisApplication anaisApplication) throws PrismeSystemException {

		List<AnaisAccessRightInstance> listAnaisHabilitation = null;
		try {
			listAnaisHabilitation = PrismeAnaisAccessRightInstance.listeAccessRightByUserAppCodeOrg(
					anaisUser, anaisApplication, listOfOrgCode);
		} catch (AnaisExceptionFailure e) {
			_logger.error(ERROR_ACCESRIGHT);
			_logger.debug(ERROR_ACCESRIGHT, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_ACCESRIGHT);
		} catch (AnaisExceptionServerCommunication e) {
			_logger.error(ERROR_ACCESRIGHT);
			_logger.debug(ERROR_ACCESRIGHT, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_ACCESRIGHT);
		} catch (NamingException e) {
			_logger.error(ERROR_ACCESRIGHT);
			_logger.debug(ERROR_ACCESRIGHT, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_ACCESRIGHT);
		}
		return listAnaisHabilitation;
	}

	/**
	 * Interroge Anais pour determiner les habilitations de l utilisateur
	 * (subjet) pour l ensemble des organismes
	 * 
	 * @param anaisUser
	 * @param anaisApplication
	 * @return une liste d objets de type AnaisAccessRightInstance representant
	 *         une habilitation dans anais
	 * 
	 * @throws PrismeSystemException
	 */
	private List<AnaisAccessRightInstance> loadAccessRightsWithoutCodeOrgList(
			AnaisUser anaisUser, AnaisApplication anaisApplication)
			throws PrismeSystemException {

		List<AnaisAccessRightInstance> listAnaisHabilitation = null;

		try {
			listAnaisHabilitation = PrismeAnaisAccessRightInstance.listeAccessRightByUserApp(
					anaisUser, anaisApplication);
		} catch (AnaisExceptionFailure e) {
			_logger.error(ERROR_ACCESRIGHT);
			_logger.debug(ERROR_ACCESRIGHT, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_ACCESRIGHT);
		} catch (AnaisExceptionServerCommunication e) {
			_logger.error(ERROR_ACCESRIGHT);
			_logger.debug(ERROR_ACCESRIGHT, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_ACCESRIGHT);
		} catch (NamingException e) {
			_logger.error(ERROR_ACCESRIGHT);
			_logger.debug(ERROR_ACCESRIGHT, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_ACCESRIGHT);
		}
		return listAnaisHabilitation;
	}

	/**
	 * determine si les habilitations sont restreint a une liste de code
	 * organisme.
	 * 
	 * @param listOfOrgCode
	 * @return boolean si il y a une liste restrictive oui ou non
	 */
	private boolean isLoadedWithAll(List<AnaisOrgCode> listOfOrgCode) {
		return listOfOrgCode.contains(PrismeRequestScope.ALL);
	}

	/**
	 * Charge les informations de l application a partir d Anais
	 * 
	 * @param oceanToken
	 * @param anaisUser
	 * @return AnaisApplication Un objet de type anais application
	 * @throws PrismeSystemException
	 */
	private AnaisApplication loadAnaisApplication(String api_label)
			throws PrismeSystemException {
		AnaisApplication anaisApplication = null;
		try {
			anaisApplication = PrismeAnaisApplication.getApplicationByCN(api_label);
		} catch (AnaisExceptionFailure e) {
			_logger.error(ERROR_APPLICATION);
			_logger.debug(ERROR_APPLICATION, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_APPLICATION);
		} catch (AnaisExceptionServerCommunication e) {
			_logger.error(ERROR_APPLICATION);
			_logger.debug(ERROR_APPLICATION, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_APPLICATION);
		} catch (NamingException e) {
			_logger.error(ERROR_APPLICATION);
			_logger.debug(ERROR_APPLICATION, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_APPLICATION);
		} finally {
			if (anaisApplication == null) {
				_logger.error(ERROR_APPLICATION);
				_logger.debug(ERROR_APPLICATION + " (application nulle)");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						ERROR_APPLICATION);
			}
		}
		return anaisApplication;
	}

	/**
	 * Charge les informations de l utilisateur a partir d Anais
	 * 
	 * @param oceanToken OceanToken
	 * @return AnaisUser anaisUser
	 * @throws PrismeSystemException exception
	 * 
	 */
	private AnaisUser loadAnaisUser(OceanToken oceanToken)
			throws PrismeSystemException {
		AnaisUser anaisUser = null;
		try {
			anaisUser = PrismeAnaisUser.byUID(oceanToken.getSubject());
		} catch (AnaisExceptionFailure e) {
			_logger.error(ERROR_USER);
			_logger.debug(ERROR_USER, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_USER);
		} catch (AnaisExceptionServerCommunication e) {
			_logger.error(ERROR_USER);
			_logger.debug(ERROR_USER, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_USER);
		} catch (NamingException e) {
			_logger.error(ERROR_USER);
			_logger.debug(ERROR_USER, e);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					ERROR_USER);
		} finally {
			if (anaisUser == null) {
				_logger.error(ERROR_USER);
				_logger.debug(ERROR_USER + " (utilisateur nul)");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						ERROR_USER);
			}
		}
		return anaisUser;
	}

	@Override
	public String getIssuer() {
		return this.issuer;
	}

	@Override
	public String getAudience() {
		return this.audience;
	}

	@Override
	public String getIdStore() {
		return this.idStore;
	}

	@Override
	public String getSubject() {
		return this.subject;
	}

	@Override
	public String getScope() {
		return this.scope;
	}
}
