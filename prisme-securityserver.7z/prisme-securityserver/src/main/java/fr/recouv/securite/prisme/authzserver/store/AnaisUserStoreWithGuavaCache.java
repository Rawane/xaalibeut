package fr.recouv.securite.prisme.authzserver.store;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisUser;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * AnaisUserStoreWithGuavaCache. <br>
 * 
 * Cache Local d'utilisateur Anais <br>
 * - Si absent, recuperation depuis Anais <br>
 */
public class AnaisUserStoreWithGuavaCache implements IStore {

	private static final PrismeLogger logger = new PrismeLogger().in(
			AnaisUserStoreWithGuavaCache.class).build();

	private static LoadingCache<String, AnaisUser> cache;

	private static final long expireAfterWrite = 21600;

	/**
	 * Constructeur.
	 */
	public AnaisUserStoreWithGuavaCache() {
		// Init cache
		cache = CacheBuilder.newBuilder().recordStats()
				.expireAfterWrite(expireAfterWrite, TimeUnit.SECONDS)
				.build(new CacheLoader<String, AnaisUser>() {
					@Override
					public AnaisUser load(String uid)
							throws PrismeSystemException {
						return loadUserFromAnais(uid);
					}
				});
	}

	@Override
	public List<EntryCache> list() {
		List<EntryCache> liste = new ArrayList<EntryCache>();
		for (String key : cache.asMap().keySet()) {
			liste.add(new EntryCache(key, (AnaisUser) cache.asMap().get(key)));
		}
		return liste;
	}

	@Override
	public String stats() {
		return CacheStatsUtility
				.getStatsFromGuavaCache(cache, expireAfterWrite);
	}

	@Override
	public int size() {
		if (cache != null) {
			return cache.asMap().size();
		}
		return 0;
	}


	@Override
	public void remove(final String key) {
		cache.invalidate(key);
	}

	@Override
	public void removeAll() {
		cache.invalidateAll();
	}

	/**
	 * Recupere AnaisUser en fonction de uid.
	 * 
	 * @param uid
	 *            String
	 * @return AnaisUser
	 * @throws PrismeSystemException
	 *             exception
	 */
	public AnaisUser get(String uid) throws PrismeSystemException {
		try {
			// Recuperation depuis cache
			logger.debug("Recuperation AnaisUser par uid:" + uid);
			return cache.get(uid);
		} catch (ExecutionException e) {
			String msg = e.getMessage();
			if (e.getCause() != null) {
				msg = e.getCause().getMessage();
			}
			logger.error("Exception:" + msg);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					msg, e);
		}
	}

	/**
	 * Enrichissment du magasin local des identites.
	 * 
	 * @param uid
	 *            String
	 * @return AnaisUser un objet AnaisUser
	 * @throws PrismeSystemException
	 *             exception
	 */
	private static AnaisUser loadUserFromAnais(String uid)
			throws PrismeSystemException {
		logger.debug("Enrichissement du store pour l uid:" + uid);
		try {
			// Recuperation Anais
			AnaisUser anaisUser = PrismeAnaisUser.byUID(uid);
			// Retour
			return anaisUser;
		} catch (NamingException e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (AnaisExceptionFailure e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		}
	}
}
