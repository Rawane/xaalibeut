package fr.recouv.securite.prisme.authzserver.client;

import javax.servlet.http.HttpServletRequest;

/**
 * HttpRequestUtility.
 */
public class HttpRequestUtility {

	/**
	 * GetURLRequest : determine l'url de la request.
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @return String urlRequest
	 */
	public static String getURLRequest(HttpServletRequest request) {;
		// Build urlRequest
		StringBuilder urlRequest = new StringBuilder();
		urlRequest.append(request.getScheme()).append("://")
			.append(request.getServerName());
		if (request.getServerPort() != 80
				&& request.getServerPort() != 443) {
			urlRequest.append(":").append(request.getServerPort());
		}
		urlRequest.append(request.getContextPath());
		return urlRequest.toString();
	}
}
