package fr.recouv.securite.prisme.authzserver.store;

/**
 * RegistryStoreWithInfiniSpanCacheMBean.
 */
public interface RegistryStoreWithInfiniSpanCacheMBean extends IStoreMBean {

	// Voir IStoreMBean
}
