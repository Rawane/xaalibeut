package fr.recouv.securite.prisme.authzserver.mock;

import fr.recouv.securite.prisme.authzserver.bo.Dashboard;

/**
 * DashboardMock.
 */
public class DashboardMock {

	static {
		// TODO
	}

	/**
	 * getAllIndicators.
	 * 
	 * @return DashBoard
	 */
	public static Dashboard getAllIndicators() {
		Dashboard dashboard = new Dashboard();
		dashboard.setNbApplications("3");
		dashboard.setNbTokens("2");
		dashboard.setNbConfigs("1");
		dashboard.setNbCaches("0");
		return dashboard;
	}

	/**
	 * RefreshIndicator.
	 * 
	 * @param nom
	 *            String
	 * @return DashBoard
	 */
	public static Dashboard refreshIndicator(String nom) {
		Dashboard dashboard = new Dashboard();
		if ("application".equals(nom)) {
			dashboard.setNbApplications("3");
		}
		if ("token".equals(nom)) {
			dashboard.setNbTokens("3");
		}
		if ("config".equals(nom)) {
			dashboard.setNbConfigs("1");
		}
		if ("cache".equals(nom)) {
			dashboard.setNbCaches("9");
		}
		return dashboard;
	}

	/**
	 * getAllValidators.
	 * 
	 * @return Dashboard
	 */
	public static Dashboard getAllValidators() {
		Dashboard dashboard = new Dashboard();
		// Anais
		dashboard.setAnaisStatus("false");
		dashboard.setAnaisHost("cnp69devanaispiv3.cer69.recouv.mock");
		dashboard.setAnaisResult("Erreur: Naming exception.");
		// Interops
		dashboard.setInterOpsStatus("true");
		dashboard.setInterOpsHost("intinteropsjeton2.cer31.recouv.mock");
		dashboard.setInterOpsResult("OK");
		// Ocean
		dashboard.setOceanStatus("false");
		dashboard.setOceanHost("hwi69devoceanappli.renov.recouv/ocean/servlet/qos.mock");
		dashboard.setOceanResult("Erreur lors de la validation du jeton Ocean");
		return dashboard;
	}

	/**
	 * RefreshValidator.
	 * 
	 * @param nom
	 *            String
	 * @return DashBoard
	 */
	public static Dashboard refreshValidator(String nom) {
		Dashboard dashboard = new Dashboard();
		if ("anais".equals(nom)) {
			dashboard.setAnaisStatus("true");
			dashboard.setAnaisHost("cnp69devanaispiv3.cer69.recouv.mock");
			dashboard.setAnaisResult("OK");
		}
		if ("interOps".equals(nom)) {
			dashboard.setInterOpsStatus("false");
			dashboard.setInterOpsHost("intinteropsjeton2.cer31.recouv.mock");
			dashboard.setInterOpsResult("Erreur: Connection interrompue.");
		}
		if ("ocean".equals(nom)) {
			dashboard.setOceanStatus("false");
			dashboard.setOceanHost("hwi69devoceanappli.renov.recouv/ocean/servlet/qos.mock");
			dashboard.setOceanResult("Erreur lors de la validation du jeton Ocean");
		}
		return dashboard;
	}
}
