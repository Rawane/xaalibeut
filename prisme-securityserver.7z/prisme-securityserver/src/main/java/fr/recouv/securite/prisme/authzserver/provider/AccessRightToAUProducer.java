package fr.recouv.securite.prisme.authzserver.provider;

import javax.servlet.http.HttpServletResponse;

import fr.recouv.securite.prisme.authzserver.request.PrismePopulateRequest;
import fr.recouv.securite.prisme.authzserver.response.PrismePopulateServerResponse;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.response.PrismeResponse;
import fr.recouv.securite.prisme.commun.message.types.PrismePopulateType;
import fr.recouv.securite.prisme.commun.providers.bean.PermissionsData;
import fr.recouv.securite.prisme.logger.PrismeLogger;

public class AccessRightToAUProducer implements PrismePopulateServerProvider {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			AccessRightToAUProducer.class).build();

	PrismePopulateRequest request;

	/**
	 * Constructeur.
	 * 
	 * @param request PrismePopulateRequest
	 */
	public AccessRightToAUProducer(PrismePopulateRequest request) {
		this.request = request;
	}

	@Override
	public PrismeResponse compose() throws PrismeSystemException {

		LOGGER.debug("> compose");

		String application = request.getParam(PrismeParams.POPULATE.APPLICATION);
		String perimetre = request.getParam(PrismeParams.POPULATE.PERIMETRE);
		String accessRight = request.getParam(PrismeParams.POPULATE.ACCESSRIGHT);
		LOGGER.debug("application: " + application);
		LOGGER.debug("perimetre: " + perimetre);
		LOGGER.debug("accessRight: " + accessRight);

		// Determination key
		String key = PermissionsData.resolveKey(perimetre, application, accessRight);
		PermissionsData pData = PermissionsData.createByKey(key);
		try {
			// Lecture cache
			pData = PrismeContexteDescriptor.getPermissionsStore().get(key);
		} catch (PrismeException e) {
			LOGGER.error("PrismeException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE, e.getMessage());
		}

		// Reponse
		PrismeResponse response = PrismePopulateServerResponse
				.response(HttpServletResponse.SC_OK)
				.setParam(PrismeParams.POPULATE.TYPE,
						PrismePopulateType.ACCESSRIGHT_TO_AU.toString())
				.setParam(PrismeParams.POPULATE.APPLICATION, application)
				.setParam(PrismeParams.POPULATE.ACCESSRIGHT, accessRight)
				.setParam(PrismeParams.POPULATE.AU, pData.getListeActionsUnitaire())
				.buildJSONMessage();
		// Resultat:
		return response;
	}
}
