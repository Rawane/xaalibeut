package fr.recouv.securite.prisme.authzserver.store;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisUID;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAccessRightInstance;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.utils.ScopeUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * ScopeStoreWithGuavaCache. <br>
 * 
 * Cache Local de scopes calcules.<br>
 * - Si absent, calcul depuis Anais <br>
 */
public class ScopeStoreWithGuavaCache implements IStore {

	private static final PrismeLogger logger = new PrismeLogger().in(
			ScopeStoreWithGuavaCache.class).build();

	private static LoadingCache<String, PrismeResponseScope> cache;

	private static final String SEPARATOR = "@";
	private static final long expireAfterWrite = 3600;

	/**
	 * Constructeur.
	 */
	public ScopeStoreWithGuavaCache() {
		// Init cache
		cache = CacheBuilder.newBuilder().recordStats()
				.expireAfterWrite(expireAfterWrite, TimeUnit.SECONDS)
				.build(new CacheLoader<String, PrismeResponseScope>() {
					@Override
					public PrismeResponseScope load(String uidAndEncodedScope)
							throws PrismeSystemException {
						return buildScope(uidAndEncodedScope);
					}
				});
	}

	@Override
	public List<EntryCache> list() {
		List<EntryCache> liste = new ArrayList<EntryCache>();
		for (String key : cache.asMap().keySet()) {
			liste.add(new EntryCache(key, (PrismeResponseScope) cache.asMap()
					.get(key)));
		}
		return liste;
	}

	@Override
	public String stats() {
		return CacheStatsUtility
				.getStatsFromGuavaCache(cache, expireAfterWrite);
	}

	@Override
	public int size() {
		if (cache != null) {
			return cache.asMap().size();
		}
		return 0;
	}

	@Override
	public void remove(final String key) {
		cache.invalidate(key);
	}

	@Override
	public void removeAll() {
		cache.invalidateAll();
	}

	/**
	 * Recupere le PrismeResponseScope en fonction de uid et encodedScope.
	 * 
	 * @param uid
	 *            String
	 * @param encodedScope
	 *            String
	 * @return PrismeResponseScope
	 * @throws PrismeSystemException
	 *             exception
	 */
	public PrismeResponseScope get(final String uid, final String encodedScope)
			throws PrismeSystemException {
		try {
			// Recuperation depuis cache
			final String key = uid + SEPARATOR + encodedScope;
			logger.debug("Recuperation scope par uidAndEncodedScope:" + key);
			return cache.get(key);
		} catch (ExecutionException e) {
			String msg = e.getMessage();
			if (e.getCause() != null) {
				msg = e.getCause().getMessage();
			}
			logger.error("Exception:" + msg);
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					msg, e);
		}
	}

	/**
	 * Enrichissment du magasin locale du scope a partir des donees aanais
	 * 
	 * @param uidAndEncodedScope
	 *            String
	 * @return PrismeResponseScope un objet PrismeResponseScope
	 * @throws PrismeSystemException
	 *             exception
	 */
	private static PrismeResponseScope buildScope(String uidAndEncodedScope)
			throws PrismeSystemException {

		Date dateDebut = new Date();

		String[] param = uidAndEncodedScope.split(SEPARATOR);
		String user = param[0];
		String encodedRequestScope = param[1];

		logger.debug(" >>> buildScope");
		try {
			logger.debug("params:user:" + user + ",scope:"
					+ encodedRequestScope);
			// Etape 1 :
			// Construire une map codeAppli-list<CodeOrg> depuis scopeRequest
			Map<String, List<String>> mapScope = ScopeUtility
					.extractMapCodeAppliListCodeOrg(encodedRequestScope);

			// Etape 2 :
			// Recuperation AnaisUser
			AnaisUID uid = AnaisUID.set(user);
			if (!uid.isAnValidateUID()) {
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"AnaisUser inconnu : " + user);
			}
			AnaisUser anaisUser = StoreManager.anaisUserStore.get(user);

			// Etape 3 :
			// Pour chaque application
			Map<String, AnaisAccessRightInstance> mapAccessRight = new HashMap<String, AnaisAccessRightInstance>();
			for (String codeAppli : mapScope.keySet()) {
				List<AnaisAccessRightInstance> list = null;

				// AnaisApplication
				AnaisApplication anaisApplication = StoreManager.anaisAppsStore.get(codeAppli);

				// AnaisOrgCode
				if (mapScope.get(codeAppli).contains(PrismeRequestScope.ALL)) {
					// RequeteAnais (sans CodeOrg)
					list = PrismeAnaisAccessRightInstance.listeAccessRightByUserApp(
							anaisUser, anaisApplication);
				} else {
					List<AnaisOrgCode> listOfOrgCode = new ArrayList<AnaisOrgCode>();
					for (String codeOrg : mapScope.get(codeAppli)) {
						listOfOrgCode.add(AnaisOrgCode.build(codeOrg));
					}
					// RequeteAnais (avec CodeOrg)
					list = PrismeAnaisAccessRightInstance.listeAccessRightByUserAppCodeOrg(
							anaisUser, anaisApplication, listOfOrgCode);
				}

				// Ajout dans Map Finale si non present
				for (AnaisAccessRightInstance ari : list) {
					String keyAri =
							patchDEFAULT(ari.getOrgCode().value(), ari.getApplicationCode().value()) + ","
							+ ari.getApplicationCode().value() + ","
							+ ari.getCn().value();
					if (!mapAccessRight.containsKey(keyAri)) {
						mapAccessRight.put(keyAri, ari);
					}
				}
			}

			// Etape 4 :
			// Calcul Scope Response
			PrismeResponseScope responseScope = PrismeResponseScope.set();
			for (String keyAri : mapAccessRight.keySet()) {
				AnaisAccessRightInstance ari = mapAccessRight.get(keyAri);
				responseScope = responseScope.add(
						patchDEFAULT(ari.getOrgCode().value(), ari.getApplicationCode().value()), 
						ari.getApplicationCode().value(), ari.getCn().value());
			}
			responseScope = responseScope.build();
			logger.debug("scope:" + responseScope.serialize());

			// Retour ResponseScope
			return responseScope;
		} catch (AnaisExceptionFailure e) {
			logger.error("AnaisExceptionFailure : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SERVER_ERROR,
					e.getMessage());
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("AnaisExceptionServerCommunication : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SERVER_ERROR,
					e.getMessage());
		} catch (NamingException e) {
			logger.error("NamingException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.SERVER_ERROR,
					e.getMessage());
		} finally {
			long interval = new Date().getTime() - dateDebut.getTime();
			logger.debug("Duree traitement (ms):" + interval);
			logger.debug(" <<< getResponseScope");
		}

	}

	/**
	 * patchDSN.
	 * 
	 * @param codeOrg String
	 * @param codeAppli String
	 * @return String
	 */
	private static String patchDEFAULT(String codeOrg, String codeAppli) {
		if ("DSN".equals(codeAppli) || "ARCHIMED-BAPI".equals(codeAppli) || "ARCHIMED-SAMPLE".equals(codeAppli)) {
			return "DEFAULT";
		}
		return codeOrg;
	}
}
