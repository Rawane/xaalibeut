package fr.recouv.securite.prisme.authzserver.listener;

import java.lang.ref.Reference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;

import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeThreadsManager : <br>
 * 
 * Permet d'effectuer les actions suivantes : <br>
 * <ul>
 * <li>showThread : afficher la liste des Threads en cours</li>
 * <li>sleepThread : sleep pour attendre la fermeture des threads</li>
 * <li>stopThread : stop les threads toujours actifs</li>
 * <li>checkThread : verification sur possible memory leaks</li>
 * </ul>
 * 
 * Librement inspiré sur WebappClassLoader (org.apache.catalina.loader)
 */
public class PrismeThreadsManager {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeThreadsManager.class).build();

	private static final int TIME_SLEEP = 10000;

	/**
	 * showThread : affiche la liste des threads actifs
	 */
	public static void showThread() {
		LOGGER.debug(" -- showThread --");
		// Recuperer liste threads actifs
		List<Thread> listeThread = listeThread();
		if (listeThread.isEmpty()) {
			LOGGER.debug("... Aucun thread actifs ...");
		} else {
			LOGGER.debug("... Liste des threads actifs [");
			// Afficher liste thread actifs
			for (Thread thread : listeThread) {
				LOGGER.debug("- name: " + thread.getName());
			}
			LOGGER.debug("]");
		}
	}

	/**
	 * sleepThread : sleep pour attendre la fermeture des threads.
	 */
	public static void sleepThread() {
		LOGGER.debug(" -- sleepThread --");
		// Thread sleep
		try {
			LOGGER.debug("... Attente de " + TIME_SLEEP
					+ " ms pour fermeture threads ...");
			Thread.sleep(TIME_SLEEP);
		} catch (InterruptedException e) {
			LOGGER.error(e.getMessage());
		} finally {
			LOGGER.debug("... Fin attente ...");
		}
	}

	/**
	 * stopThread : stop les threads toujours actifs.
	 */
	public static void stopThread() {
		LOGGER.debug(" -- stopThread --");
		// Recuperer liste threads actifs
		List<Thread> listeThread = listeThread();
		if (listeThread.isEmpty()) {
			LOGGER.debug("... Aucun thread actif ...");
		} else {
			// Boucler sur threads actifs
			for (Thread thread : listeThread) {
				// Stop le thread
				LOGGER.debug("... Fermeture thread : " + thread.getName()
						+ " ...");
				stopThread(thread);
			}
			// Verification thread restant
			List<Thread> listeThreadAfterStop = listeThread();
			if (!listeThreadAfterStop.isEmpty()) {
				for (Thread thread : listeThreadAfterStop) {
					LOGGER.debug("... WARNING ! Thread " + thread.getName()
							+ " toujours actif");
				}
			}
		}
	}

	/**
	 * checkTread : verification sur possible memory leaks.
	 */
	public static void checkThread() {
		LOGGER.debug(" -- checkThread --");
		// Recuperer tous thread
		Thread[] threads = listeAllThread();
		try {
			// Rend Field accessible
			Field threadLocalsField = Thread.class
					.getDeclaredField("threadLocals");
			threadLocalsField.setAccessible(true);
			Field inheritableThreadLocalsField = Thread.class
					.getDeclaredField("inheritableThreadLocals");
			inheritableThreadLocalsField.setAccessible(true);
			// Rend Object du Thread accessible
			Class<?> tlmClass = Class
					.forName("java.lang.ThreadLocal$ThreadLocalMap");
			Field tableField = tlmClass.getDeclaredField("table");
			tableField.setAccessible(true);
			Method expungeStaleEntriesMethod = tlmClass
					.getDeclaredMethod("expungeStaleEntries");
			expungeStaleEntriesMethod.setAccessible(true);
			// Parcours thread
			for (int i = 0; i < threads.length; i++) {
				Object threadLocalMap;
				if (threads[i] != null) {
					// Clear the first map
					threadLocalMap = threadLocalsField.get(threads[i]);
					if (null != threadLocalMap) {
						expungeStaleEntriesMethod.invoke(threadLocalMap);
						checkThreadLocalMapForLeaks(threadLocalMap, tableField);
					}
					// Clear the second map
					threadLocalMap = inheritableThreadLocalsField
							.get(threads[i]);
					if (null != threadLocalMap) {
						expungeStaleEntriesMethod.invoke(threadLocalMap);
						checkThreadLocalMapForLeaks(threadLocalMap, tableField);
					}
				}
			}
		} catch (Throwable t) {
			LOGGER.warn(" Exception checkThreadLocalsForLeaks  : "
					+ t.getMessage());
		}
	}

	/**
	 * listeAllThread : retourne la liste de tous les threads.
	 * 
	 * @return Thread
	 */
	protected static Thread[] listeAllThread() {
		// Recuperation thread group courant
		ThreadGroup tg = Thread.currentThread().getThreadGroup();
		// Recherche root thread group
		try {
			while (tg.getParent() != null) {
				tg = tg.getParent();
			}
		} catch (SecurityException se) {
			LOGGER.error(tg.getName() + " - " + se.getMessage());
		}
		int threadCountGuess = tg.activeCount() + 50;
		Thread[] threads = new Thread[threadCountGuess];
		int threadCountActual = tg.enumerate(threads);
		// Pour ne manquer aucun thread
		while (threadCountActual == threadCountGuess) {
			threadCountGuess *= 2;
			threads = new Thread[threadCountGuess];
			threadCountActual = tg.enumerate(threads);
		}
		// Retour
		return threads;
	}

	/**
	 * listeThread : Retourne la liste des threads actifs et du meme
	 * classLoader.
	 * 
	 * @return List Thread
	 */
	protected static List<Thread> listeThread() {
		List<Thread> listeThread = new ArrayList<Thread>();
		// Recuperation all threads
		Thread[] threads = listeAllThread();
		// Liste Thread : threads
		for (Thread thread : threads) {
			if (thread != null) {
				ClassLoader cl = thread.getContextClassLoader();
				if (cl == PrismeThreadsManager.class.getClassLoader()
						&& thread != Thread.currentThread() && thread.isAlive()) {
					// Ajout threads
					listeThread.add(thread);
				}
			}
		}
		// Retourne listeThread
		return listeThread;
	}

	/**
	 * stopThread : stop un thread.
	 * 
	 * @param thread
	 *            Thread
	 */
	@SuppressWarnings("deprecation")
	protected static void stopThread(Thread thread) {
		try {
			synchronized (thread) {
				int count = 0;
				while (thread.isAlive() && count < 100) {
					try {
						Thread.sleep(20);
					} catch (InterruptedException e) {
						// Quit the while loop
						break;
					}
					count++;
				}
				if (thread.isAlive()) {
					// This method is deprecated and for good reason. This is
					// very risky code but is the only option at this point.
					// A *very* good reason for apps to do this clean-up
					// themselves.
					thread.stop();
				}
			}
		} catch (Throwable e) {
			LOGGER.error(" - Erreur stopThread : " + thread.getName()
					+ ", Exception : " + e.getMessage());
		}
	}

	/**
	 * checkThreadLocalMapForLeaks : verifie ThreadLocal MemoryLeak.
	 * 
	 * Analyzes the given thread local map object. <br>
	 * Also pass in the field that points to the internal table to save
	 * re-calculating it on every call to this method.
	 * 
	 * @param map
	 *            Object
	 * @param internalTableField
	 *            Field
	 * @exception IllegalAccessException
	 *                exception
	 * @exception NoSuchFieldException
	 *                exception
	 */
	protected static void checkThreadLocalMapForLeaks(Object map,
			Field internalTableField) throws IllegalAccessException,
			NoSuchFieldException {
		if (map != null) {
			Object[] table = (Object[]) internalTableField.get(map);
			if (table != null) {
				for (int j = 0; j < table.length; j++) {
					Object obj = table[j];
					if (obj != null) {
						boolean potentialLeak = false;
						// Check the key
						Object key = ((Reference<?>) obj).get();
						if (loadedByThisOrChild(key)) {
							potentialLeak = true;
						}
						// Check the value
						Field valueField = obj.getClass().getDeclaredField(
								"value");
						valueField.setAccessible(true);
						Object value = valueField.get(obj);
						if (loadedByThisOrChild(value)) {
							potentialLeak = true;
						}
						if (potentialLeak) {
							String nameClass = "unknown";
							if (key != null) {
								nameClass = getPrettyClassName(key.getClass());
							}
							LOGGER.debug("... WARNING : Probable memory leak sur : "
									+ nameClass);
						}
					}
				}
			}
		}
	}

	/**
	 * loadedByThisOrChild : verifie si object charge par classloader.
	 * 
	 * @param o
	 *            object to test, may be null
	 * @return <code>true</code> if o has been loaded by the current classloader
	 *         or one of its descendants.
	 */
	protected static boolean loadedByThisOrChild(Object o) {
		if (o == null) {
			return false;
		}
		Class<?> clazz;
		if (o instanceof Class) {
			clazz = (Class<?>) o;
		} else {
			clazz = o.getClass();
		}
		ClassLoader cl = clazz.getClassLoader();
		while (cl != null) {
			if (cl == PrismeThreadsManager.class.getClassLoader()) {
				return true;
			}
			cl = cl.getParent();
		}
		if (o instanceof Collection<?>) {
			Iterator<?> iter = ((Collection<?>) o).iterator();
			try {
				while (iter.hasNext()) {
					Object entry = iter.next();
					if (loadedByThisOrChild(entry)) {
						return true;
					}
				}
			} catch (ConcurrentModificationException e) {
				LOGGER.warn(" Exception : " + e.getMessage());
			}
		}
		return false;
	}

	/**
	 * getPrettyClassName : Retourne className.
	 * 
	 * @param clazz
	 *            Class
	 * @return String name
	 */
	protected static String getPrettyClassName(Class<?> clazz) {
		String name = clazz.getCanonicalName();
		if (name == null) {
			name = clazz.getName();
		}
		return name;
	}
}
