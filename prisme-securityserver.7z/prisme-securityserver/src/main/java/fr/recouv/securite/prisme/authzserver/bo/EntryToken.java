package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import net.minidev.json.JSONObject;

import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.AbstractToken;
import fr.recouv.securite.prisme.commun.token.AccessPrismeToken;
import fr.recouv.securite.prisme.commun.token.JWTAccessToken;
import fr.recouv.securite.prisme.commun.token.reverse.JWTReverse;
import fr.recouv.securite.prisme.commun.utils.ScopeUtility;

/**
 * EntryToken
 */
public class EntryToken implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 2622008105242480759L;

	private String value;

	// JWTReverse
	private String uid;

	private String issuer;

	private String scope;

	private Date issueTime;

	private Date expirationTime;

	// Infos complementaires
	private String userId;

	private String clientId;

	private String scopeRequest;

	/**
	 * Constructeur simple.
	 */
	public EntryToken() {
		super();
	}

	/**
	 * Constructeur.
	 * 
	 * @param abstractToken
	 *            AbstractToken
	 * @throws PrismeSystemException
	 *             exception
	 */
	public EntryToken(final AbstractToken abstractToken) throws PrismeSystemException {
		try {
			if (abstractToken.getType().equals(PrismeParams.TOKEN.JWT_TYPE)) {
				// JWT
				final JWTAccessToken token = new JWTAccessToken(
						abstractToken.value());
				// Recuperation valeurs
				this.value = token.value();
				this.uid = token.UID();
				// Reverse sur token
				JWTReverse jwt = JWTReverse.set(token.value()).build();
				this.issuer = jwt.getIssuer();
				this.scope = PrismeResponseScope.decode(jwt.getScope());
				this.issueTime = jwt.getIssueTime();
				this.expirationTime = jwt.getExpirationTime();
				// Calcul element complementaire
				final List<String> listeIdStoreExposed = ScopeUtility
						.exposeIdStore(jwt.getIdStore());
				this.userId = listeIdStoreExposed.get(0);
				this.clientId = listeIdStoreExposed.get(1);
				this.scopeRequest = listeIdStoreExposed.get(2);
			} else if (abstractToken.getType().equals(
					PrismeParams.TOKEN.JSON_TYPE)) {
				// JSON
				final AccessPrismeToken token = new AccessPrismeToken(
						abstractToken.value());
				// Recuperation valeurs
				this.value = token.value();
				this.uid = token.UID();
			}
		} catch (PrismeInvalidTokenException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur PrismeInvalidTokenException: " + e.getMessage());
		} catch (ParseException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur ParseException: " + e.getMessage());
		}
	}

	@Override
	public String toString() {
		JSONObject response = new JSONObject();
		response.put("uid", this.uid);
		response.put("userId", this.userId);
		response.put("scope", this.scope);
		if (this.issueTime != null) {
			response.put("issueTime", this.issueTime.getTime());
		}
		if (this.expirationTime != null) {
			response.put("expirationTime", this.expirationTime.getTime());
		}
		// Elements complementaires
		response.put("value", this.value);
		response.put("issuer", this.issuer);
		response.put("clientId", this.clientId);
		response.put("scopeRequest", this.scopeRequest);
		return response.toJSONString();
	}
}
