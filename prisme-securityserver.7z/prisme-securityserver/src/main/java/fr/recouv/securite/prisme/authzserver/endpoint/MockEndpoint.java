package fr.recouv.securite.prisme.authzserver.endpoint;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import fr.recouv.securite.prisme.authzserver.bo.Dashboard;
import fr.recouv.securite.prisme.authzserver.bo.EntryConfig;
import fr.recouv.securite.prisme.authzserver.bo.EntryIDToken;
import fr.recouv.securite.prisme.authzserver.bo.EntryLogger;
import fr.recouv.securite.prisme.authzserver.bo.EntryToken;
import fr.recouv.securite.prisme.authzserver.bo.IDTokenStorable;
import fr.recouv.securite.prisme.authzserver.bo.JSONRequest;
import fr.recouv.securite.prisme.authzserver.bo.JSONResponse;
import fr.recouv.securite.prisme.authzserver.bo.Parametres;
import fr.recouv.securite.prisme.authzserver.bo.UserSession;
import fr.recouv.securite.prisme.authzserver.listener.PrismeServletSession;
import fr.recouv.securite.prisme.authzserver.mock.DashboardMock;
import fr.recouv.securite.prisme.authzserver.mock.EntryCacheMock;
import fr.recouv.securite.prisme.authzserver.mock.EntryConfigMock;
import fr.recouv.securite.prisme.authzserver.mock.EntryIDTokenMock;
import fr.recouv.securite.prisme.authzserver.mock.EntryTokenMock;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.config.bean.Config;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.AbstractToken;
import fr.recouv.securite.prisme.logger.PrismeLogger;

@Path("/mock/{version}")
public class MockEndpoint {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			MockEndpoint.class).build();

	@Context
	private HttpServletRequest request;

	// Ping

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String ping() {
		LOGGER.debug("ping");
		return "ping from MockEndpoint!";
	}

	// Dashboard

	@GET
	@Path("/dashboard/indicateur/all")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllIndicateurMock() {
		LOGGER.debug("> dashboard indicator all (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu Dashboard.");
		// Si utilisateur connecte
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation dashboard
			Dashboard dashboard = DashboardMock.getAllIndicators();
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(dashboard.toString());
		}
		return response.build();
	}

	@GET
	@Path("/dashboard/indicateur/refresh/{nom}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response refreshIndicateurMock(@PathParam("nom") String nom) {
		LOGGER.debug("> dashboard resfresh indicator (Mock), nom : " + nom);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu Dashboard.");
		// Si utilisateur connecte
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation dashboard
			Dashboard dashboard = DashboardMock.refreshIndicator(nom);
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(dashboard.toString());
		}
		return response.build();
	}

	@GET
	@Path("/dashboard/validateur/all")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllValidatorMock() {
		LOGGER.debug("> dashboard validator all (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu Dashboard.");
		// Si utilisateur connecte
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation dashboard
			Dashboard dashboard = DashboardMock.getAllValidators();
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(dashboard.toString());
		}
		return response.build();
	}

	@GET
	@Path("/dashboard/validateur/refresh/{nom}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response refreshValidatorMock(@PathParam("nom") String nom) {
		LOGGER.debug("> dashboard resfresh validator (Mock), nom : " + nom);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu Dashboard.");
		// Si utilisateur connecte
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation dashboard
			Dashboard dashboard = DashboardMock.refreshValidator(nom);
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(dashboard.toString());
		}
		return response.build();
	}

	// Token Store

	@GET
	@Path("/tokenStore/liste")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getListeTokenStoreMock() {
		LOGGER.debug("> tokenStore List (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu TokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Recuperation liste EntryToken
				List<EntryToken> liste = new ArrayList<EntryToken>();
				Map<String, AbstractToken> cacheMock = EntryTokenMock.cacheTokenMock();
				for (AbstractToken abstractToken : cacheMock.values()) {
					liste.add(new EntryToken(abstractToken));
				}
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"data\": " + liste + " }");
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception récupération du contenu TokenStore.");
			}
		}
		return response.build();
	}

	@GET
	@Path("/tokenStore/stats")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStatsTokenStoreMock() {
		LOGGER.debug("> tokenStore Stats (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération des stats pour TokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryTokenMock.stats());
		}
		return response.build();
	}

	@GET
	@Path("/tokenStore/start")
	@Produces(MediaType.APPLICATION_JSON)
	public Response startTokenStoreMock() {
		LOGGER.debug("> Start tokenStore (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur TokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryTokenMock.start());
		}
		return response.build();
	}

	@GET
	@Path("/tokenStore/stop")
	@Produces(MediaType.APPLICATION_JSON)
	public Response stopTokenStoreMock() {
		LOGGER.debug("> Stop tokenStore (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur TokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryTokenMock.stop());
		}
		return response.build();
	}

	// Config Store

	@GET
	@Path("/configStore/liste")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getListeConfigStoreMock() {
		LOGGER.debug("> configStore List (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu RegistryStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Recuperation liste EntryConfig
				List<EntryConfig> liste = new ArrayList<EntryConfig>();
				Map<String, Config> cacheMock = EntryConfigMock.cacheRegistryMock();
				for (Config config : cacheMock.values()) {
					liste.add(new EntryConfig(config));
				}
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"data\": " + liste + " }");
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception récupération du contenu RegistryStore.");
			}
		}
		return response.build();
	}

	@GET
	@Path("/configStore/stats")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStatsConfigStoreMock() {
		LOGGER.debug("> configStore Stats (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération des stats pour RegistryStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryConfigMock.stats());
		}
		return response.build();
	}

	@GET
	@Path("/configStore/start")
	@Produces(MediaType.APPLICATION_JSON)
	public Response startConfigStoreMock() {
		LOGGER.debug("> Start configStore (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur ConfigStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryConfigMock.start());
		}
		return response.build();
	}

	@GET
	@Path("/configStore/stop")
	@Produces(MediaType.APPLICATION_JSON)
	public Response stopConfigStoreMock() {
		LOGGER.debug("> Stop configStore (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur ConfigStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryConfigMock.stop());
		}
		return response.build();
	}

	// ID Token Store

	@GET
	@Path("/idTokenStore/liste")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getListeIDTokenStoreMock() {
		LOGGER.debug("> IDTokenStore List (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu IDTokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Recuperation liste EntryIDToken
				List<EntryIDToken> liste = new ArrayList<EntryIDToken>();
				Map<String, IDTokenStorable> cacheMock = EntryIDTokenMock.cacheIDTokenMock();
				for (IDTokenStorable idToken : cacheMock.values()) {
					liste.add(new EntryIDToken(idToken));
				}
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"data\": " + liste + " }");
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception récupération du contenu IDTokenStore.");
			}
		}
		return response.build();
	}

	@GET
	@Path("/idTokenStore/stats")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStatsIDTokenStoreMock() {
		LOGGER.debug("> IDTokenStore Stats (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération des stats pour IDTokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryIDTokenMock.stats());
		}
		return response.build();
	}

	@GET
	@Path("/idTokenStore/start")
	@Produces(MediaType.APPLICATION_JSON)
	public Response startIDTokenStoreMock() {
		LOGGER.debug("> Start IDTokenStore (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur IDTokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryIDTokenMock.start());
		}
		return response.build();
	}

	@GET
	@Path("/idTokenStore/stop")
	@Produces(MediaType.APPLICATION_JSON)
	public Response stopIDTokenStoreMock() {
		LOGGER.debug("> Stop IDTokenStore (Mock)");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur IDTokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(EntryIDTokenMock.stop());
		}
		return response.build();
	}

	// Revoke

	/**
	 * Revocation token. (Mock)
	 * 
	 * @param token
	 *            JSONRequest
	 * @return true si jeton supprime, false sinon
	 * @throws PrismeException
	 *             exception
	 */
	@POST
	@Path("/revokeToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse revokeTokenMock(JSONRequest token)
			throws PrismeException {
		LOGGER.debug("Revoke Token (Mock) : " + token.uid);
		JSONResponse response = new JSONResponse();
		if (token.uid != null && EntryTokenMock.contains(token.uid)) {
			EntryTokenMock.remove(token.uid);
			response.result = PrismeParams.TRUE;
		} else {
			response.result = PrismeParams.FALSE;
		}
		return response;
	}

	/**
	 * Revocation all token. (Mock)
	 * 
	 * @return true si token supprime, false sinon
	 * @throws PrismeException
	 *             exception
	 */
	@POST
	@Path("/revokeAllToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse revokeAllTokenMock() throws PrismeException {
		LOGGER.debug("Revoke All Token (Mock)");
		JSONResponse response = new JSONResponse();
		EntryTokenMock.removeAll();
		response.result = PrismeParams.TRUE;
		return response;
	}

	/**
	 * Revocation config. (Mock)
	 * 
	 * @param config
	 *            JSONRequest
	 * @return true si config supprime, false sinon
	 * @throws PrismeException
	 *             exception
	 */
	@POST
	@Path("/revokeConfig")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse revokeConfigMock(JSONRequest config) throws PrismeException {
		LOGGER.debug("Revoke Config (Mock) : " + config.nodeId);
		JSONResponse response = new JSONResponse();
		if (config.nodeId != null
				&& EntryConfigMock.contains(config.nodeId)) {
			EntryConfigMock.remove(config.nodeId);
			response.result = PrismeParams.TRUE;
		} else {
			response.result = PrismeParams.FALSE;
		}
		return response;
	}

	/**
	 * Revocation all config. (Mock)
	 * 
	 * @return true si config supprime, false sinon
	 * @throws PrismeException
	 *             exception
	 */
	@POST
	@Path("/revokeAllConfig")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse revokeAllConfigMock() throws PrismeException {
		LOGGER.debug("Revoke All Config (Mock)");
		JSONResponse response = new JSONResponse();
		EntryConfigMock.removeAll();
		response.result = PrismeParams.TRUE;
		return response;
	}

	/**
	 * Revocation ID Token. (Mock)
	 * 
	 * @param idToken
	 *            JSONRequest
	 * @return true si config supprime, false sinon
	 * @throws PrismeException
	 *             exception
	 */
	@POST
	@Path("/revokeIDToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse revokeIDTokenMock(JSONRequest idToken) throws PrismeException {
		LOGGER.debug("Revoke IDToken (Mock) : " + idToken.state);
		JSONResponse response = new JSONResponse();
		if (idToken.state != null
				&& EntryIDTokenMock.contains(idToken.state)) {
			EntryIDTokenMock.remove(idToken.state);
			response.result = PrismeParams.TRUE;
		} else {
			response.result = PrismeParams.FALSE;
		}
		return response;
	}

	/**
	 * Revocation all ID Token. (Mock)
	 * 
	 * @return true si config supprime, false sinon
	 * @throws PrismeException
	 *             exception
	 */
	@POST
	@Path("/revokeAllIDToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse revokeAllIDTokenMock() throws PrismeException {
		LOGGER.debug("Revoke All IDToken (Mock)");
		JSONResponse response = new JSONResponse();
		EntryIDTokenMock.removeAll();
		response.result = PrismeParams.TRUE;
		return response;
	}

	// Caches

	/**
	 * Liste du contenu cache. (Mock)
	 * 
	 * @param nom
	 *            identifiant du cache
	 * @return contenu du cache
	 */
	@GET
	@Path("/cache/{nom}/liste")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getListeDetailCache(@PathParam("nom") String nom) {
		LOGGER.debug("> cache List (Mock), nom : " + nom);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu pour le cache.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"data\": " + EntryCacheMock.liste(nom) + " }");
		}
		return response.build();
	}

	/**
	 * Stats cache. (Mock)
	 * 
	 * @param nom
	 *            identifiant du cache
	 * @return stats du cache
	 */
	@GET
	@Path("/cache/{nom}/stats")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDetailCacheStats(@PathParam("nom") String nom) {
		LOGGER.debug("> cache Stats (Mock), nom : " + nom);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération des stats pour le cache.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Construit Reponse
			response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(EntryCacheMock.stats(nom));
		}
		return response.build();
	}

	/**
	 * Revocation entree du cache. (Mock)
	 * 
	 * @param nom
	 *            identifiant du cache
	 * @param entry
	 *            JSONRequest
	 * @return true si entry supprime, false sinon
	 * @throws PrismeException
	 *             exception
	 */
	@POST
	@Path("/cache/{nom}/remove")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse removeEntryCacheMock(@PathParam("nom") String nom,
			JSONRequest entry) throws PrismeException {
		LOGGER.debug("Remove Entry Cache (Mock), nom : " + nom + ", entry : " + entry.key);
		JSONResponse response = new JSONResponse();
		if (entry.key != null) {
			EntryCacheMock.remove(nom, entry.key);
			response.result = PrismeParams.TRUE;
		} else {
			response.result = PrismeParams.FALSE;
		}
		return response;
	}

	/**
	 * Revocation tout le cache. (Mock)
	 * 
	 * @param nom
	 *            identifiant du cache
	 * @return true si entry supprime, false sinon
	 * @throws PrismeException
	 *             exception
	 */
	@POST
	@Path("/cache/{nom}/removeAll")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse removeAllEntryCacheMock(@PathParam("nom") String nom) throws PrismeException {
		LOGGER.debug("Remove All Entry Cache (Mock), nom : " + nom);
		JSONResponse response = new JSONResponse();
		if (nom != null) {
			EntryCacheMock.removeAll(nom);
			response.result = PrismeParams.TRUE;
		} else {
			response.result = PrismeParams.FALSE;
		}
		return response;
	}

	// Parametres

	@GET
	@Path("/parametres/liste")
	@Produces(MediaType.APPLICATION_JSON)
	public Parametres listeParametres() {
		LOGGER.debug("> listeParametres");
		Parametres parametres = new Parametres();
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Chargement parametres Mock
			parametres.setClusterName("localhost.pss.mock");
			parametres.setNodeName("mockNodeName");
			parametres.setBindAddr("127.0.0.1");
			parametres.setBindPort("8800");
			parametres.setInitialHost("127.0.0.1[8800]");
		}
		return parametres;
	}

	@GET
	@Path("/parametres/logger/liste")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getListeLogger() {
		LOGGER.debug("> Logger List ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu de la liste des Logger.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Recuperation liste Logger
			List<EntryLogger> liste = new ArrayList<EntryLogger>();
			// Ajout Entree Mock
			liste.add(new EntryLogger(0, "ROOT", "INFO"));
			liste.add(new EntryLogger(1, "fr.recouv.securite.prisme", "DEBUG"));
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity("{\"data\": " + liste + " }");
		}
		return response.build();
	}

	@POST
	@Path("/parametres/logger/edit")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public JSONResponse editLogger(JSONRequest logger)
			throws PrismeException {
		LOGGER.debug("> Edit Logger (Mock) : " + logger.name);
		JSONResponse response = new JSONResponse();
		if (!"ERROR".equals(logger.level)) {
			response.result = PrismeParams.TRUE;
		} else {
			response.result = PrismeParams.FALSE;
		}
		return response;
	}
}
