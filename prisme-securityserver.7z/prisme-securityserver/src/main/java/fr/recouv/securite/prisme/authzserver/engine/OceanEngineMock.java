package fr.recouv.securite.prisme.authzserver.engine;

import java.io.IOException;

import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.engine.IEngine;
import fr.recouv.securite.prisme.commun.utils.ScopeUtility;

/**
 * OceanEngineMock : <br>
 * 
 * Parse un jeton Ocean pour en extraire les informations. (Mock)
 */
public class OceanEngineMock implements IEngine {

	private String subject;
	private String issuer;
	private String audience;
	private String idStore;

	@Override
	public IEngine parse(PrismeTokenRequest prismeRequest)
			throws PrismeSystemException {
		// MOCK sur valeurs pour generer un Token valide
		// - Subject
		this.subject = "CER4495240";
		// - Issuer
		this.issuer = prismeRequest.getParam(PrismeParams.CLIENT_ID);
		// - Audience (scope request)
		this.audience = PrismeRequestScope.set()
				.add(PrismeRequestScope.ALL, "SNV2-PROD").encode();
		try {
			// - Id Store
			this.idStore = ScopeUtility.encodeIdStore(this.subject,
					this.issuer, "[" + this.audience + "]");
		} catch (IOException e) {
			throw new PrismeSystemException(ExceptionCode.INVALID,
					"Erreur lors de la generation de la cle de stockage");
		}
		return this;
	}

	@Override
	public String getSubject() {
		return this.subject;
	}

	@Override
	public String getIssuer() {
		return this.issuer;
	}

	@Override
	public String getAudience() {
		return this.audience;
	}

	@Override
	public String getIdStore() {
		return this.idStore;
	}

	@Override
	public String getScope() {
		return null;
	}
}
