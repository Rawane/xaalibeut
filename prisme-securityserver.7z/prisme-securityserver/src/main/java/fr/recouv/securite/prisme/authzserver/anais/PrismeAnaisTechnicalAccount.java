package fr.recouv.securite.prisme.authzserver.anais;

import javax.naming.NamingException;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisDN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisDescription;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisTechnicalAccount.
 */
public class PrismeAnaisTechnicalAccount {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisTechnicalAccount.class).build();

	private static final String CONTEXT_NAME_READER = "reader";
	private static final String CONTEXT_NAME_WRITER = "writer";

	/**
	 * byDN.
	 * 
	 * @param dn
	 *            String
	 * @return AnaisTechnicalAccount
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static AnaisTechnicalAccount byDN(String dn)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException, PrismeSystemException {
		LOGGER.debug("> byDN");
		// Recuperation AnaisDN
		final AnaisDN anaisDN = AnaisDN.set(dn);
		if (!anaisDN.isAnValidateDN()) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"AnaisDN non valide : " + dn);
		}
		// Recuperation Anais
		AnaisTechnicalAccount technicalAccount = AnaisTechnicalAccount.build
				.get(CONTEXT_NAME_READER).by(anaisDN).execute();
		return technicalAccount;
	}

	/**
	 * byAnaisDescription.
	 * 
	 * @param description
	 *            String
	 * @return AnaisTechnicalAccount
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static AnaisTechnicalAccount byAnaisDescription(String description)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException {
		LOGGER.debug("> byAnaisDescription");
		// Recuperation Anais
		AnaisTechnicalAccount technicalAccount = AnaisTechnicalAccount.build
				.get(CONTEXT_NAME_READER)
				.by(AnaisDescription.build(description)).execute();
		return technicalAccount;
	}

	/**
	 * save.
	 * 
	 * @param technicalAccount
	 *            AnaisTechnicalAccount
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static void save(AnaisTechnicalAccount technicalAccount)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException {
		LOGGER.debug("> save");
		AnaisTechnicalAccount.build.set(CONTEXT_NAME_WRITER)
				.with(technicalAccount).save();
	}
}
