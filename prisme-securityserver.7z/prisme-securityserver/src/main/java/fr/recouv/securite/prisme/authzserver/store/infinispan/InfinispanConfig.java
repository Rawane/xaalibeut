package fr.recouv.securite.prisme.authzserver.store.infinispan;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import org.infinispan.configuration.parsing.ConfigurationBuilderHolder;
import org.infinispan.configuration.parsing.ParserRegistry;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.manager.EmbeddedCacheManager;
import org.yaml.snakeyaml.Yaml;

import com.google.common.io.Resources;

import fr.recouv.securite.prisme.commun.config.business.YamlConfigurationLoader;
import fr.recouv.securite.prisme.commun.exceptions.PrismeConfigurationException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * Charge la config lié a Infinispan <br>
 * <ul>
 * <li>Soit par un fichier 'configInfinispan.yaml' passé en parametre system
 * 'prisme.configInfinispan'</li>
 * <li>Soit par systemProperty</li>
 * </ul>
 */
public class InfinispanConfig extends YamlConfigurationLoader {

	private static final PrismeLogger logger = new PrismeLogger().in(
			InfinispanConfig.class).build();

	private final static String DEFAULT_CONFIGURATION = "infinispanConfig.yaml";

	public String infinispan_clusterName;
	public String infinispan_nodeName;
	public String infinispan_tmp_directory;
	public String jgroups_bind_addr;
	public String jgroups_bind_port;
	public String jgroups_tcpping_initial_hosts;
	public String java_net_preferIPv4Stack;

	/**
	 * Chargement config
	 */
	public static void loadInfiniSpanConfig() {

		try {
			// Chargement fichier
			URL url = getStorageConfigURL("prisme.infinispanConfig",
					DEFAULT_CONFIGURATION);
			// Lecture Guava
			InputStream isGuava = Resources.asByteSource(url).openStream();
			// Parsing Yaml
			Yaml yaml = new Yaml();
			InfinispanConfig config = yaml.loadAs(isGuava,
					InfinispanConfig.class);
			// Chargement systemProperty
			loadSystemProperty("infinispan.clusterName",
					config.infinispan_clusterName);
			loadSystemProperty("infinispan.nodeName",
					config.infinispan_nodeName);
			loadSystemProperty("infinispan.tmp.directory",
					config.infinispan_tmp_directory);
			loadSystemProperty("jgroups.bind_addr", config.jgroups_bind_addr);
			loadSystemProperty("jgroups.bind_port", config.jgroups_bind_port);
			loadSystemProperty("jgroups.tcpping.initial_hosts",
					config.jgroups_tcpping_initial_hosts);
			loadSystemProperty("java.net.preferIPv4Stack",
					config.java_net_preferIPv4Stack);
		} catch (MalformedURLException e) {
			logger.error("Url yaml invalide : " + e.getMessage());
		} catch (IOException e) {
			logger.error("Fichier infinispan yaml invalide : " + e.getMessage());
		} catch (PrismeConfigurationException e) {
			logger.error("PrismeConfigurationException : " + e.getMessage());
		}
	}

	/**
	 * loadSystemProperty
	 * 
	 * @param name
	 *            String
	 * @param value
	 *            String
	 */
	private static void loadSystemProperty(String name, String value) {
		if (System.getProperty(name) == null
				|| System.getProperty(name).equals("")) {
			System.setProperty(name, value);
		}
	}

	/**
	 * @return EmbeddedCacheManager
	 * @throws IOException
	 *             exception
	 */
	public static EmbeddedCacheManager getCacheManager() throws IOException {

		// Chargement configuration
		loadInfiniSpanConfig();
		// Chargement fichier
		ParserRegistry parser = new ParserRegistry(
				InfinispanConfig.class.getClassLoader());
		String infinispanConfigFile = System.getProperty(
				"infinispan.config.filename", "infinispan.xml");
		// Creation cacheManager
		ConfigurationBuilderHolder configurationBuilder = parser.parseFile(infinispanConfigFile);
		EmbeddedCacheManager cacheManager = new DefaultCacheManager(
				configurationBuilder, false);
		return cacheManager;
	}
}
