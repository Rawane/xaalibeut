package fr.recouv.securite.prisme.authzserver.store;

/**
 * TokenStoreWithInfiniSpanCacheMBean.
 */
public interface TokenStoreWithInfiniSpanCacheMBean extends IStoreMBean {

	// Voir IStoreMBean
}
