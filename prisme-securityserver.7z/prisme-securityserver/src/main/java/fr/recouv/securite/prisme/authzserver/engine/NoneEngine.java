package fr.recouv.securite.prisme.authzserver.engine;

import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.engine.IEngine;

/**
 * NoneEngine <br>
 * 
 * Exception lancée si tentative d'utilisation d'une cinématique utilisant NoneEngine. 
 */
public class NoneEngine implements IEngine {

	@Override
	public IEngine parse(PrismeTokenRequest prismeRequest)
			throws PrismeSystemException {
		throw new PrismeSystemException(ExceptionCode.INVALID,
				"NoneEngine défini pour cette cinématique.");
	}

	@Override
	public String getSubject() {
		return null;
	}

	@Override
	public String getIssuer() {
		return null;
	}

	@Override
	public String getAudience() {
		return null;
	}

	@Override
	public String getIdStore() {
		return null;
	}

	@Override
	public String getScope() {
		return null;
	}
}
