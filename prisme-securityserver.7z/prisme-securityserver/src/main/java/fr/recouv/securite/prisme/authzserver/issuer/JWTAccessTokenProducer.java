package fr.recouv.securite.prisme.authzserver.issuer;

import java.security.interfaces.RSAPrivateKey;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisScope;
import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.consumer.ConsumerType;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.AbstractAccessToken;
import fr.recouv.securite.prisme.commun.token.AbstractRefreshToken;
import fr.recouv.securite.prisme.commun.token.JWTAccessToken;
import fr.recouv.securite.prisme.commun.token.reverse.JWTReverse;
import fr.recouv.securite.prisme.commun.token.simulator.DummyRefreshToken;

public class JWTAccessTokenProducer implements PrismeIssuer {

	PrismeTokenRequest prismeRequest;
	PrismeResponseScope scope;
	JWTReverse jwtReverse;

	/**
	 * Constructeur
	 * 
	 * @param prismeRequest
	 *            PrismeTokenRequest
	 * @throws PrismeSystemException
	 *             exception
	 */
	public JWTAccessTokenProducer(PrismeTokenRequest prismeRequest) throws PrismeSystemException {
		// Recuperation PrismeRequest
		this.prismeRequest = prismeRequest;
		// Recuperation du token en entree
		try {
			String jwtToken = this.prismeRequest
					.getParam(PrismeParams.ASSERTION);
			this.jwtReverse = JWTReverse.set(jwtToken).build();
		} catch (ParseException e) {
			// Exception lors du reverse du token
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					e.getMessage(), e);
		}
		// Determination Scope Cible
		this.scope = PrismeAnaisScope.getResponseScope(
				this.jwtReverse.getSubject(),
				this.prismeRequest.getScope());
	}

	@Override
	public AbstractAccessToken accessToken() throws PrismeSystemException {
		JWTAccessToken jwtAccessToken = new JWTAccessToken();
		try {
			// Generer JWTAccessToken
			jwtAccessToken.setJWTID(new MD5Generator().generateValue());
			jwtAccessToken.setIssuer(
					PrismeContexteDescriptor.nodeId() + "@" + PrismeContexteDescriptor.clientId());
			Date date = new Date();
			jwtAccessToken.setIssueTime(date);
			jwtAccessToken.setExpirationTime(
					DateUtils.addSeconds(
							date, PrismeSecurityServer.getTokenDelayedTimeInteger()));
			jwtAccessToken.setScope(getScope().encode());
			ConsumerType consumer = ConsumerType.set()
					.setSubject(this.jwtReverse.getSubject())
					.setClientId(this.jwtReverse.getIssuer()).build();
			jwtAccessToken.setSubject(consumer.serialize());
			jwtAccessToken.setCustomClaim(PrismeParams.ID_STORE, this.jwtReverse.getIdStore());

			// Signer JWTToken avec cle privee PSS
			// recuperation privateKey
			RSAPrivateKey privateKey = PrismeContexteDescriptor
					.getPrivateKeyFile();
			// signer avec privateKey
			jwtAccessToken.sign(privateKey);
		} catch (PrismeInvalidTokenException e) {
			// Exception lors de la signature
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la signature du JWTAccessToken", e);
		}
		return jwtAccessToken;
	}

	@Override
	public AbstractRefreshToken refreshToken() throws PrismeSystemException {
		return new DummyRefreshToken(new MD5Generator().generateValue());
	}

	@Override
	public PrismeResponseScope getScope() throws PrismeSystemException {
		return this.scope;
	}

	@Override
	public String getTokenType() {
		return PrismeParams.TOKEN.JWT_TYPE;
	}
	@Override
	public String getSubject() {		
		return jwtReverse.getSubject();
	}
}
