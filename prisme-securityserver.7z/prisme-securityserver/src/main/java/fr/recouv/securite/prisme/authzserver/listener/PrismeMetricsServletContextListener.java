/**
 * 
 */
package fr.recouv.securite.prisme.authzserver.listener;

import javax.servlet.annotation.WebListener;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.servlets.MetricsServlet;

/**
 * @author CER4495267
 * 
 */
@WebListener
public class PrismeMetricsServletContextListener extends
		MetricsServlet.ContextListener {

	public static final MetricRegistry METRIC_REGISTRY = new MetricRegistry();

	@Override
	protected MetricRegistry getMetricRegistry() {
		return METRIC_REGISTRY;
	}

}
