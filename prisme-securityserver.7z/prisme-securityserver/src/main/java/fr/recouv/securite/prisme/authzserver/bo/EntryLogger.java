package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import net.minidev.json.JSONObject;

import ch.qos.logback.classic.Logger;

/**
 * EntryLogger
 */
public class EntryLogger implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = -3698386140295094244L;

	// Attributs
	private int order;

	private String name;

	private String level;

	/**
	 * Constructeur simple.
	 */
	public EntryLogger() {
		super();
	}

	/**
	 * Constructeur depuis String.
	 * 
	 * @param order
	 *            int
	 * @param name
	 *            String
	 * @param level
	 *            String
	 */
	public EntryLogger(final int order, final String name, final String level) {
		this.order = order;
		this.name = name;
		this.level = level;
	}

	/**
	 * Constructeur depuis Logger.
	 * 
	 * @param order
	 *            int
	 * @param logger
	 *            Logger
	 */
	public EntryLogger(final int order, final Logger logger) {
		this.order = order;
		this.name = logger.getName();
		this.level = logger.getLevel().toString();
	}

	/**
	 * @return the order
	 */
	public final int getOrder() {
		return order;
	}

	/**
	 * @return the name
	 */
	public final String getName() {
		return this.name;
	}

	/**
	 * @return the level
	 */
	public final String getLevel() {
		return this.level;
	}

	@Override
	public String toString() {
		JSONObject response = new JSONObject();
		response.put("order", this.order);
		response.put("name", this.name);
		response.put("level", this.level);
		return response.toJSONString();
	}
}
