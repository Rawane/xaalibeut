package fr.recouv.securite.prisme.authzserver.endpoint;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.codahale.metrics.annotation.Timed;

import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.bo.JSONRequest;
import fr.recouv.securite.prisme.authzserver.bo.JSONResponse;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

@Path("/revoke/{version}")
public class RevokeEndpoint {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			RevokeEndpoint.class).build();

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Timed
	public String ping() {
		_logger.debug("ping");
		return "ping from RevokeEndpoint!";
	}

	/**
	 * Revocation config.
	 * 
	 * @param config
	 *            JSONRequest
	 * @return true si config supprime, false sinon
	 */
	@POST
	@Path("/revokeConfig")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse revokeConfig(JSONRequest config) {
		_logger.debug("Revoke Config:" + config.nodeId);
		JSONResponse response = new JSONResponse();
		response.result = PrismeParams.FALSE;
		try {
			if (config.nodeId != null
					&& PrismeSecurityServer.registryStore().contains(config.nodeId)) {
				PrismeSecurityServer.registryStore().remove(config.nodeId);
				response.result = PrismeParams.TRUE;
			}
		} catch (PrismeSystemException e) {
			_logger.error("PrismeSystemException: " + e.getMessage());
		} catch (PrismeException e) {
			_logger.error("PrismeException: " + e.getMessage());
		} catch (Exception e) {
			_logger.error("Exception: " + e.getMessage());
		}
		return response;
	}

	/**
	 * Revocation all config.
	 * 
	 * @return true si config supprime, false sinon
	 */
	@POST
	@Path("/revokeAllConfig")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse revokeAllConfig() {
		_logger.debug("Revoke All Config");
		JSONResponse response = new JSONResponse();
		response.result = PrismeParams.FALSE;
		try {
			PrismeSecurityServer.registryStore().removeAll();
			response.result = PrismeParams.TRUE;
		} catch (PrismeSystemException e) {
			_logger.error("PrismeSystemException: " + e.getMessage());
		} catch (PrismeException e) {
			_logger.error("PrismeException: " + e.getMessage());
		}
		return response;
	}

	/**
	 * Revocation token.
	 * 
	 * @param token
	 *            JSONRequest
	 * @return true si jeton supprime, false sinon
	 */
	@POST
	@Path("/revokeToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse revokeToken(JSONRequest token) {
		_logger.debug("Revoke Token:" + token.uid);
		JSONResponse response = new JSONResponse();
		response.result = PrismeParams.FALSE;
		try {
			if (token.uid != null
					&& PrismeSecurityServer.tokenStore().contains(token.uid)) {
				PrismeSecurityServer.tokenStore().remove(token.uid);
				response.result = PrismeParams.TRUE;
			}
		} catch (PrismeSystemException e) {
			_logger.error("PrismeSystemException: " + e.getMessage());
		} catch (PrismeException e) {
			_logger.error("PrismeException: " + e.getMessage());
		} catch (Exception e) {
			_logger.error("Exception: " + e.getMessage());
		}
		return response;
	}

	/**
	 * Revocation all token.
	 * 
	 * @return true si token supprime, false sinon
	 */
	@POST
	@Path("/revokeAllToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse revokeAllToken() {
		_logger.debug("Revoke All Token");
		JSONResponse response = new JSONResponse();
		response.result = PrismeParams.FALSE;
		try {
			PrismeSecurityServer.tokenStore().removeAll();
			response.result = PrismeParams.TRUE;
		} catch (PrismeSystemException e) {
			_logger.error("PrismeSystemException: " + e.getMessage());
		} catch (PrismeException e) {
			_logger.error("PrismeException: " + e.getMessage());
		}
		return response;
	}

	/**
	 * Revocation ID Token.
	 * 
	 * @param idToken
	 *            JSONRequest
	 * @return true si config supprime, false sinon
	 */
	@POST
	@Path("/revokeIDToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse revokeIDToken(JSONRequest idToken) {
		_logger.debug("Revoke IDToken:" + idToken.state);
		JSONResponse response = new JSONResponse();
		response.result = PrismeParams.FALSE;
		try {
			if (idToken.state != null
					&& PrismeSecurityServer.idTokenStore().contains(idToken.state)) {
				PrismeSecurityServer.idTokenStore().remove(idToken.state);
				response.result = PrismeParams.TRUE;
			}
		} catch (PrismeSystemException e) {
			_logger.error("PrismeSystemException: " + e.getMessage());
		} catch (PrismeException e) {
			_logger.error("PrismeException: " + e.getMessage());
		} catch (Exception e) {
			_logger.error("Exception: " + e.getMessage());
		}
		return response;
	}

	/**
	 * Revocation all ID Token.
	 * 
	 * @return true si config supprime, false sinon
	 */
	@POST
	@Path("/revokeAllIDToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse revokeAllIDToken() {
		_logger.debug("Revoke All IDToken");
		JSONResponse response = new JSONResponse();
		response.result = PrismeParams.TRUE;
		try {
			PrismeSecurityServer.idTokenStore().removeAll();
			response.result = PrismeParams.TRUE;
		} catch (PrismeSystemException e) {
			_logger.error("PrismeSystemException: " + e.getMessage());
		} catch (PrismeException e) {
			_logger.error("PrismeException: " + e.getMessage());
		}
		return response;
	}
}
