package fr.recouv.securite.prisme.authzserver.issuer;

import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAuthenticator;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisScope;
import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.consumer.ConsumerType;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.AbstractAccessToken;
import fr.recouv.securite.prisme.commun.token.AbstractRefreshToken;
import fr.recouv.securite.prisme.commun.token.AccessPrismeToken;
import fr.recouv.securite.prisme.commun.token.simulator.DummyRefreshToken;

public class ConsumerAccessTokenProducer implements PrismeIssuer {

	PrismeTokenRequest prismeRequest;
	PrismeResponseScope scope;
	private String subject;

	/**
	 * Constructeur
	 * 
	 * @param prismeRequest
	 *            PrismeTokenRequest
	 * @throws PrismeSystemException
	 *             exception
	 */
	public ConsumerAccessTokenProducer(PrismeTokenRequest prismeRequest) throws PrismeSystemException {
		this.prismeRequest = prismeRequest;
		// Authentification sur Anais
		String username = this.prismeRequest.getParam(PrismeParams.USERNAME);
		String password = this.prismeRequest.getParam(PrismeParams.PWD);
		subject=username;
		// Exception lancée si authentification echouée sur Anais
		PrismeAnaisAuthenticator.authenticateUser(username, password);
		// Scope
		this.scope = PrismeAnaisScope.getResponseScope(
				prismeRequest.getParam(PrismeParams.USERNAME),
				prismeRequest.getScope());
	}

	@Override
	public AbstractAccessToken accessToken() throws PrismeSystemException {
		// TODO
		// Consumer
		ConsumerType consumer = ConsumerType
				.set()
				.setSubject(this.prismeRequest.getParam(PrismeParams.USERNAME))
				.setClientId(
						this.prismeRequest.getParam(PrismeParams.CLIENT_ID))
				.build();
		return AccessPrismeToken.set(new MD5Generator().generateValue())
//				.setSubject(consumer.serialize())
//				.setScope(this.getScope())
				.build();
	}

	@Override
	public AbstractRefreshToken refreshToken() throws PrismeSystemException {
		// TODO
		return new DummyRefreshToken(new MD5Generator().generateValue());
	}

	@Override
	public PrismeResponseScope getScope() throws PrismeSystemException {
		return scope;
	}

	@Override
	public String getTokenType() {
		return PrismeParams.TOKEN.JSON_TYPE;
	}
	/* (non-Javadoc)
	 * @see fr.recouv.securite.prisme.authzserver.issuer.PrismeIssuer#getSubject()
	 */
	@Override
	public String getSubject() {		
		return subject;
	}
}
