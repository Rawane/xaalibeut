package fr.recouv.securite.prisme.authzserver.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.annotation.WebListener;

import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.logger.PrismeLogger;

@WebListener
public class PrismeServletContextListener implements
		javax.servlet.ServletContextListener {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			PrismeServletContextListener.class).build();

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		_logger.debug("-- ContextInitialized --");
		PrismeContexteDescriptor.start();
		PrismeSecurityServer.start();
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		_logger.debug("-- ContextDestroyed --");
		if (PrismeContexteDescriptor.getHttpClient() != null) {
			PrismeContexteDescriptor.getHttpClient().shutdown();
		}
		PrismeSecurityServer.stop();
	}
}
