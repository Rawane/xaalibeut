package fr.recouv.securite.prisme.authzserver.store;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisApplication;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * AnaisAppsStoreWithGuavaCache. <br>
 * 
 * Cache Local d objet applications Anais <br>
 * - Si absent, recuperation depuis Anais <br>
 */
public class AnaisAppsStoreWithGuavaCache implements IStore {

	private static final PrismeLogger logger = new PrismeLogger().in(
			AnaisAppsStoreWithGuavaCache.class).build();

	private static LoadingCache<String, AnaisApplication> cache;

	private static final long expireAfterWrite = 21600;

	/**
	 * Constructeur.
	 */
	public AnaisAppsStoreWithGuavaCache() {
		// Init cache
		cache = CacheBuilder.newBuilder().recordStats()
				.expireAfterWrite(expireAfterWrite, TimeUnit.SECONDS)
				.build(new CacheLoader<String, AnaisApplication>() {
					@Override
					public AnaisApplication load(String cn)
							throws PrismeSystemException {
						return loadApplicationFromAnais(cn);
					}
				});
	}

	@Override
	public List<EntryCache> list() {
		List<EntryCache> liste = new ArrayList<EntryCache>();
		for (String key : cache.asMap().keySet()) {
			liste.add(new EntryCache(key, (AnaisApplication) cache.asMap().get(key)));
		}
		return liste;
	}

	@Override
	public String stats() {
		return CacheStatsUtility
				.getStatsFromGuavaCache(cache, expireAfterWrite);
	}

	@Override
	public int size() {
		if (cache != null) {
			return cache.asMap().size();
		}
		return 0;
	}

	@Override
	public void remove(final String key) {
		cache.invalidate(key);
	}

	@Override
	public void removeAll() {
		cache.invalidateAll();
	}

	/**
	 * Recupere AnaisApplication en fonction de cn.
	 * 
	 * @param cn
	 *            String
	 * @return AnaisApplication
	 * @throws PrismeSystemException
	 *             exception
	 */
	public AnaisApplication get(String cn) throws PrismeSystemException {
		try {
			// Recuperation depuis cache
			logger.debug("Recuperation AnaisApplication par cn:" + cn);
			return cache.get(cn);
		} catch (ExecutionException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de l'application sur Anais.");
		}
	}

	/**
	 * Enrichissment du magasin locale des applications.
	 * 
	 * @param codeAppli
	 *            - cn de l application String
	 * @return AnaisApplication un objet AnaisApplication
	 * @throws PrismeSystemException
	 *             exception
	 */
	private static AnaisApplication loadApplicationFromAnais(String codeAppli)
			throws PrismeSystemException {
		logger.debug("Enrichissement du store pour CN:" + codeAppli);
		try {
			// Recuperation Anais
			AnaisApplication anaisApplication = PrismeAnaisApplication
					.getApplicationByCN(codeAppli);
			// Si application null, exception
			if (anaisApplication == null) {
				logger.error("Exception lors de la recuperation Anais : application inconnue");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur Anais dans le chargement de l'application.");
			}
			// Retour
			return anaisApplication;
		} catch (NamingException e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (AnaisExceptionFailure e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		}
	}
}
