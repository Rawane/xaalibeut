package fr.recouv.securite.prisme.authzserver.mock;

import java.util.ArrayList;
import java.util.List;

import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisUID;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.bo.Application;

/**
 * PrismeAnaisMock : pour palier indispo Anais.
 */
public class PrismeAnaisMock {

	/**
	 * Active / Desactive le Mock
	 */
	private static final boolean actif = false;

	/**
	 * @return anaisUser
	 */
	public static AnaisUser mockAnaisUser() {
		if (actif) {
			AnaisUser anaisUser = new AnaisUser();
			anaisUser.setCn(AnaisCN.build("MOCKVID FERREIRA"));
			anaisUser.setUid(AnaisUID.build("CER4495240"));
			return anaisUser;
		} else {
			return null;
		}
	}

	/**
	 * @return List AnaisAccessRightInstance
	 */
	public static List<AnaisAccessRightInstance> mockListAnaisHabilitation() {
		if (actif) {
			// Mode bouchonne
			List<AnaisAccessRightInstance> listAnaisHabilitation = new ArrayList<AnaisAccessRightInstance>();
			AnaisAccessRightInstance ari = new AnaisAccessRightInstance();
			ari.setCn(AnaisCN.build("ADMINSECU"));
			listAnaisHabilitation.add(ari);
			return listAnaisHabilitation;
		} else {
			return null;
		}
	}

	/**
	 * @return List Application
	 */
	public static List<Application> mockListeApplication() {
		List<Application> listeApplication = new ArrayList<Application>();
		if (actif) {
			// Mode bouchonne
			Application application = new Application();
			application.setHwiCN("hwi_mixte-mock");
			listeApplication.add(application);
		}
		return listeApplication;
	}

	/**
	 * @return Application
	 */
	public static Application mockApplication() {
		Application application = new Application();
		if (actif) {
			// Mode bouchonne
			application.setHwiCN("hwi_mixte-mock");
			application.setClientId("cn=USR_READ_NAT_APP_MIXTE-MOCK,ou=MIXTE-MOCK,ou=Applications,ou=Technique,dc=recouv");
			application.setKeyOcean("MOCK_KEY_OCEAN");
			application.setKeyPrismePublic("");
		}
		return application;
	}
}
