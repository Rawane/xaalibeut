package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;
import java.util.Date;

import net.minidev.json.JSONObject;

import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisUtility;
import fr.recouv.securite.prisme.commun.config.bean.Config;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;

/**
 * EntryConfig.
 */
public class EntryConfig implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = -4616944965786753206L;

	private String nodeId;

	private String version;

	private String authenticator;

	private String authorizer;

	private String clientId;

	private String clientIdFull;

	private String httpClient;

	private String endpoint;

	private String tokenStore;

	private String identityStore;

	private String permissionsStore;

	private String jmxActivated;

	private String securityOptions;

	private String providerPermissionsLoader;

	private String providerPermissionsFile;

	private String permissionsCacheMaxEntries;

	private String permissionsValidityInS;

	private String identityCacheMaxEntries;

	private String identityValidityInS;

	private String tokenCacheMaxEntries;

	private String tokenValidityInS;

	private Date registryDate;

	private String pssNodeId;

	/**
	 * Constructeur simple.
	 */
	public EntryConfig() {
		super();
	}

	/**
	 * Constructeur.
	 * 
	 * @param config
	 *            Config
	 * @throws PrismeSystemException
	 *             exception
	 */
	public EntryConfig(final Config config) throws PrismeSystemException {
		// Recuperation valeurs
		this.nodeId = config.nodeId;
		this.version = config.version;
		this.authenticator = this.formatClass(config.authenticator);
		this.authorizer = this.formatClass(config.authorizer);
		this.clientId = this.formatClientId(config.client_id);
		this.clientIdFull = config.client_id;
		this.httpClient = this.formatClass(config.http_client);
		this.endpoint = this.formatEndpoint(config.token_endpoint);
		this.tokenStore = this.formatClass(config.token_store);
		this.identityStore = this.formatClass(config.identity_store);
		this.permissionsStore = this.formatClass(config.permissions_store);
		this.jmxActivated = config.jmx_activated;
		this.securityOptions = config.security_options;
		this.providerPermissionsLoader = this.formatClass(config.provider_permissions_loader);
		this.providerPermissionsFile = config.provider_permissions_file;
		this.permissionsCacheMaxEntries = this.formatInt(config.permissions_cache_max_entries);
		this.permissionsValidityInS = this.formatInt(config.permissions_validity_in_s);
		this.identityCacheMaxEntries = this.formatInt(config.identity_cache_max_entries);
		this.identityValidityInS = this.formatInt(config.identity_validity_in_s);
		this.tokenCacheMaxEntries = this.formatInt(config.token_cache_max_entries);
		this.tokenValidityInS = this.formatInt(config.token_validity_in_s);
		this.registryDate = config.registry_date;
		this.pssNodeId = config.pss_nodeId;
	}

	/**
	 * format.
	 * 
	 * @param entry
	 *            String
	 * @return String
	 */
	private String formatClass(final String entry) {
		if (entry != null) {
			if (entry.lastIndexOf(".") != -1) {
				return entry.substring(entry.lastIndexOf(".") + 1,
						entry.length());
			} else {
				return entry;
			}
		} else {
			return "";
		}
	}

	/**
	 * formatClient.
	 * 
	 * @param entry
	 *            String
	 * @return String
	 */
	private String formatClientId(final String entryClientId) {
		if (entryClientId != null) {
			return PrismeAnaisUtility.extractCodeApplication(entryClientId);
		} else {
			return "";
		}
	}

	/**
	 * formatEndpoint.
	 * 
	 * @param entryEndpoint
	 *            String
	 * @return String
	 */
	private String formatEndpoint(final String entryEndpoint) {
		if (entryEndpoint != null) {
			final int posEndpoint = entryEndpoint.indexOf("endpoint/");
			if (posEndpoint != -1) {
				return entryEndpoint.substring(0, posEndpoint);
			} else {
				return entryEndpoint;
			}
		} else {
			return "";
		}
	}

	/**
	 * formatInt.
	 * 
	 * @param entry
	 *            int
	 * @return String
	 */
	private String formatInt(final int entry) {
		return Integer.toString(entry);
	}

	@Override
	public String toString() {
		JSONObject response = new JSONObject();
		response.put("nodeId", this.nodeId);
		response.put("version", this.version);
		if (this.registryDate != null) {
			response.put("registryDate", this.registryDate.getTime());
		}
		response.put("authenticator", this.authenticator);
		response.put("authorizer", this.authorizer);
		response.put("clientId", this.clientId);
		response.put("clientIdFull", this.clientIdFull);
		response.put("httpClient", this.httpClient);
		response.put("endpoint", this.endpoint);
		response.put("tokenStore", this.tokenStore);
		response.put("identityStore", this.identityStore);
		response.put("permissionsStore", this.permissionsStore);
		response.put("jmxActivated", this.jmxActivated);
		response.put("securityOptions", this.securityOptions);
		response.put("providerPermissionsLoader", this.providerPermissionsLoader);
		response.put("providerPermissionsFile", this.providerPermissionsFile);
		response.put("permissionsCacheMaxEntries", this.permissionsCacheMaxEntries);
		response.put("permissionsValidityInS", this.permissionsValidityInS);
		response.put("identityCacheMaxEntries", this.identityCacheMaxEntries);
		response.put("identityValidityInS", this.identityValidityInS);
		response.put("tokenCacheMaxEntries", this.tokenCacheMaxEntries);
		response.put("tokenValidityInS", this.tokenValidityInS);
		response.put("pssNodeId", this.pssNodeId);
		return response.toJSONString();
	}
}
