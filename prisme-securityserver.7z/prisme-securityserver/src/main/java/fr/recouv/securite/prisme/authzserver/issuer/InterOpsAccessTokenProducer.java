package fr.recouv.securite.prisme.authzserver.issuer;

import java.security.interfaces.RSAPrivateKey;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.consumer.ConsumerType;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.AbstractAccessToken;
import fr.recouv.securite.prisme.commun.token.AbstractRefreshToken;
import fr.recouv.securite.prisme.commun.token.JWTAccessToken;
import fr.recouv.securite.prisme.commun.token.engine.IEngine;
import fr.recouv.securite.prisme.commun.token.simulator.DummyRefreshToken;

public class InterOpsAccessTokenProducer implements PrismeIssuer {

	PrismeResponseScope scope;
	IEngine interOpsEngine;

	/**
	 * Constructeur
	 * 
	 * @param prismeRequest
	 *            PrismeTokenRequest
	 * @throws PrismeSystemException
	 *             exception
	 */
	public InterOpsAccessTokenProducer(PrismeTokenRequest prismeRequest)
			throws PrismeSystemException {
		// InterOpsEngine
		this.interOpsEngine = PrismeSecurityServer.getInterOpsEngine().parse(
				prismeRequest);
		// Determination Scope Cible
		this.scope = PrismeResponseScope.set()
				.addScopeComplete(this.interOpsEngine.getScope()).build();
	}

	@Override
	public AbstractAccessToken accessToken() throws PrismeSystemException {
		JWTAccessToken jwtAccessToken = new JWTAccessToken();
		try {
			// Generer JWTAccessToken
			jwtAccessToken.setJWTID(new MD5Generator().generateValue());
			jwtAccessToken.setIssuer(PrismeSecurityServer.getIssuer());
			Date date = new Date();
			jwtAccessToken.setIssueTime(date);
			jwtAccessToken.setExpirationTime(DateUtils.addSeconds(date,
					PrismeSecurityServer.getTokenDelayedTimeInteger()));
			jwtAccessToken.setScope(getScope().encode());
			ConsumerType consumer = ConsumerType.set()
					.setSubject(this.interOpsEngine.getSubject())
					.setClientId(this.interOpsEngine.getIssuer()).build();
			jwtAccessToken.setSubject(consumer.serialize());
			jwtAccessToken.setCustomClaim(PrismeParams.ID_STORE,
					this.interOpsEngine.getIdStore());

			// Signer JWTToken avec cle privee PSS
			// recuperation privateKey
			RSAPrivateKey privateKey = PrismeSecurityServer.getPrivateKeyFile();
			// signer avec privateKey
			jwtAccessToken.sign(privateKey);
		} catch (PrismeInvalidTokenException e) {
			// Exception lors de la signature
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la signature du JWTAccessToken", e);
		}
		return jwtAccessToken;
	}

	@Override
	public AbstractRefreshToken refreshToken() throws PrismeSystemException {
		return new DummyRefreshToken(new MD5Generator().generateValue());
	}

	@Override
	public PrismeResponseScope getScope() throws PrismeSystemException {
		return this.scope;
	}

	@Override
	public String getTokenType() {
		return PrismeParams.TOKEN.JWT_TYPE;
	}
	@Override
	public String getSubject() {		
		return interOpsEngine.getSubject();
	}
}
