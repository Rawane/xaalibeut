package fr.recouv.securite.prisme.authzserver.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.recouv.securite.prisme.authzserver.bo.UserSession;
import fr.recouv.securite.prisme.authzserver.listener.PrismeServletSession;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeFilter.
 */
public class PrismeFilter implements Filter {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeFilter.class).build();

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// Ne rien faire
		LOGGER.debug("> init");
	}

	@Override
	public void doFilter(ServletRequest servletRequest,
			ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {

		// Recuperation request
		HttpServletRequest request = ((HttpServletRequest) servletRequest);
		// Recuperation path
		String path = request.getRequestURI();
		// Recuperation parametre action
		String paramAction = "null";
		if (request.getParameter("action") != null) {
			paramAction = request.getParameter("action");
		}
		// Recuperation userSession
		UserSession userSession = PrismeServletSession.getUserSession(request);
		String anaisUserUid = "null";
		if (userSession != null) {
			anaisUserUid = userSession.getIdentifiant();
		}
		LOGGER.debug(" > doFilter, path: " + path + ", action: " + paramAction + ", user: " + anaisUserUid);
		// Utilisateur connecte et access page login sans paramAction
		if (userSession != null && path.endsWith("/ihm/login.jsp") && paramAction.equals("null")) {
			// Redirection vers dashboard
			String urlLogin = path.substring(0, path.indexOf("/ihm/")) + "/ihm/dashboard.jsp";
			((HttpServletResponse) servletResponse).sendRedirect(urlLogin);
			LOGGER.debug(" - redirection:" + urlLogin);
			return;
		}
		// Utilisateur non connecte et access page securise
		if (userSession == null
				&& !path.endsWith("/ihm/login.jsp")) {
			// Calcul doRedirect
			String doRedirect = "&doRedirect=" + path.substring(path.indexOf("/ihm/") + 5);
			// Redirection vers urlLogin
			String urlLogin = path.substring(0, path.indexOf("/ihm/")) + "/ihm/login.jsp?action=required_auth" + doRedirect;
			((HttpServletResponse) servletResponse).sendRedirect(urlLogin);
			LOGGER.debug(" - redirection:" + urlLogin);
			return;
		}
		// Propagation chain
		filterChain.doFilter(servletRequest, servletResponse) ;
	}

	@Override
	public void destroy() {
		// Ne rien faire
		LOGGER.debug("> destroy");
	}
}
