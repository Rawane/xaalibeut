package fr.recouv.securite.prisme.authzserver.endpoint;

import java.text.ParseException;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.codahale.metrics.annotation.Timed;

import fr.recouv.securite.prisme.authzserver.bo.JSONRequest;
import fr.recouv.securite.prisme.authzserver.bo.JSONResponse;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.AbstractPermission;
import fr.recouv.securite.prisme.commun.claims.ActionUnitaire;
import fr.recouv.securite.prisme.commun.claims.consumer.ConsumerType;
import fr.recouv.securite.prisme.commun.claims.consumer.IConsumer;
import fr.recouv.securite.prisme.commun.claims.resource.IResource;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeDenyOperationException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.response.PrismeResponse;
import fr.recouv.securite.prisme.commun.security.service.JWTTokenService;
import fr.recouv.securite.prisme.commun.token.JWTAccessToken;
import fr.recouv.securite.prisme.commun.token.reverse.JWTReverse;
import fr.recouv.securite.prisme.commun.utils.StringUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;
import fr.recouv.securite.prisme.resourceserver.authorizer.IAuthorizer;
import fr.recouv.securite.prisme.resourceserver.authorizer.WithDualModeAuthorizer;

@Path("/pdp/{version}")
public class PdpEndpoint {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			PdpEndpoint.class).build();

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Timed
	public String ping() {
		_logger.debug("ping");
		return "ping from PdpEndpoint!";
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response pdp(JSONRequest entry) throws PrismeException {
		_logger.debug("-- Policy Decision Point (PDP) --");
		// Par defaut
		JSONResponse response = new JSONResponse();
		response.result = "Erreur dans le traitement de la requete";
		int status = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
		try {
			// Patch DSN
			if (StringUtility.isNullOrEmpty(entry.routage_perimetre)) {
				entry.routage_perimetre = "DEFAULT";
			}
			// Traitement parametres entrees
			_logger.debug("routage_servicename: " + entry.routage_servicename);
			_logger.debug("routage_perimetre: " + entry.routage_perimetre);
			_logger.debug("assertion: " + entry.assertion);

			// Traitement assertion
			final JWTAccessToken token = new JWTAccessToken(entry.assertion);

			// Validation signature
			boolean isVerify = JWTTokenService.verifier(
					token.getJWT(), PrismeContexteDescriptor.getPublicKeyFile());
			_logger.info("Validation par cle public PSS : " + isVerify);
			if (!isVerify) {
				_logger.error("Erreur lors de la verification du token");
				// Lancement exception
				throw new PrismeInvalidTokenException(ExceptionCode.SECURITY,
						"Erreur lors de la verification du token");
			}

			// Validation dateExpiration
			try {
				JWTReverse jwtReverse = new JWTReverse(token.value());
				if (jwtReverse.getExpirationTime() == null) {
					_logger.error("ExpirationTime du token non défini");
					// Lancement exception
					throw new PrismeInvalidTokenException(ExceptionCode.SECURITY,
							"ExpirationTime du token non défini");
				} else if (!(new Date()).before(jwtReverse.getExpirationTime())) {
					_logger.error("ExpirationTime du token dépassé : " + jwtReverse.getExpirationTime());
					// Lancement exception
					throw new PrismeInvalidTokenException(ExceptionCode.SECURITY,
							"ExpirationTime du token dépassé");
				} else {
					_logger.info("ExpirationTime du token correct : " + jwtReverse.getExpirationTime());
				}
			} catch (ParseException e) {
				_logger.error("Exception : " + e.getMessage());
				// Lancement exception
				throw new PrismeInvalidTokenException(
						ExceptionCode.FUNCTION_FAILURE, e.getMessage());
			}

			// Action Unitaire
			AbstractPermission operation = ActionUnitaire
					.set(entry.routage_servicename)
					.addPerimetre(entry.routage_perimetre).build();
			// Consumer
			IConsumer consumer = ConsumerType.set()
					.setConsumer(token.getSubject())
					.setScope(token.getScope()).build();
			// Resource
			IResource resource = null;
			try {
				// Appel Authorizer
				IAuthorizer authorizer = new WithDualModeAuthorizer();
				authorizer.authorize(consumer, resource, operation);
				// Response Success
				response.result = PrismeParams.TRUE;
				status = HttpServletResponse.SC_OK;
			} catch (PrismeDenyOperationException e) {
				_logger.error("Erreur DenyOperationException : " + e.getMessage());
				return onProtocoleError("deny_operation_exception", e.getMessage());
			}
		} catch (PrismeInvalidTokenException e) {
			_logger.error("PrismeInvalidTokenException : " + e.getMessage());
			return onProtocoleError("invalid_token_exception", e.getMessage());
		}

		// Retour
		return Response
				.status(status)
				.entity(response)
				.build();
	}

	/**
	 * @param code
	 *            String
	 * @param msg
	 *            String
	 * @return Response
	 * @throws PrismeSystemException
	 */
	private Response onProtocoleError(final String code, final String msg)
			throws PrismeSystemException {
		final PrismeResponse response = PrismeResponse
				.onError(HttpServletResponse.SC_BAD_REQUEST).setErrorCode(code)
				.setErrorMessage(msg).buildJSONMessage();
		return Response.status(response.getResponseStatus())
				.entity(response.getBody()).build();
	}

}
