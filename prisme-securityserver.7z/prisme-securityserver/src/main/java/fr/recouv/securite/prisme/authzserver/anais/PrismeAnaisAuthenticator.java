package fr.recouv.securite.prisme.authzserver.anais;

import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.mock.PrismeAnaisMock;
import fr.recouv.securite.prisme.authzserver.store.AnaisClientStoreWithGuavaCache;
import fr.recouv.securite.prisme.authzserver.store.StoreManager;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisAuthenticator <br>
 * 
 * Fournit les methodes d'authentification pour un client et un user sur Anais.
 */
public class PrismeAnaisAuthenticator {

	private static final PrismeLogger logger = new PrismeLogger().in(
			PrismeAnaisAuthenticator.class).build();

	private static String CN = "PRISME-PSS";

	private static AnaisClientStoreWithGuavaCache client = StoreManager.anaisClientStore;

	/**
	 * AuthenticateClient.
	 * 
	 * @param clientId
	 *            String
	 * @param clientSecret
	 *            String
	 * @return AnaisApplication anaisApplication
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static AnaisApplication authenticateClient(String clientId,
			String clientSecret) throws PrismeSystemException {
		logger.debug(">>> Authentification Anais Client, clientId:" + clientId
				+ ", clientSecret");
		AnaisApplication anaisApplication = client.get(clientId, clientSecret);
		logger.debug("<<< Authentification Anais Client success.");
		return anaisApplication;
	}

	/**
	 * AuthenticateUser.
	 * 
	 * @param userId
	 *            String
	 * @param userSecret
	 *            String
	 * @return AnaisUser anaisUser
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static AnaisUser authenticateUser(String userId, String userSecret)
			throws PrismeSystemException {
		AnaisUser anaisUser = null;
		try {
			logger.debug(">>> Authentification Anais User, userId:" + userId);
			anaisUser = PrismeAnaisUser.withAccount(userId, userSecret);
			logger.debug("<<< Authentification Anais User success.");
		} catch (AnaisExceptionFailure e) {
			logger.error("AnaisExceptionFailure: " + e.getMessage());
		} catch (NamingException e) {
			logger.error("NamingException: " + e.getMessage());
			// Mock Anais si NamingException
			anaisUser = PrismeAnaisMock.mockAnaisUser();
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("AnaisExceptionServerCommunication: " + e.getMessage());
		} finally {
			if (anaisUser == null) {
				logger.error("<<< Authentification Anais User failed !");
				throw new PrismeSystemException(ExceptionCode.SECURITY,
						"Erreur lors de l'authentification sur Anais.");
			}
		}
		return anaisUser;
	}

	/**
	 * Retourne la liste des profils de AnaisUser sur PrismePSS.
	 * 
	 * @param anaisUser
	 *            AnaisUser
	 * @return List AnaisAccessRightInstance
	 */
	public static List<AnaisAccessRightInstance> listeHabilitationsPrisme(
			final AnaisUser anaisUser) {
		AnaisApplication anaisApplication = null;
		List<AnaisAccessRightInstance> listAnaisHabilitation = null;
		try {
			anaisApplication = PrismeAnaisApplication.getApplicationByCN(CN);
			if (anaisApplication != null) {
				List<AnaisOrgCode> listOfOrgCode = new ArrayList<AnaisOrgCode>();
				listOfOrgCode.add(AnaisOrgCode.build(anaisUser.getOu().value()));
				listAnaisHabilitation = PrismeAnaisAccessRightInstance.listeAccessRightByUserAppCodeOrg(
						anaisUser, anaisApplication, listOfOrgCode);
			}
		} catch (AnaisExceptionFailure e) {
			logger.error("AnaisExceptionFailure: " + e.getMessage());
		} catch (NamingException e) {
			logger.error("NamingException: " + e.getMessage());
			// Mock Anais si NamingException
			listAnaisHabilitation = PrismeAnaisMock.mockListAnaisHabilitation();
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("AnaisExceptionServerCommunication: " + e.getMessage());
		}
		return listAnaisHabilitation;
	}
}
