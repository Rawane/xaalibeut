package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;
import java.util.Date;

import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;

import net.minidev.json.JSONObject;

/**
 * EntryIDToken.
 */
public class EntryIDToken implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = -768897262421562868L;

	private String state;

	private String audience;

	private String subject;

	private String name;

	private String email;

	private String nonce;

	private Date issueTime;

	private Date expirationTime;

	/**
	 * Constructeur simple.
	 */
	public EntryIDToken() {
		super();
	}

	/**
	 * Constructeur.
	 * 
	 * @param idTokenStorable
	 *            IDTokenStorable
	 * @throws PrismeSystemException
	 *             exception
	 */
	public EntryIDToken(final IDTokenStorable idTokenStorable) throws PrismeSystemException {
		// Recuperation valeurs
		this.state = idTokenStorable.state;
		this.audience = idTokenStorable.idToken.getAudience().get(0);
		this.subject = idTokenStorable.idToken.getSubject();
		this.name = idTokenStorable.idToken.getName();
		this.email = idTokenStorable.idToken.getEmail();
		this.nonce = idTokenStorable.idToken.getNonce();
		this.issueTime = idTokenStorable.idToken.getIssueTime();
		this.expirationTime = idTokenStorable.idToken.getExpirationTime();
	}

	@Override
	public String toString() {
		JSONObject response = new JSONObject();
		response.put("state", this.state);
		response.put("audience", this.audience);
		response.put("subject", this.subject);
		response.put("name", this.name);
		response.put("email", this.email);
		response.put("nonce", this.nonce);
		response.put("issueTime", this.issueTime.getTime());
		response.put("expirationTime", this.expirationTime.getTime());
		return response.toJSONString();
	}
}
