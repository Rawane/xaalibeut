package fr.recouv.securite.prisme.authzserver.issuer.oidc;

import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

import com.nimbusds.openid.connect.sdk.OIDCResponseTypeValue;
import com.nimbusds.openid.connect.sdk.OIDCScopeValue;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.logger.PrismeLogger;
import fr.recouv.securite.prisme.oidc.authz.request.PrismeAuthenticationRequest;
import fr.recouv.securite.prisme.oidc.authz.token.IDToken;

/**
 * IDTokenProducer : Producteur de IDToken.
 */
public class IDTokenProducer {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			IDTokenProducer.class).build();

	/**
	 * Genere un IDToken.
	 * 
	 * @param authRequest
	 *            PrismeAuthenticationRequest
	 * @param urlIssuer
	 *            String
	 * @param anaisUser
	 *            AnaisUser
	 * @return IDToken
	 */
	public static IDToken produce(PrismeAuthenticationRequest authRequest,
			String urlIssuer, AnaisUser anaisUser) {
		LOGGER.debug(" > produce ");
		// Si IdToken non demande
		if (!authRequest.getResponseType().contains(
				OIDCResponseTypeValue.ID_TOKEN)) {
			return null;
		}

		// Generation idToken
		IDToken idToken = new IDToken();
		idToken.setPrivateKey(PrismeContexteDescriptor.getPrivateKeyFile());
		// Champs
		idToken.setIssuer(urlIssuer);
		idToken.setSubject(anaisUser.getUid().value());
		idToken.setAudience(authRequest.getClientID().getValue());
		Date date = new Date();
		idToken.setIssueTime(date);
		idToken.setExpirationTime(DateUtils.addSeconds(date,
				PrismeSecurityServer.getIDTokenDelayedTime()));
		idToken.setNonce(authRequest.getNonce().getValue());
		// Ajouts infos selon scope
		if (authRequest.getScope().contains(OIDCScopeValue.PROFILE.getValue())) {
			idToken.setName(anaisUser.getCn().value());
		}
		if (authRequest.getScope().contains(OIDCScopeValue.EMAIL.getValue())) {
			idToken.setEmail(anaisUser.getMail().value());
		}

		// Serialize
		idToken.serialize();
		LOGGER.debug(idToken.debug());

		// Retour
		return idToken;
	}
}
