package fr.recouv.securite.prisme.authzserver.anais;

import java.util.Date;

import fr.recouv.securite.prisme.authzserver.store.ScopeStoreWithGuavaCache;
import fr.recouv.securite.prisme.authzserver.store.StoreManager;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisScope : <br>
 * Determine le ScopeResponse a partir du ScopeRequest depuis Anais.
 */
public class PrismeAnaisScope {

	private static final PrismeLogger logger = new PrismeLogger().in(
			PrismeAnaisScope.class).build();

	private static ScopeStoreWithGuavaCache cache = StoreManager.scopeStore;

	/**
	 * getResponseScope : <br>
	 * Calcul du ScopeResponse en fonction de l'utilisateur et du scope request
	 * encoded
	 * 
	 * @param user
	 *            String
	 * @param encodedRequestScope
	 *            String
	 * @return PrismeResponseScope
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static PrismeResponseScope getResponseScope(String user,
			String encodedRequestScope) throws PrismeSystemException {

		Date dateDebut = new Date();
		logger.debug(" >>> getResponseScope");

		logger.debug("params:user:" + user + ",scope:" + encodedRequestScope);

		long interval = new Date().getTime() - dateDebut.getTime();
		logger.debug("Duree traitement (ms):" + interval);
		logger.debug(" <<< getResponseScope");

		return cache.get(user, encodedRequestScope);
	}
}
