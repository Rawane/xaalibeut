package fr.recouv.securite.prisme.authzserver.endpoint;

import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import net.minidev.json.JSONObject;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

import com.codahale.metrics.annotation.Timed;
import com.google.common.base.Splitter;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.RSAKey;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAuthenticator;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisHabilitation;
import fr.recouv.securite.prisme.authzserver.bo.Application;
import fr.recouv.securite.prisme.authzserver.security.PrismeSecurityUtility;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

@Path("/jwks/{version}")
public class JwksEndpoint {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			JwksEndpoint.class).build();
	/**
	 * Le nom de l'en-tête pour les autorisations.
	 */
	private static final String AUTHORIZATION_HEADER_NAME = "Authorization";

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Timed
	public String ping() {
		_logger.debug("ping");
		return "ping from JwksEndpoint!";
	}

	@GET
	@Path("/{app}")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response distribution(@Context HttpHeaders headers,
			@PathParam("app") String app) {
		JSONObject jsonResult = new JSONObject();
		jsonResult.put("result", "error");
		ResponseBuilder response = Response.status(
				HttpServletResponse.SC_BAD_REQUEST).entity(
				jsonResult.toJSONString());
		try {
			_logger.debug("distrib jwks for [" + app + "]");
			// RSAPrivateKey depuis File PEM
			if ("pss".equalsIgnoreCase(app)) {
				JWK jwk = new RSAKey.Builder(
						PrismeContexteDescriptor.getPublicKeyFile())
						.privateKey(
								PrismeContexteDescriptor.getPrivateKeyFile())
						.build();
				// Construit Reponse
				response = Response.status(HttpServletResponse.SC_OK).entity(
						jwk.toString());
				return response.build();
			} else {
				// génère la clé privé et sauvegarde la clé publique
				List<String> listAuthizations = headers
						.getRequestHeader(AUTHORIZATION_HEADER_NAME);
				if (listAuthizations == null || listAuthizations.isEmpty()) {
					return Response.status(HttpServletResponse.SC_BAD_REQUEST)
							.entity("Entete authorisation absente").build();
				}
				String basicAuthorization = StringUtils.removeStart(
						listAuthizations.get(0), "Basic ");

				String basicAuthorizationDecode = new String(
						Base64.decodeBase64(basicAuthorization));
				List<String> listCredentials = Splitter.on(":").splitToList(
						basicAuthorizationDecode);
				if (listCredentials == null || listCredentials.size() != 2) {
					return Response.status(HttpServletResponse.SC_BAD_REQUEST)
							.entity("Entete authorisation incorrecte").build();
				}
				response = generateAndSaveKey(listCredentials);

			}

		} catch (Exception e) {
			_logger.debug(e.getMessage());
		}
		return response.build();
	}

	protected ResponseBuilder generateAndSaveKey(List<String> listCredentials) {
		ResponseBuilder response;
		try {
			_logger.info("recupération des clés de l'application "
					+ listCredentials.get(0));
			AnaisApplication anaisApplication = PrismeAnaisAuthenticator
					.authenticateClient(listCredentials.get(0),
							listCredentials.get(1));
			// application habilité
			// Recuperation application
			AnaisTechnicalAccount technicalAccount = PrismeAnaisHabilitation
					.getTechnicalAccount(anaisApplication.getCn().value());
			Application application = new Application();
			if (technicalAccount != null) {
				application.parseFrom(technicalAccount);
			}
			// Generation cles
			PrismeSecurityUtility.generateKey(application);
			//TODo à enlever
			// Sauvegarde cle publique
//			PrismeAnaisHabilitation.saveTechnicalAccount(technicalAccount,
//					application.getKeyPrismePublic());
			JSONObject jsonKey = new JSONObject();
			jsonKey.put("private_key", application.getKeyPrismePrivate());
			jsonKey.put("public_key", application.getKeyPrismePublic());
			response = Response.status(HttpServletResponse.SC_OK).entity(
					jsonKey.toString());
		} catch (PrismeSystemException prismeSystemException) {
			_logger.error("erreur authentification", prismeSystemException);
			response = Response
					.status(HttpServletResponse.SC_UNAUTHORIZED)
					.entity("Erreur lors de la recuperation des habilitations Prisme sur Anais.");
		}
		return response;
	}
}
