package fr.recouv.securite.prisme.authzserver.client;

import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import fr.recouv.securite.prisme.client.HttpClientWithOkHttp3;

/**
 * HttpClientWithOkHttp3TrustedSSL : <br>
 * Utilisé pour tester la dispo des serveurs InterOps et Ocean. <br>
 * Contrairement a HttpClientWithOkHttp3, ne verifie pas la validite certif SSL.
 */
public class HttpClientWithOkHttp3TrustedSSL extends HttpClientWithOkHttp3 {

	/**
	 * Constructeur.
	 */
	public HttpClientWithOkHttp3TrustedSSL() {
		super();
		// Modifie le client en ClientTrustedSSL
		this.client = getThreadSafeClientTrustedSSL();
	}

	/**
	 * @return OkHttpClient
	 */
	public static OkHttpClient getThreadSafeClientTrustedSSL() {
		try {
			// Creation d'un trust manager qui ne valide pas les certif
			final X509TrustManager trustManager = new X509TrustManager() {
				@Override
				public void checkClientTrusted(
						java.security.cert.X509Certificate[] chain,
						String authType) throws CertificateException {
				}

				@Override
				public void checkServerTrusted(
						java.security.cert.X509Certificate[] chain,
						String authType) throws CertificateException {
				}

				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return new java.security.cert.X509Certificate[] {};
				}
			};
			final TrustManager[] trustAllCerts = new TrustManager[] { trustManager };

			// Installation d'un context qui trust tout à partir du manager
			final SSLContext sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustAllCerts,
					new java.security.SecureRandom());

			// Creation d'une factory socket ssl a partir du context
			final SSLSocketFactory sslSocketFactory = sslContext
					.getSocketFactory();

			// Creation d'un verifieur hostname qui renvoie true au verify
			final HostnameVerifier hostnameVerifier = new HostnameVerifier() {
				@Override
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};

			// Creation httpClient final
			return new OkHttpClient.Builder()
					.sslSocketFactory(sslSocketFactory, trustManager)
					.hostnameVerifier(hostnameVerifier)
					// FIX DFE Memory Leak
					.connectionPool(new ConnectionPool(5, 1, TimeUnit.SECONDS))
					.build();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
