package fr.recouv.securite.prisme.authzserver.store;

import java.lang.management.ManagementFactory;
import java.util.concurrent.TimeUnit;

import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.infinispan.Cache;

import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.store.ISecurityStore;
import fr.recouv.securite.prisme.commun.token.AbstractToken;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * TokenStoreWithInfiniSpanCache
 */
public class TokenStoreWithInfiniSpanCache implements
		TokenStoreWithInfiniSpanCacheMBean, ISecurityStore<AbstractToken> {

	private static final PrismeLogger logger = new PrismeLogger().in(
			TokenStoreWithInfiniSpanCache.class).build();

	private final String MBEAN_NAME = "fr.recouv.securite.prisme.commun.store:type=TokenStoreWithInfiniSpanCache";
	private MBeanServer mbs;
	private ObjectName name;

	// Map [uid - AbstractToken] = cache
	private static Cache<String, AbstractToken> cache;

	/**
	 * Constructeur
	 */
	public TokenStoreWithInfiniSpanCache() {
		logger.info("TokenStoreWithInfiniSpanCache : init, option:");
		// JMX
		if (PrismeContexteDescriptor.isJMXActivated()) {
			try {
				logger.info("JMX registred.");
				mbs = ManagementFactory.getPlatformMBeanServer();
				name = new ObjectName(MBEAN_NAME);
				if (!mbs.isRegistered(name)) {
					mbs.registerMBean(this, name);
				}
			} catch (Exception e) {
				logger.error("Exception : " + e.getMessage());
				throw new RuntimeException(e);
			}
		}
		// Chargement cache
		try {
			this.loadCache();
		} catch (PrismeSystemException e) {
			logger.error("Erreur lors de l'init de TokenStore : "
					+ e.getMessage());
		}
	}

	@Override
	public void invalidate() throws MBeanException {
		try {
			cache.clear();
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public void invalidateByKey(String key) throws MBeanException {
		try {
			if (cache.containsKey(key)) {
				cache.remove(key);
			}
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public long cacheSize() throws MBeanException {
		try {
			return cache.size();
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public String stats() {
		return CacheStatsUtility.getStatsFromInfiniSpanCache(cache,
				"cache-token", getCacheValidity());
	}

	@Override
	public void start() {
		cache.start();
	}

	@Override
	public void stop() {
		cache.stop();
	}

	@Override
	public void setCacheValidity(int validityPeriod) throws MBeanException {
		PrismeContexteDescriptor.setTokenCacheValidity(validityPeriod);
		invalidate();
	}

	@Override
	public int getCacheValidity() {
		return PrismeContexteDescriptor.getTokenCacheValidity();
	}

	@Override
	public void setCacheMaxEntries(int maxEntries) throws MBeanException {
		PrismeContexteDescriptor.setTokenCacheMaxEntries(maxEntries);
		invalidate();
	}

	@Override
	public int getCacheMaxEntries() {
		return PrismeContexteDescriptor.getTokenCacheMaxEntries();
	}

	// JMX
	@Override
	public Object getMBeanObject() throws MBeanException {
		try {
			return mbs.getObjectInstance(name);
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public ObjectName getMBeanObjectName() throws MBeanException {
		try {
			return name;
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public void add(String tokenKey, AbstractToken tokenValue) {
		if (cache.size() < getCacheMaxEntries()) {
			cache.put(tokenKey, tokenValue,
					getCacheValidity(),
					TimeUnit.SECONDS);
		} else {
			logger.error("Ajout impossible, maxEntries (" + getCacheMaxEntries() + ") atteint.");
		}
	}

	@Override
	public AbstractToken get(String tokenKey) throws PrismeException {
		return cache.get(tokenKey);
	}

	@Override
	public boolean contains(String tokenKey) {
		try {
			return cache.containsKey(tokenKey);
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			return false;
		}
	}

	@Override
	public void remove(String key) throws PrismeException {
		cache.remove(key);
	}

	@Override
	public void removeAll() throws PrismeException {
		cache.clear();
	}

	/**
	 * loadCache
	 * 
	 * @throws PrismeSystemException
	 *             exception
	 */
	private void loadCache() throws PrismeSystemException {
		try {
			// Recuperation cache
			cache = PrismeSecurityServer.cacheToken();
		} catch (Exception e) {
			logger.error("Exception lors de la creation du TokenCache : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR,
					"Exception lors de la creation du TokenStore");
		}
	}
}
