package fr.recouv.securite.prisme.authzserver.anais;

import javax.naming.NamingException;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisIrCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplicationInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisEntity;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.utils.StringUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisApplicationInstance.
 */
public class PrismeAnaisApplicationInstance {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisApplicationInstance.class).build();

	private static final String CONTEXT_NAME_READER = "reader";
//	private static final String CONTEXT_NAME_WRITER = "writer";

	/**
	 * getByCodeAppCodeOrg.
	 * 
	 * @param codeApplication
	 *            String
	 * @param codeOrg
	 *            String
	 * @return AnaisApplicationInstance
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 * @throws PrismeSystemException
	 *             exception
	 */
	@Deprecated
	public static AnaisApplicationInstance getByCodeAppCodeOrg(
			final String codeApplication, String codeOrg)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException, PrismeSystemException {
		// Recuperation cn par codeApplication
		AnaisCN cn = AnaisCN.set(codeApplication);
		if (cn.isEmptyOrNull()) {
			LOGGER.error("Erreur lors de la récupération de la description de l'application (application null).");
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application (application null).");
		}
		if ("DEFAULT".equals(codeOrg)) {
			codeOrg = "CER44";
		}
		// Recuperation IrCode
		AnaisEntity anaisEntity = AnaisEntity.build
				.get(CONTEXT_NAME_READER)
				.by(AnaisOrgCode.set(codeOrg))
				.execute();
		if (anaisEntity == null
				|| StringUtility.isNullOrEmpty(anaisEntity.explodeIRCode())) {
			LOGGER.error("Erreur lors de la récupération du code organisme (code organisme inconnu).");
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération du code organisme (code organisme inconnu).");
		}
		LOGGER.debug("irCode: " + anaisEntity.explodeIRCode());
		// Recuperation Instance
		AnaisApplicationInstance applicationInstance = AnaisApplicationInstance.build
				.get(CONTEXT_NAME_READER)
				.by(cn)
				.and(PrismeAnaisProperties.getEnvCode())
				.and(AnaisIrCode.set(anaisEntity.explodeIRCode()))
				.execute();
		// Retour applicationInstance
		return applicationInstance;
	}

	/**
	 * save.
	 * 
	 * @param applicationInstance
	 *            AnaisApplicationInstance
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	@Deprecated
	public static void save(AnaisApplicationInstance applicationInstance)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException {
		LOGGER.debug("> saveApplicationInstance");
//		AnaisApplicationInstance.build.set(CONTEXT_NAME_WRITER)
//				.with(applicationInstance).save();
	}
}
