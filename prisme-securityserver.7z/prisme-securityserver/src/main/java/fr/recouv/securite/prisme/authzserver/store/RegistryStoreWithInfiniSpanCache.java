package fr.recouv.securite.prisme.authzserver.store;

import java.lang.management.ManagementFactory;
import java.util.concurrent.TimeUnit;

import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.infinispan.Cache;

import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.config.bean.Config;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.store.ISecurityStore;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * RegistryStoreWithInfiniSpanCache
 */
public class RegistryStoreWithInfiniSpanCache implements
		RegistryStoreWithInfiniSpanCacheMBean, ISecurityStore<Config> {

	private static final PrismeLogger logger = new PrismeLogger().in(
			RegistryStoreWithInfiniSpanCache.class).build();

	private final String MBEAN_NAME = "fr.recouv.securite.prisme.commun.store:type=RegistryStoreWithInfiniSpanCache";
	private MBeanServer mbs;
	private ObjectName name;

	// Map [nodeId - Config] = cache
	private static Cache<String, Config> cache;

	/**
	 * Constructeur
	 */
	public RegistryStoreWithInfiniSpanCache() {
		logger.info("RegistryStoreWithInfiniSpanCache : init, option:");
		// JMX
		if (PrismeContexteDescriptor.isJMXActivated()) {
			try {
				logger.info("JMX registred.");
				mbs = ManagementFactory.getPlatformMBeanServer();
				name = new ObjectName(MBEAN_NAME);
				if (!mbs.isRegistered(name)) {
					mbs.registerMBean(this, name);
				}
			} catch (Exception e) {
				logger.error("Exception : " + e.getMessage());
				throw new RuntimeException(e);
			}
		}
		// Chargement cache
		try {
			this.loadCache();
		} catch (PrismeSystemException e) {
			logger.error("Erreur lors de l'init de RegistyStore : "
					+ e.getMessage());
		}
	}

	@Override
	public void invalidate() throws MBeanException {
		try {
			cache.clear();
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public void invalidateByKey(String key) throws MBeanException {
		try {
			if (cache.containsKey(key)) {
				cache.remove(key);
			}
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public long cacheSize() throws MBeanException {
		try {
			return cache.size();
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public String stats() {
		return CacheStatsUtility.getStatsFromInfiniSpanCache(cache,
				"cache-registry", getCacheValidity());
	}

	@Override
	public void start() {
		cache.start();
	}

	@Override
	public void stop() {
		cache.stop();
	}

	@Override
	public void setCacheValidity(int validityPeriod) throws MBeanException {
		PrismeContexteDescriptor.setRegistryStoreValidity(validityPeriod);
		invalidate();
	}

	@Override
	public int getCacheValidity() {
		return PrismeContexteDescriptor.getRegistryStoreValidity();
	}

	@Override
	public void setCacheMaxEntries(int maxEntries) throws MBeanException {
		PrismeContexteDescriptor.setRegistryStoreMaxEntries(maxEntries);
		invalidate();
	}

	@Override
	public int getCacheMaxEntries() {
		return PrismeContexteDescriptor.getRegistryStoreMaxEntries();
	}

	// JMX
	@Override
	public Object getMBeanObject() throws MBeanException {
		try {
			return mbs.getObjectInstance(name);
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public ObjectName getMBeanObjectName() throws MBeanException {
		try {
			return name;
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			throw new MBeanException(new Exception(e.getMessage()), e.getMessage());
		}
	}

	@Override
	public void add(String configKey, Config configValue) throws PrismeException {
		try {
			if (cache.size() < getCacheMaxEntries()) {
				cache.put(configKey, configValue,
						getCacheValidity(),
						TimeUnit.SECONDS);
			} else {
				logger.error("Ajout impossible, maxEntries (" + getCacheMaxEntries() + ") atteint.");
				throw new PrismeException(ExceptionCode.FUNCTION_FAILURE, "Ajout impossible, maxEntries (" + getCacheMaxEntries() + ") atteint.");
			}
		} catch (Exception e) {
			logger.error("Exception : " + e.getMessage());
			throw new PrismeException(ExceptionCode.FUNCTION_FAILURE, "Ajout impossible.");
		}
	}

	@Override
	public Config get(String configKey) throws PrismeException {
		return cache.get(configKey);
	}

	@Override
	public boolean contains(String configKey) {
		try {
			return cache.containsKey(configKey);
		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());
			return false;
		}
	}

	@Override
	public void remove(String key) throws PrismeException {
		cache.remove(key);
	}

	@Override
	public void removeAll() throws PrismeException {
		cache.clear();
	}

	/**
	 * loadCache
	 * 
	 * @throws PrismeSystemException
	 *             exception
	 */
	private void loadCache() throws PrismeSystemException {
		try {
			// Recuperation cache
			cache = PrismeSecurityServer.cacheRegistry();
		} catch (Exception e) {
			logger.error("Exception lors de la creation du RegistryCache : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR,
					"Exception lors de la creation du RegistryStore");
		}
	}
}
