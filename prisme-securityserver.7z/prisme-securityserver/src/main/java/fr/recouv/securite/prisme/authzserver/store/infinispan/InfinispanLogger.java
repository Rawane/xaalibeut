package fr.recouv.securite.prisme.authzserver.store.infinispan;

import org.infinispan.notifications.Listener;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryCreated;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryModified;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryRemoved;
import org.infinispan.notifications.cachelistener.annotation.TopologyChanged;
import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;
import org.infinispan.notifications.cachelistener.event.TopologyChangedEvent;

import fr.recouv.securite.prisme.commun.store.ElementStorable;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * InfinispanLogger
 */
@Listener
public class InfinispanLogger {

	private PrismeLogger logger = new PrismeLogger().in(InfinispanLogger.class)
			.build();

	@CacheEntryCreated
	public void observeAdd(CacheEntryCreatedEvent<String, ElementStorable> event) {
		if (event.isPre())
			return;

		logger.info("Cache entry " + event.getKey() + " added in cache "
				+ event.getCache());
	}

	@CacheEntryModified
	public void observeUpdate(CacheEntryModifiedEvent<String, ElementStorable> event) {
		if (event.isPre())
			return;

		logger.info("Cache entry " + event.getKey() + " = " + event.getValue().value()
				+ " modified in cache " + event.getCache());
	}

	@CacheEntryRemoved
	public void observeRemove(CacheEntryRemovedEvent<String, ElementStorable> event) {
		if (event.isPre())
			return;

		logger.info("Cache entry " + event.getKey() + " removed in cache "
				+ event.getCache());
	}

	@TopologyChanged
	public void observeTopologyChange(TopologyChangedEvent<String, ElementStorable> event) {
		if (event.isPre())
			return;

		logger.info("Cache " + event.getCache().getName()
				+ " topology changed, new membership is "
				+ event.getConsistentHashAtEnd().getMembers());
	}
}
