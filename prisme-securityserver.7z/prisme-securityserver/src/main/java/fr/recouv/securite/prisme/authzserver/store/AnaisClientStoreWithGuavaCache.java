package fr.recouv.securite.prisme.authzserver.store;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import com.google.common.base.Splitter;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.nimbusds.jose.util.Base64;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisApplication;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.utils.zip.GZIPUtils;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * AnaisClientStoreWithGuavaCache. <br>
 * 
 * Cache Local de Client Anais <br>
 * - Configurable sur duree expiration (-1: illimite, 0: pas de cache)<br>
 * - Receptionne une demande authentification client avec id + secret <br>
 * - Consulte cache pour presence cle (id_secret) existante <br>
 * - Si oui, retourne client <br>
 * - Si non, tente authentification, stocke resultat si ok, sinon retourne
 * erreur <br>
 */
public class AnaisClientStoreWithGuavaCache implements IStore {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			AnaisClientStoreWithGuavaCache.class).build();

	private static LoadingCache<String, AnaisApplication> cache;

	private static final String SEPARATOR = "@";
	private static long expireAfterWrite;

	/**
	 * Constructeur vide. (prise en compte valeur par defaut)
	 */
	public AnaisClientStoreWithGuavaCache() {
		new AnaisClientStoreWithGuavaCache(1200);
	}

	/**
	 * Constructeur avec duree expiration.
	 * 
	 * @param expireCache
	 *            int (-1: illimite, 0: pas de cache)
	 */
	public AnaisClientStoreWithGuavaCache(final int expireCache) {
		expireAfterWrite = expireCache;
		if (0 == expireCache) {
			// Pas de cache
			LOGGER.debug("Pas de Cache");
			cache = null;
		} else if (-1 == expireCache) {
			// Init cache (-1: illimite)
			LOGGER.debug("Init cache, illimite");
			cache = CacheBuilder.newBuilder().recordStats()
					.build(new CacheLoader<String, AnaisApplication>() {
						@Override
						public AnaisApplication load(String key)
								throws PrismeSystemException {
							return loadApplicationFromAnais(key);
						}
					});
		} else {
			// Init cache (avec expireCache)
			LOGGER.debug("Init cache, expireCache a " + expireCache + " (s)");
			cache = CacheBuilder.newBuilder().recordStats()
					.expireAfterWrite(expireCache, TimeUnit.SECONDS)
					.build(new CacheLoader<String, AnaisApplication>() {
						@Override
						public AnaisApplication load(String key)
								throws PrismeSystemException {
							return loadApplicationFromAnais(key);
						}
					});
		}
	}

	@Override
	public List<EntryCache> list() {
		List<EntryCache> liste = new ArrayList<EntryCache>();
		// Si cache
		if (cache != null) {
			for (String key : cache.asMap().keySet()) {
				liste.add(new EntryCache(key, (AnaisApplication) cache.asMap().get(key)));
			}
		}
		return liste;
	}

	@Override
	public String stats() {
		return CacheStatsUtility
				.getStatsFromGuavaCache(cache, expireAfterWrite);
	}

	@Override
	public int size() {
		if (cache != null) {
			return cache.asMap().size();
		}
		return 0;
	}


	@Override
	public void remove(final String key) {
		// Si cache
		if (cache != null) {
			cache.invalidate(key);
		}
	}

	@Override
	public void removeAll() {
		// Si cache
		if (cache != null) {
			cache.invalidateAll();
		}
	}

	/**
	 * Recuperation depuis cache.
	 * 
	 * @param clientId
	 *            String
	 * @param clientSecret
	 *            String
	 * @return AnaisApplication
	 * @throws PrismeSystemException
	 *             Exception
	 */
	public AnaisApplication get(String clientId, String clientSecret)
			throws PrismeSystemException {
		try {
			// Encodage clientSecret
			String clientSecretEncoded = Base64.encode(GZIPUtils.compress(clientSecret)).toString();
			final String key = clientId + SEPARATOR + clientSecretEncoded;
			// Si cache
			if (cache != null) {
				// Recuperation depuis cache
				LOGGER.debug("Lecture cache pour recuperation client");
				return cache.get(key);
			} else {
				// Pas de cache
				LOGGER.debug("Pas de cache configure");
				return loadApplicationFromAnais(key);
			}
		} catch (IOException e) {
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de l'encodage clientSecret.");
		} catch (ExecutionException e) {
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de l'authentification Client sur Anais.");
		}
	}

	/**
	 * Enrichissment du magasin locale des clients.
	 * 
	 * @param key
	 * @return AnaisApplication un objet AnaisApplication
	 * @throws PrismeSystemException
	 *             exception
	 */
	private static AnaisApplication loadApplicationFromAnais(String key)
			throws PrismeSystemException {
		LOGGER.debug("Client non present, Enrichissement depuis Anais");
		AnaisApplication client = null;
		try {
			String clientId = "";
			String clientSecret = "";
			if (key != null && !"".equals(key)) {
				List<String> liste = Splitter.on(SEPARATOR).splitToList(key);
				if (liste != null && liste.size() == 2) {
					clientId = liste.get(0);
					clientSecret = liste.get(1);
				}
			}
			// Decodage clientSecret
			String clientSecretDecoded = GZIPUtils.decompress(new Base64(clientSecret).decode());
			// Recuperation Anais
			client = PrismeAnaisApplication.withAccount(clientId, clientSecretDecoded);
		} catch (IOException e) {
			LOGGER.error("Exception lors du decodage clientSecret.");
		} catch (NamingException e) {
			LOGGER.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
		} catch (AnaisExceptionFailure e) {
			LOGGER.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
		} catch (AnaisExceptionServerCommunication e) {
			LOGGER.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
		} finally {
			if (client == null) {
				throw new PrismeSystemException(ExceptionCode.SECURITY,
						"Erreur lors de l'authentification Client sur Anais.");
			}
		}
		return client;
	}
}
