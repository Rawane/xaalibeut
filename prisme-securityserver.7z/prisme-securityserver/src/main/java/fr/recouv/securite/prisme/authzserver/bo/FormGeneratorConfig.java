package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * FormGeneratorConfig.
 */
public class FormGeneratorConfig implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = -1878368048133175675L;

	@JsonProperty
	private String mode;
	@JsonProperty
	private String authenticator;
	@JsonProperty
	private String authorizer;
	@JsonProperty
	private String providerPermissionsLoader;
	@JsonProperty
	private String providerPermissionsFile;
	@JsonProperty
	private String httpClient;
	@JsonProperty
	private String tokenEndpoint;
	@JsonProperty
	private String authzEndpoint;
	@JsonProperty
	private String registryEndpoint;
	@JsonProperty
	private String populateEndpoint;
	@JsonProperty
	private String identityStore;
	@JsonProperty
	private String identityCacheMaxEntries;
	@JsonProperty
	private String identityValidity;
	@JsonProperty
	private String tokenStore;
	@JsonProperty
	private String tokenCacheMaxEntries;
	@JsonProperty
	private String tokenValidity;
	@JsonProperty
	private String permissionsStore;
	@JsonProperty
	private String permissionsCacheMaxEntries;
	@JsonProperty
	private String permissionsValidity;
	@JsonProperty
	private String jmxActivated;
	@JsonProperty
	private String securityOptions;
	@JsonProperty
	private String clientId;
	@JsonProperty
	private String clientSecret;
	@JsonProperty
	private String urlClientCallback;
	@JsonProperty
	private String urlBackendRedirectAfterAuth;
	@JsonProperty
	private String urlBackendLogout;

	/**
	 * Constructeur simple.
	 */
	public FormGeneratorConfig() {
		// Constructeur simple
	}

	/**
	 * @return the mode
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMode() {
		return this.mode;
	}

	/**
	 * @param mode the mode to set
	 */
	public void setMode(final String mode) {
		this.mode = mode;
	}

	/**
	 * @return the authenticator
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getAuthenticator() {
		return authenticator;
	}

	/**
	 * @param authenticator the authenticator to set
	 */
	public final void setAuthenticator(String authenticator) {
		this.authenticator = authenticator;
	}

	/**
	 * @return the authorizer
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getAuthorizer() {
		return authorizer;
	}

	/**
	 * @param authorizer the authorizer to set
	 */
	public final void setAuthorizer(String authorizer) {
		this.authorizer = authorizer;
	}

	/**
	 * @return the providerPermissionsLoader
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getProviderPermissionsLoader() {
		return providerPermissionsLoader;
	}

	/**
	 * @param providerPermissionsLoader the providerPermissionsLoader to set
	 */
	public final void setProviderPermissionsLoader(String providerPermissionsLoader) {
		this.providerPermissionsLoader = providerPermissionsLoader;
	}

	/**
	 * @return the providerPermissionsFile
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getProviderPermissionsFile() {
		return providerPermissionsFile;
	}

	/**
	 * @param providerPermissionsFile the providerPermissionsFile to set
	 */
	public final void setProviderPermissionsFile(String providerPermissionsFile) {
		this.providerPermissionsFile = providerPermissionsFile;
	}

	/**
	 * @return the httpClient
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getHttpClient() {
		return httpClient;
	}

	/**
	 * @param httpClient the httpClient to set
	 */
	public final void setHttpClient(String httpClient) {
		this.httpClient = httpClient;
	}

	/**
	 * @return the tokenEndpoint
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getTokenEndpoint() {
		return tokenEndpoint;
	}

	/**
	 * @param tokenEndpoint the tokenEndpoint to set
	 */
	public final void setTokenEndpoint(String tokenEndpoint) {
		this.tokenEndpoint = tokenEndpoint;
	}

	/**
	 * @return the authzEndpoint
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getAuthzEndpoint() {
		return authzEndpoint;
	}

	/**
	 * @param authzEndpoint the authzEndpoint to set
	 */
	public final void setAuthzEndpoint(String authzEndpoint) {
		this.authzEndpoint = authzEndpoint;
	}

	/**
	 * @return the registryEndpoint
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getRegistryEndpoint() {
		return registryEndpoint;
	}

	/**
	 * @param registryEndpoint the registryEndpoint to set
	 */
	public final void setRegistryEndpoint(String registryEndpoint) {
		this.registryEndpoint = registryEndpoint;
	}

	/**
	 * @return the populateEndpoint
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getPopulateEndpoint() {
		return populateEndpoint;
	}

	/**
	 * @param populateEndpoint the populateEndpoint to set
	 */
	public final void setPopulateEndpoint(String populateEndpoint) {
		this.populateEndpoint = populateEndpoint;
	}

	/**
	 * @return the identityStore
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getIdentityStore() {
		return identityStore;
	}

	/**
	 * @param identityStore the identityStore to set
	 */
	public final void setIdentityStore(String identityStore) {
		this.identityStore = identityStore;
	}

	/**
	 * @return the identityCacheMaxEntries
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getIdentityCacheMaxEntries() {
		return identityCacheMaxEntries;
	}

	/**
	 * @param identityCacheMaxEntries the identityCacheMaxEntries to set
	 */
	public final void setIdentityCacheMaxEntries(String identityCacheMaxEntries) {
		this.identityCacheMaxEntries = identityCacheMaxEntries;
	}

	/**
	 * @return the identityValidity
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getIdentityValidity() {
		return identityValidity;
	}

	/**
	 * @param identityValidity the identityValidity to set
	 */
	public final void setIdentityValidity(String identityValidity) {
		this.identityValidity = identityValidity;
	}

	/**
	 * @return the tokenStore
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getTokenStore() {
		return tokenStore;
	}

	/**
	 * @param tokenStore the tokenStore to set
	 */
	public final void setTokenStore(String tokenStore) {
		this.tokenStore = tokenStore;
	}

	/**
	 * @return the tokenCacheMaxEntries
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getTokenCacheMaxEntries() {
		return tokenCacheMaxEntries;
	}

	/**
	 * @param tokenCacheMaxEntries the tokenCacheMaxEntries to set
	 */
	public final void setTokenCacheMaxEntries(String tokenCacheMaxEntries) {
		this.tokenCacheMaxEntries = tokenCacheMaxEntries;
	}

	/**
	 * @return the tokenValidity
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getTokenValidity() {
		return tokenValidity;
	}

	/**
	 * @param tokenValidity the tokenValidity to set
	 */
	public final void setTokenValidity(String tokenValidity) {
		this.tokenValidity = tokenValidity;
	}

	/**
	 * @return the permissionsStore
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getPermissionsStore() {
		return permissionsStore;
	}

	/**
	 * @param permissionsStore the permissionsStore to set
	 */
	public final void setPermissionsStore(String permissionsStore) {
		this.permissionsStore = permissionsStore;
	}

	/**
	 * @return the permissionsCacheMaxEntries
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getPermissionsCacheMaxEntries() {
		return permissionsCacheMaxEntries;
	}

	/**
	 * @param permissionsCacheMaxEntries the permissionsCacheMaxEntries to set
	 */
	public final void setPermissionsCacheMaxEntries(
			String permissionsCacheMaxEntries) {
		this.permissionsCacheMaxEntries = permissionsCacheMaxEntries;
	}

	/**
	 * @return the permissionsValidity
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getPermissionsValidity() {
		return permissionsValidity;
	}

	/**
	 * @param permissionsValidity the permissionsValidity to set
	 */
	public final void setPermissionsValidity(String permissionsValidity) {
		this.permissionsValidity = permissionsValidity;
	}

	/**
	 * @return the jmxActivated
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getJmxActivated() {
		return jmxActivated;
	}

	/**
	 * @param jmxActivated the jmxActivated to set
	 */
	public final void setJmxActivated(String jmxActivated) {
		this.jmxActivated = jmxActivated;
	}

	/**
	 * @return the securityOptions
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getSecurityOptions() {
		return securityOptions;
	}

	/**
	 * @param securityOptions the securityOptions to set
	 */
	public final void setSecurityOptions(String securityOptions) {
		this.securityOptions = securityOptions;
	}

	/**
	 * @return the clientId
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getClientId() {
		return this.clientId;
	}

	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(final String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the clientSecret
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getClientSecret() {
		return clientSecret;
	}

	/**
	 * @param clientSecret the clientSecret to set
	 */
	public final void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	/**
	 * @return the urlClientCallback
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getUrlClientCallback() {
		return urlClientCallback;
	}

	/**
	 * @param urlClientCallback the urlClientCallback to set
	 */
	public final void setUrlClientCallback(String urlClientCallback) {
		this.urlClientCallback = urlClientCallback;
	}

	/**
	 * @return the urlBackendRedirectAfterAuth
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getUrlBackendRedirectAfterAuth() {
		return urlBackendRedirectAfterAuth;
	}

	/**
	 * @param urlBackendRedirectAfterAuth the urlBackendRedirectAfterAuth to set
	 */
	public final void setUrlBackendRedirectAfterAuth(String urlBackendRedirectAfterAuth) {
		this.urlBackendRedirectAfterAuth = urlBackendRedirectAfterAuth;
	}

	/**
	 * @return the urlBackendLogout
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getUrlBackendLogout() {
		return urlBackendLogout;
	}

	/**
	 * @param urlBackendLogout the urlBackendLogout to set
	 */
	public final void setUrlBackendLogout(String urlBackendLogout) {
		this.urlBackendLogout = urlBackendLogout;
	}
}
