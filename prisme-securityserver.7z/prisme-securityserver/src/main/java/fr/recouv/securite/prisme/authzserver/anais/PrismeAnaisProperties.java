package fr.recouv.securite.prisme.authzserver.anais;

import org.apache.commons.lang3.StringUtils;

import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisEnvCode;
import fr.recouv.securite.prisme.commun.utils.PropertiesUtility;

/**
 * Lecture Fichier anais.properties.
 */
public class PrismeAnaisProperties {

	/** Fichier de Properties */
	private static PropertiesUtility PROPERTIE_FILE;

	/** Nom de fichier de Properties */
	private final static String PROPERTIE_NAME = "anais.properties";

	/** Propriete envCode */
	private static final String ENV_CODE = "envCode";

	/** Defaut envCode */
	private static final String DEFAUT_ENV_CODE = "PROD";

	/**
	 * Chargement implicite.
	 */
	static {
		// Initialisation properties
		if (PROPERTIE_FILE == null) {
			PROPERTIE_FILE = PropertiesUtility.build(PROPERTIE_NAME);
		}
	}

	/**
	 * Recuperation envCode.
	 * 
	 * @return String
	 */
	public static AnaisEnvCode getEnvCode() {
		if (PROPERTIE_FILE == null
				|| PROPERTIE_FILE.getProperty(ENV_CODE) == null) {
			return AnaisEnvCode.set(DEFAUT_ENV_CODE);
		} else {
			return AnaisEnvCode.set(StringUtils.trimToEmpty(PROPERTIE_FILE
					.getProperty(ENV_CODE)));
		}
	}
}
