package fr.recouv.securite.prisme.authzserver.listener;

import javax.servlet.http.HttpServletRequest;

import fr.recouv.securite.prisme.authzserver.bo.UserSession;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;

/**
 * PrismeServletSession : <br>
 * Manager de l'object UserSession en session. <br>
 * Fait le lien entre request et contenu session.
 */
public class PrismeServletSession {

	/**
	 * USER_SESSION.
	 */
	public static final String USER_SESSION = "userSession";

	/**
	 * Set User Session.
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param username
	 *            String
	 * @param password
	 *            String
	 * @throws PrismeSystemException
	 *             Exception
	 */
	public static void setUserSession(final HttpServletRequest request,
			final String username, final String password)
			throws PrismeSystemException {
		// Creation UserSession
		UserSession userSession = new UserSession(username, password);
		// Mise en session UserSession
		request.getSession().setAttribute(PrismeServletSession.USER_SESSION,
				userSession);
	}

	/**
	 * Get User Session.
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @return userSession
	 */
	public static UserSession getUserSession(final HttpServletRequest request) {
		// Retourne object UserSession present en session
		return (UserSession) request.getSession().getAttribute(
				PrismeServletSession.USER_SESSION);
	}

	/**
	 * Is User Session.
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @return boolean
	 */
	public static boolean isUserSession(final HttpServletRequest request) {
		// Verifie presence UserSession present en session
		return (getUserSession(request) != null);
	}

	/**
	 * Is User Session + hasRole.
	 * 
	 * @param request HttpServletRequest
	 * @param role String
	 * @return boolean
	 */
	public static boolean hasUserSessionRole(final HttpServletRequest request,
			final String role) {
		// Verifie presence UserSession + Role
		return (getUserSession(request) != null
			&& (getUserSession(request).hasRole(UserSession.LIBELLE_PROFIL_ADMINSECU)
				|| getUserSession(request).hasRole(role)));
	}

	/**
	 * Reset User Session.
	 * 
	 * @param request
	 *            HttpServletRequest
	 */
	public static void resetUserSession(final HttpServletRequest request) {
		// Reset UserSession present en session
		request.getSession().setAttribute(PrismeServletSession.USER_SESSION,
				null);
	}
}
