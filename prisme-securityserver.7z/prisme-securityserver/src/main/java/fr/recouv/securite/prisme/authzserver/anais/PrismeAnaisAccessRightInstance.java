package fr.recouv.securite.prisme.authzserver.anais;

import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisApplicationCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisIrCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisEntity;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.utils.StringUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisAccessRightInstance.
 */
public class PrismeAnaisAccessRightInstance {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisAccessRightInstance.class).build();

	private static String CONTEXT_NAME_READER = "reader";
	private static String CONTEXT_NAME_WRITER = "writer";

	/**
	 * listeAccessRightByUser.
	 * 
	 * @param user
	 *            String
	 * @return List AnaisAccessRightInstance
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static List<AnaisAccessRightInstance> listeAccessRightByUser(
			String user) throws AnaisExceptionFailure,
			AnaisExceptionServerCommunication, NamingException, PrismeSystemException {
		LOGGER.debug("> listeAccessRightByUser");
		// Recuperation utilisateur
		AnaisUser anaisUser = PrismeAnaisUser.byUID(user);
		// Liste AccessRight utilisateur
		return listeAccessRightByAnaisUser(anaisUser);
	}

	/**
	 * listeAccessRightByAnaisUser.
	 * 
	 * @param anaisUser
	 *            AnaisUser
	 * @return List AnaisAccessRightInstance
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static List<AnaisAccessRightInstance> listeAccessRightByAnaisUser(
			final AnaisUser anaisUser) throws AnaisExceptionFailure,
			AnaisExceptionServerCommunication, NamingException {
		LOGGER.debug("> listeAccessRightByAnaisUser");
		List<AnaisAccessRightInstance> listAnaisAccessRightInstance = null;
		listAnaisAccessRightInstance = AnaisAccessRightInstance.build
				.getList(CONTEXT_NAME_READER).by(anaisUser)
				.and(PrismeAnaisProperties.getEnvCode()).execute();
		return listAnaisAccessRightInstance;
	}

	/**
	 * listeAccessRightByUserApp.
	 * 
	 * @param anaisUser
	 *            AnaisUser
	 * @param anaisApplication
	 *            AnaisApplication
	 * @return List AnaisAccessRightInstance
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static List<AnaisAccessRightInstance> listeAccessRightByUserApp(
			final AnaisUser anaisUser, final AnaisApplication anaisApplication)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException {
		LOGGER.debug("> listeAccessRightByUserApp");
		List<AnaisAccessRightInstance> listAnaisAccessRightInstance = null;
		if (anaisApplication.isPortalTypeApplication()) {
			listAnaisAccessRightInstance = AnaisAccessRightInstance.build
					.getList(CONTEXT_NAME_READER).by(anaisApplication).and(anaisUser)
					.and(PrismeAnaisProperties.getEnvCode()).execute();
		} else {
			listAnaisAccessRightInstance = AnaisAccessRightInstance.build
					.getList(CONTEXT_NAME_READER)
					.by(AnaisApplicationCode.set(anaisApplication
							.getApplicationCode().value())).and(anaisUser)
					.and(PrismeAnaisProperties.getEnvCode()).execute();
		}
		return listAnaisAccessRightInstance;
	}

	/**
	 * listeAccessRightByUserAppCodeOrg.
	 * 
	 * @param anaisUser
	 *            AnaisUser
	 * @param anaisApplication
	 *            AnaisApplication
	 * @param listOfOrgCode
	 *            List AnaisOrgCode
	 * @return List AnaisAccessRightInstance
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static List<AnaisAccessRightInstance> listeAccessRightByUserAppCodeOrg(
			final AnaisUser anaisUser, final AnaisApplication anaisApplication,
			final List<AnaisOrgCode> listOfOrgCode)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException {
		LOGGER.debug("> listeAccessRightByUserAppCodeOrg");
		List<AnaisAccessRightInstance> listAnaisAccessRightInstance = null;
		if (anaisApplication.isPortalTypeApplication()) {
			listAnaisAccessRightInstance = AnaisAccessRightInstance.build
					.getList(CONTEXT_NAME_READER).by(anaisApplication).and(anaisUser)
					.and(PrismeAnaisProperties.getEnvCode()).and(listOfOrgCode)
					.execute();
		} else {
			listAnaisAccessRightInstance = AnaisAccessRightInstance.build
					.getList(CONTEXT_NAME_READER)
					.by(AnaisApplicationCode.set(anaisApplication
							.getApplicationCode().value())).and(anaisUser)
					.and(PrismeAnaisProperties.getEnvCode()).and(listOfOrgCode)
					.execute();
		}
		return listAnaisAccessRightInstance;
	}

	// PERMISSIONS

	/**
	 * getAccessRightByUserAppCodeOrg
	 * 
	 * @param codeApplication
	 *            String
	 * @param codeOrg
	 *            String
	 * @param libDroit
	 *            String
	 * @return AnaisAccessRightInstance
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static List<AnaisAccessRightInstance> getAccessRightByAppCodeOrgLibDroit(
			final String codeApplication, final String codeOrg,
			final String libDroit) throws AnaisExceptionFailure,
			AnaisExceptionServerCommunication, NamingException,
			PrismeSystemException {
		LOGGER.debug("> getAccessRightByAppCodeOrgLibDroit, codeApp: "
				+ codeApplication + ", codeOrg: " + codeOrg + ", libDroit: "
				+ libDroit);

		// Recuperation application
		AnaisCN cnAnaisApplication = AnaisCN.set(codeApplication);
		if (cnAnaisApplication.isEmptyOrNull()) {
			LOGGER.error("Erreur lors de la récupération de la description de l'application (application null).");
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application (application null).");
		}
		AnaisApplication anaisApplication = PrismeAnaisApplication
				.getApplicationByCN(cnAnaisApplication.value());
		if (anaisApplication == null) {
			LOGGER.error("Erreur lors de la récupération de la description de l'application (application null).");
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de la description de l'application (application null).");
		}

		// Si codeOrg non specifie
		if (StringUtility.isNullOrEmpty(codeOrg) || "DEFAULT".equals(codeOrg)) {
			// Recuperation Instance sous forme de List
			List<AnaisAccessRightInstance> listeAccessRight = AnaisAccessRightInstance.build
					.getList(CONTEXT_NAME_READER)
					.by(anaisApplication.getApplicationCode())
					.and(PrismeAnaisProperties.getEnvCode())
					.execute();

			// Retour listeAccessRight
			return listeAccessRight;
		} else {
			// Recuperation codeOrg
			AnaisOrgCode anaisCodeOrg = AnaisOrgCode.set(codeOrg);
			if (anaisCodeOrg == null) {
				LOGGER.error("Erreur lors de la récupération du code organisme (application null).");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur lors de la récupération du code organisme (application null).");
			}
			AnaisEntity anaisEntity = AnaisEntity.build
					.get(CONTEXT_NAME_READER)
					.by(anaisCodeOrg)
					.execute();
			if (anaisEntity == null
					|| StringUtility.isNullOrEmpty(anaisEntity.explodeIRCode())) {
				LOGGER.error("Erreur lors de la récupération du code organisme (code organisme inconnu).");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur lors de la récupération du code organisme (code organisme inconnu).");
			}

			// Recuperation droit
			AnaisCN cnDroit = AnaisCN.set(libDroit);
			if (cnDroit.isEmptyOrNull()) {
				LOGGER.error("Erreur lors de la récupération du droit (libellé droit inconnu).");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur lors de la récupération du droit (libellé droit inconnu).");
			}

			// Recuperation Instance
			AnaisAccessRightInstance accessRight = AnaisAccessRightInstance.build
					.get(CONTEXT_NAME_READER)
					.by(anaisApplication)
					.and(cnDroit)
					.and(PrismeAnaisProperties.getEnvCode())
					.and(AnaisIrCode.set(anaisEntity.explodeIRCode()))
					.and(anaisCodeOrg)
					.execute();

			List<AnaisAccessRightInstance> listeAccessRight = new ArrayList<AnaisAccessRightInstance>();
			listeAccessRight.add(accessRight);
			// Retour listeAccessRight
			return listeAccessRight;
		}
	}

	/**
	 * save.
	 * 
	 * @param accessRight
	 *            AnaisAccessRightInstance
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static void save(AnaisAccessRightInstance accessRight)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException {
		LOGGER.debug("> saveAnaisAccessRightInstance");
		LOGGER.debug("accessRight: " + accessRight.getCn().value());
		LOGGER.debug("description: " + accessRight.getDescription().value());
		AnaisAccessRightInstance.build.set(CONTEXT_NAME_WRITER)
				.with(accessRight).save();
	}
}
