package fr.recouv.securite.prisme.authzserver.store;

/**
 * IDTokenStoreWithInfiniSpanCacheMBean.
 */
public interface IDTokenStoreWithInfiniSpanCacheMBean extends IStoreMBean {

	// Voir IStoreMBean
}
