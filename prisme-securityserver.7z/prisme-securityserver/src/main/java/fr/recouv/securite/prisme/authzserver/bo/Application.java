package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.api.anais.api.source.model.primary.HawaiOldTechnicalSupportAccessRightInstance;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisUtility;
import fr.recouv.securite.prisme.authzserver.security.PrismeSecurityUtility;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;

/**
 * Application : <br>
 * Object representant les applications dont la personne connectee a les droits.
 */
public class Application implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 3409564134678405834L;

	@JsonProperty
	private String hwiCN;

	@JsonProperty
	private String clientId;

	@JsonProperty
	private String nom;

	@JsonProperty
	private String keyOcean;

	@JsonProperty
	private String keyPrismePublic;

	@JsonProperty
	private String keyPrismePrivate;

	/**
	 * Constructeur.
	 */
	public Application() {
		// Objet vide
		this.clientId = "";
	}

	/**
	 * Constructeur par HabilitationSurApplication
	 * 
	 * @param ari
	 *            HawaiOldTechnicalSupportAccessRightInstance
	 */
	public Application(final HawaiOldTechnicalSupportAccessRightInstance ari) {
		if (ari != null && ari.getCn() != null) {
			this.hwiCN = ari.getCn().value();
		}
	}

	/**
	 * resolveDN : formate un cn en dn.
	 * 
	 * @param cn
	 *            String
	 * @return String dn
	 */
	public static String resolveDN(final String cn) {
		return PrismeAnaisUtility.constructCN(cn.replace("hwi_", "").toUpperCase());
	}

	/**
	 * Parse From TechnicalAccount.
	 * 
	 * @param technicalAccount
	 *            AnaisTechnicalAccount
	 */
	public void parseFrom(final AnaisTechnicalAccount technicalAccount) {
		if (technicalAccount != null) {
			this.nom = PrismeAnaisUtility.extractCodeApplication(technicalAccount.getCn().value());
			this.clientId = technicalAccount.getRdn().value();
			this.keyOcean = technicalAccount.getKeyOcean().value();
			this.keyPrismePublic = technicalAccount.getKeyPrisme().value();
		}
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHwiCN() {
		return this.hwiCN;
	}

	/**
	 * @param hwiCN
	 *            String
	 */
	public void setHwiCN(final String hwiCN) {
		this.hwiCN = hwiCN;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getNom() {
		return this.nom;
	}

	/**
	 * @param nom
	 *            String
	 */
	public void setNom(final String nom) {
		this.nom = nom;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getClientId() {
		return this.clientId;
	}

	/**
	 * @param clientId
	 *            String
	 */
	public void setClientId(final String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getKeyOcean() {
		return this.keyOcean;
	}

	/**
	 * @param keyOcean
	 *            String
	 */
	public void setKeyOcean(final String keyOcean) {
		this.keyOcean = keyOcean;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getKeyPrismePublic() {
		return this.keyPrismePublic;
	}

	/**
	 * @param keyPrismePublic
	 *            String
	 */
	public void setKeyPrismePublic(final String keyPrismePublic) {
		this.keyPrismePublic = keyPrismePublic;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getKeyPrismePublicFormated() {
		if (this.keyPrismePublic != null && !"".equals(this.keyPrismePublic)) {
			try {
				return PrismeSecurityUtility.formatPublicKey(this.keyPrismePublic);
			} catch (PrismeSystemException e) {
				return null;
			}
		}
		return null;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getKeyPrismePrivate() {
		return this.keyPrismePrivate;
	}

	/**
	 * @param keyPrismePrivate
	 *            String
	 */
	public void setKeyPrismePrivate(final String keyPrismePrivate) {
		this.keyPrismePrivate = keyPrismePrivate;
	}
}
