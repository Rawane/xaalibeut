package fr.recouv.securite.prisme.authzserver.endpoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.codahale.metrics.annotation.Timed;

import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAuthenticator;
import fr.recouv.securite.prisme.authzserver.provider.AccessRightToAUProducer;
import fr.recouv.securite.prisme.authzserver.provider.IdentityProducer;
import fr.recouv.securite.prisme.authzserver.provider.PrismePopulateServerProvider;
import fr.recouv.securite.prisme.authzserver.request.PrismePopulateRequest;
import fr.recouv.securite.prisme.authzserver.response.PrismePopulateServerResponse;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.PrismeProtocoleError;
import fr.recouv.securite.prisme.commun.message.response.PrismeResponse;
import fr.recouv.securite.prisme.commun.message.types.PrismePopulateType;
import fr.recouv.securite.prisme.logger.PrismeLogger;

@Path("/populate/{version}")
public class PopulateEndpoint {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			PopulateEndpoint.class).build();

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Timed
	public String ping() {
		_logger.debug("ping");
		return "ping from PopulateEndpoint!";
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response request(@Context HttpServletRequest request)
			throws PrismeSystemException {

		// Extraire les donnees relatif aux traitements de la requete
		PrismePopulateRequest populateRequest;
		try {
			populateRequest = new PrismePopulateRequest(request);

			_logger.debug("populate type   : "
					+ populateRequest.getParam(PrismeParams.POPULATE.TYPE));
			_logger.debug("client id    : "
					+ populateRequest.getParam(PrismeParams.CLIENT_ID));
			_logger.debug("client secret: "
					+ populateRequest.getParam(PrismeParams.CLIENT_SECRET));

			// Authentification Client_id + Client_secret sur Anais
			PrismeAnaisAuthenticator.authenticateClient(
					populateRequest.getParam(PrismeParams.CLIENT_ID),
					populateRequest.getParam(PrismeParams.CLIENT_SECRET));

			PrismePopulateServerProvider provider = this
					.getProvider(populateRequest);
			if (provider == null) {
				_logger.debug(" << onProtocoleError");
				return onProtocoleError(
						PrismeProtocoleError.POPULATE_PROTOCOLE.INVALID_CODE,
						PrismeProtocoleError.POPULATE_PROTOCOLE.INVALID_MESSAGE);
			}

			PrismeResponse response = provider.compose();
			return Response.status(response.getResponseStatus())
					.entity(response.getBody()).build();
		} catch (PrismeSystemException e) {
			_logger.error("Erreur lors du traitement : " + e.getMessage());
			return onProtocoleError(e.getCodeException().toString(),
					e.getMessage());
		}
	}

	/**
	 * @param code
	 *            String
	 * @param msg
	 *            String
	 * @return Response
	 * @throws PrismeSystemException
	 */
	private Response onProtocoleError(final String code, final String msg)
			throws PrismeSystemException {
		final PrismeResponse response = PrismePopulateServerResponse
				.onError(HttpServletResponse.SC_BAD_REQUEST).setErrorCode(code)
				.setErrorMessage(msg).buildJSONMessage();
		return Response.status(response.getResponseStatus())
				.entity(response.getBody()).build();
	}

	/**
	 * getProvider
	 * 
	 * @param populateType
	 *            String
	 * @return PrismePopulateServerProvider
	 */
	private PrismePopulateServerProvider getProvider(PrismePopulateRequest request) {

		final PrismePopulateType enumPopulateType = PrismePopulateType
				.toValue(request.getParam(PrismeParams.POPULATE.TYPE));
		if (enumPopulateType == null) {
			return null;
		}
		PrismePopulateServerProvider provider = null;
		switch (enumPopulateType) {
		case IDENTITY:
			_logger.debug(" << isIdentityFlow");
			// Producteur de reponse a une demande d enrichissement.
			provider = new IdentityProducer(
					request.getParam(PrismeParams.USERNAME));
			break;
		case ACCESSRIGHT_TO_AU:
			_logger.debug(" << isAccessRightToAU");
			// Producteur de reponse a une demande d enrichissement.
			provider = new AccessRightToAUProducer(request);
			break;
		default:
			// Defaut
			break;
		}
		return provider;
	}
}
