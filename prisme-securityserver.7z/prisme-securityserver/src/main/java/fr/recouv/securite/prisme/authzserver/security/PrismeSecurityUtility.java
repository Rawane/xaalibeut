package fr.recouv.securite.prisme.authzserver.security;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Base64;

import com.nimbusds.jose.jwk.RSAKey;

import fr.recouv.securite.prisme.authzserver.bo.Application;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.security.utility.RSAPrivateKeyUtility;
import fr.recouv.securite.prisme.commun.security.utility.RSAPublicKeyUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeSecurityUtility : <br>
 * Classe utilitaire pour gestion cles publiques / cles privees cote PSS.
 */
public class PrismeSecurityUtility {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeSecurityUtility.class).build();

	/**
	 * @param pubKey
	 *            String
	 * @return pubKey (format PEM)
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static String formatPublicKey(String pubKey)
			throws PrismeSystemException {
		LOGGER.debug(" > formatPublicKey");
		try {
			// Convert to RSAPublicKey
			RSAPublicKey rsaPubKey = RSAPublicKeyUtility
					.convertToRSAPublicKey(pubKey);
			// Conversion en String (format PEM)
			return RSAPublicKeyUtility.convertKeyToPEMPublicKey(rsaPubKey
					.getEncoded());
		} catch (PrismeInvalidTokenException e) {
			LOGGER.error("PrismeInvalidTokenException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur conversion public Key");
		}
	}

	/**
	 * @param privKey
	 *            String
	 * @return privKey (format PEM)
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static String formatPrivateKey(String privKey)
			throws PrismeSystemException {
		LOGGER.debug(" > formatPrivateKey");
		try {
			// Convert to RSAPrivateKey
			RSAPrivateKey rsaPrivKey = RSAPrivateKeyUtility
					.convertToRSAPrivateKey(privKey);
			// Conversion en String (format PEM)
			return RSAPrivateKeyUtility.convertKeyToPEMPrivateKey(rsaPrivKey
					.getEncoded());
		} catch (PrismeInvalidTokenException e) {
			LOGGER.error("PrismeInvalidTokenException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur conversion public Key");
		}
	}

	/**
	 * Genere un jeu de cles et les stocke dans l'application passé en
	 * parametre.
	 * 
	 * @param application
	 *            Application
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static void generateKey(Application application)
			throws PrismeSystemException {
		LOGGER.debug(" > generateKey");
		try {
			// Generation keyPair
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
			final int keyBitSize = 1024;
			keyGen.initialize(keyBitSize);
			KeyPair keyPair = keyGen.genKeyPair();
			// Generation clés privée et publique
			RSAPrivateKey priv = (RSAPrivateKey) keyPair.getPrivate();
			RSAPublicKey pub = (RSAPublicKey) keyPair.getPublic();
			// Conversion application
			application.setKeyPrismePrivate(RSAPrivateKeyUtility
					.convertRSAPrivateKey(priv));
			application.setKeyPrismePublic(RSAPublicKeyUtility
					.convertRSAPublicKey(pub));
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error("NoSuchAlgorithmException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur dans la génération des clés.");
		} catch (PrismeInvalidTokenException e) {
			LOGGER.error("PrismeInvalidTokenException : " + e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur dans la génération des clés.");
		}
	}

	public static void main(String[] args) {
		LOGGER.debug(" > generateKey");
		try {
			// Generation keyPair
			KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
			final int keyBitSize = 1024;
			keyGen.initialize(keyBitSize);
			KeyPair keyPair = keyGen.genKeyPair();
			// Generation clés privée et publique
			RSAPrivateKey priv = (RSAPrivateKey) keyPair.getPrivate();
			RSAPublicKey pub = (RSAPublicKey) keyPair.getPublic();
			// Conversion application
			String keyprivate = RSAPrivateKeyUtility.convertRSAPrivateKey(priv);
			String keyPrismePublic = RSAPublicKeyUtility
					.convertRSAPublicKey(pub);
			//LOGGER.debug(" > generateKey key privé " + keyprivate);
			//LOGGER.debug(" > generateKey key public " + keyPrismePublic);
			LOGGER.debug(" > basic authent "
					+ Base64.encodeBase64String(new String("user:password")
							.getBytes()));
			Cipher encrypt = Cipher.getInstance("RSA");
			encrypt.init(Cipher.ENCRYPT_MODE, priv);
			byte[] encryptedMessage = encrypt.doFinal("cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv:CLIENT-Mock44".getBytes());
			String messageEncode=Base64.encodeBase64String("cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv:CLIENT-Mock44:TEST".getBytes());
			LOGGER.debug(" message encodé " + messageEncode);
			Cipher decript = Cipher.getInstance("RSA");
			decript.init(Cipher.DECRYPT_MODE, pub);
			//byte[] decryptMessage = decript.doFinal(Base64.decodeBase64(messageEncode));
			//LOGGER.debug(" message " + new String(decryptMessage));
			
			RSAKey rsaKey = RSAKey.parse("{\"d\":\"H6xWB_xStxDubywrOa1JQObSpkBo3n0Fl6UDo8QGlzSBBNRQ2RliHNuaCg544J04LzIyFl2ShucXvYwD7wpAd9EIDx1iUUguSmjx0byO7JbKqEvO6FCFgPP6ag4gyu952YmBbA20Qo8QYTvFh17MaTgz5dIuGTZkrye4vPSveB0\",\"e\":\"AQAB\",\"qi\":\"bbWcaGFW46DmL0SS1M-OiyInj7aeOvhwGbQc9ZjnuEFCTqZQRbA06BWKfWUl0cUoXw-Ug1FGfslBxkhOdP6gBA\",\"q\":\"uRKGJT1W8WYSDQnxVWHwdcWinjn6BpY2FI2y4Ysgm1ZpL_vZzBYF4QhH45HEumktD840H09cD_WRdkPizlEL5w\",\"p\":\"8eo2clHMz0lY1qXYIfJYV1vPF9nyCqEPqNZ9kRXCVREa3rybNIfTIzpUGY0aMkbL1vt5hM-ksCl7zgYDeX1-gw\",\"n\":\"ruPClDp3b08U_RnppsJl5SB-lr7dZsXftE5-tj_D2YBybfyKwtB3ihlMSA0BKqTCeSN3F-mWc9v-dfnc_rs_6pQZntYuw1nWBFA0RvYle7gVtnCAVFySxwiWjZfwbv21Ke3e0YOAtsW7Ht8XecupLbGO_XgIYr-D4E34g3YfyTU\",\"kty\":\"RSA\",\"dq\":\"LKY2bNeOmTCZ3EFw0ruNKqyine-4zUwCAhVpeZZ6KF_Bgs0M73rEslSwG0v4nUxwjaae1orr2AHTtSeNmV7eMw\",\"dp\":\"raBZNZGqOrg878oWJr8mUoTNTSQayTAx6g8QDlqcoKtnKqgZiQlXK7iIddJFFAKl-IWDASR64gjUF9lPExpT-w\"}");
			//LOGGER.debug(" debug key " + RSAPrivateKeyUtility.convertRSAPrivateKey(rsaKey.toRSAPrivateKey()));
			//LOGGER.debug(" debug key public " + RSAPublicKeyUtility.convertRSAPublicKey(rsaKey.toRSAPublicKey()));
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error("NoSuchAlgorithmException : " + e.getMessage());

		} catch (Exception e) {
			LOGGER.error("PrismeInvalidTokenException : " + e.getMessage());

		}
	}
}
