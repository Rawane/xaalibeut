package fr.recouv.securite.prisme.authzserver.internal;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.jmock.Expectations;
import org.jmock.Mockery;

import fr.recouv.securite.prisme.authzserver.endpoint.TokenEndpoint;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * TokenEndpointInternal : <br>
 * Appel au TokenEndPoint depuis PSS (sans requete http)
 */
public class TokenEndpointInternal {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			TokenEndpointInternal.class).build();

	private static TokenEndpoint endPoint = new TokenEndpoint();

	/**
	 * Constructeur prive
	 */
	private TokenEndpointInternal() {
		// Constructeur prive
	}

	/**
	 * Holder
	 */
	private static class TokenEndpointInternalHolder {
		/** Instance unique non préinitialisée */
		private final static TokenEndpointInternal instance = new TokenEndpointInternal();
	}

	/**
	 * Point d'accès pour l'instance unique du singleton
	 * 
	 * @return TokenEndpointInternal instance
	 */
	public static TokenEndpointInternal getInstance() {
		return TokenEndpointInternalHolder.instance;
	}

	/**
	 * InternalServletInputStream
	 */
	class InternalServletInputStream extends ServletInputStream {
		InputStream inputStream;

		InternalServletInputStream(String inputStream) {
			this.inputStream = IOUtils.toInputStream(inputStream);
		}

		@Override
		public int read() throws IOException {
			return inputStream.read();
		}
	}

	/**
	 * mockHttpServletRequest
	 * 
	 * @param iStream
	 *            ServletInputStream
	 * @return HttpServletRequest
	 * @throws IOException
	 *             exception
	 */
	private HttpServletRequest mockHttpServletRequest(
			final ServletInputStream iStream) throws IOException {
		Mockery context = new Mockery();
		final HttpServletRequest servletRequest = context
				.mock(HttpServletRequest.class);
		context.checking(new Expectations() {
			{
				atLeast(1).of(servletRequest).getInputStream();
				will(returnValue(iStream));
			}
		});
		return servletRequest;
	}

	/**
	 * authorize
	 * 
	 * @param request
	 *            String
	 * @return Response response
	 * @throws PrismeSystemException
	 *             exception
	 */
	public Response authorize(final String request)
			throws PrismeSystemException {
		try {
			LOGGER.debug(" > authorize (internal)");
			// Mock InputStream
			final ServletInputStream iStream = TokenEndpointInternal
					.getInstance().new InternalServletInputStream(request);
			// Mock ServletRequest
			final HttpServletRequest servletRequest = mockHttpServletRequest(iStream);
			// Retour authorize
			return endPoint.authorize(servletRequest);
		} catch (IOException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur appel TokenEndpoint internal : " + e.getMessage());
		}
	}
}
