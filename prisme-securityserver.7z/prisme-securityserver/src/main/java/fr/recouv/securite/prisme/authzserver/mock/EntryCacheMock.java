package fr.recouv.securite.prisme.authzserver.mock;

import java.security.interfaces.RSAPublicKey;
import java.util.List;

import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisScope;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.StoreManager;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.security.utility.RSAPublicKeyUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * EntryCacheMock.
 */
public class EntryCacheMock {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			EntryCacheMock.class).build();

	static {
		LOGGER.debug(" > init Mock ");
		// Init ScopeStore
		try {
			String user = "CER4400468";
			// Valeur CodeOrg
			String encodedRequestScope = PrismeRequestScope.set()
					.add("UR527", "SNV2-PROD").encode();
			PrismeAnaisScope.getResponseScope(user, encodedRequestScope);
			// Valeur All
			encodedRequestScope = PrismeRequestScope.set()
					.add("*", "SNV2-PROD").encode();
			PrismeAnaisScope.getResponseScope(user, encodedRequestScope);
		} catch (PrismeSystemException e) {
			LOGGER.error(e.getMessage());
		}
		// Init KeyStore
		try {
			RSAPublicKey rsaPub;
			// Valeur 1
			rsaPub = RSAPublicKeyUtility
					.convertToRSAPublicKey("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCKiziP2w6wgqppbZA3WMHnEwW2tKkxn1hvtfXTic"
							+ "pVdmmVR2Khddk+4zqNYIeMESeDURI4Ox1eX2EmBmkuyolJ5VWnIDXtohU5tMD/j3oT6hfq+Tpv/4ZjaKZ/RK+GpVWY8"
							+ "VgtosH8DBosx4uU6yA31ct8AyYU47OvnChvn8cGYwIDAQAB");
			StoreManager.keyStore
					.put("cn=USR_READ_NAT_APP_MIXTE-MOCK,ou=MIXTE-MOCK,ou=Applications,OU=Technique,dc=recouv",
							rsaPub);
			// Valeur 2
			rsaPub = RSAPublicKeyUtility
					.convertToRSAPublicKey("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCjkWyBeP0+XlmPXcvhT0Va+0MCAN8MQ6E8RfCzKp"
							+ "qZKgXUr7dI3Q/OoFczoW2ErkOeHzeKP9fOQKwDWpbkySD7NmV+fTvF5BACr0ZR03qyLKT+I8SQGdi3O0DJ2Nc3Y4aJV"
							+ "jfELKz8qpsFFYiy5t3BWEZBHPsxVdzXDdXLB3jjvwIDAQAB");
			StoreManager.keyStore
					.put("cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv",
							rsaPub);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	/**
	 * @param nomCache
	 *            String
	 * @return String
	 */
	public static String stats(final String nomCache) {
		if ("key-store".equals(nomCache)) {
			return StoreManager.keyStore.stats();
		} else {
			return StoreManager.scopeStore.stats();
		}
	}

	/**
	 * @param nomCache
	 *            String
	 * @return List EntryCache
	 */
	public static List<EntryCache> liste(final String nomCache) {
		if ("key-store".equals(nomCache)) {
			return StoreManager.keyStore.list();
		} else {
			return StoreManager.scopeStore.list();
		}
	}

	/**
	 * @param nomCache String
	 * @param key String
	 */
	public static void remove(final String nomCache, final String key) {
		if ("key-store".equals(nomCache)) {
			StoreManager.keyStore.remove(key);
		} else {
			StoreManager.scopeStore.remove(key);
		}
	}

	/**
	 * @param nomCache String
	 */
	public static void removeAll(final String nomCache) {
		if ("key-store".equals(nomCache)) {
			StoreManager.keyStore.removeAll();
		} else {
			StoreManager.scopeStore.removeAll();
		}
	}
}
