package fr.recouv.securite.prisme.authzserver.store;

import java.util.List;

import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;

/**
 * IStore : Interface commune a tous les stores.
 */
public interface IStore {

	/**
	 * Retourne le contenu du store au format List EntryCache.
	 * 
	 * @return List EntryCache
	 */
	List<EntryCache> list();

	/**
	 * Retourne les stats au format String.
	 * 
	 * @return String
	 */
	String stats();

	/**
	 * Retourne la taille du cache.
	 * 
	 * @return int
	 */
	int size();

	/**
	 * Suppprime l'entree par sa cle.
	 * 
	 * @param key
	 *            String
	 * @throws PrismeException
	 *             exception
	 */
	void remove(final String key) throws PrismeException;

	/**
	 * Suppprime tout le cache.
	 * 
	 * @throws PrismeException
	 *             exception
	 */
	void removeAll() throws PrismeException;
}
