package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * FormLoadMetiersNatRef.
 */
public class FormLoadMetiersNatRef implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 4523681353404877063L;

	@JsonProperty
	private String codeApp;

	@JsonProperty
	private String codeOrg;

	@JsonProperty
	private String metiersNatRef;

	/**
	 * Constructeur simple.
	 */
	public FormLoadMetiersNatRef() {
		// Constructeur simple
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCodeApp() {
		return this.codeApp;
	}

	/**
	 * @param codeApp
	 *            String
	 */
	public void setCodeApp(final String codeApp) {
		this.codeApp = codeApp;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCodeOrg() {
		return this.codeOrg;
	}

	/**
	 * @param codeOrg
	 *            String
	 */
	public void setCodeOrg(final String codeOrg) {
		this.codeOrg = codeOrg;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMetiersNatRef() {
		return this.metiersNatRef;
	}

	/**
	 * @param metiersNatRef
	 *            String
	 */
	public void setMetiersNatRef(final String metiersNatRef) {
		this.metiersNatRef = metiersNatRef;
	}


}
