package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;
import java.security.interfaces.RSAPrivateKey;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.types.PrismeGrantType;
import fr.recouv.securite.prisme.commun.security.factory.JWTTokenFactory;
import fr.recouv.securite.prisme.commun.security.utility.RSAPrivateKeyUtility;
import fr.recouv.securite.prisme.commun.token.JWTToken;
import fr.recouv.securite.prisme.commun.utils.json.JSONUtils;

/**
 * FormAccessToken.
 */
public class FormAccessToken implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 4148355483451429638L;

	@JsonProperty
	private String cinematique;

	@JsonProperty
	private String clientId;

	@JsonProperty
	private String clientSecret;

	@JsonProperty
	private String username;

	@JsonProperty
	private String password;

	@JsonProperty
	private String scope;

	@JsonProperty
	private String subject;

	@JsonProperty
	private String filePrivateKey;

	@JsonProperty
	private String jetonInterOps;

	@JsonProperty
	private String jetonOcean;

	/**
	 * Constructeur simple.
	 */
	public FormAccessToken() {
		// Constructeur simple
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCinematique() {
		return this.cinematique;
	}

	/**
	 * @param cinematique
	 *            String
	 */
	public void setCinematique(final String cinematique) {
		this.cinematique = cinematique;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getClientId() {
		return this.clientId;
	}

	/**
	 * @param clientId
	 *            String
	 */
	public void setClientId(final String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getClientSecret() {
		return this.clientSecret;
	}

	/**
	 * @param clientSecret
	 *            String
	 */
	public void setClientSecret(final String clientSecret) {
		this.clientSecret = clientSecret;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getUsername() {
		return this.username;
	}

	/**
	 * @param username
	 *            String
	 */
	public void setUsername(final String username) {
		this.username = username;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPassword() {
		return this.password;
	}

	/**
	 * @param password
	 *            String
	 */
	public void setPassword(final String password) {
		this.password = password;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getScope() {
		return this.scope;
	}

	/**
	 * @param scope
	 *            String
	 */
	public void setScope(final String scope) {
		this.scope = scope;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getSubject() {
		return this.subject;
	}

	/**
	 * @param subject
	 *            String
	 */
	public void setSubject(final String subject) {
		this.subject = subject;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getFilePrivateKey() {
		return this.filePrivateKey;
	}

	/**
	 * @param filePrivateKey
	 *            String
	 */
	public void setFilePrivateKey(final String filePrivateKey) {
		this.filePrivateKey = filePrivateKey;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getJetonInterOps() {
		return this.jetonInterOps;
	}

	/**
	 * @param jetonInterOps
	 *            String
	 */
	public void setJetonInterOps(final String jetonInterOps) {
		this.jetonInterOps = jetonInterOps;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getJetonOcean() {
		return this.jetonOcean;
	}

	/**
	 * @param jetonOcean
	 *            String
	 */
	public void setJetonOcean(final String jetonOcean) {
		this.jetonOcean = jetonOcean;
	}

	/**
	 * Construit le resultat de la requete Demande sous forme JSON.
	 * 
	 * @return String
	 * @exception PrismeSystemException
	 *                exception
	 */
	public String buildRequeteDemande() throws PrismeSystemException {
		String stringResult = "";
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		// scope
		String encodedScopes = PrismeRequestScope.set()
				.addScopeComplete(this.scope).encode();
		result.put("scope", encodedScopes);
		// client_id
		result.put("client_id", this.clientId);
		// client_secret
		result.put("client_secret", this.clientSecret);
		// Suivant cinematique
		if ("CC".equals(this.cinematique)) {
			// cinematique = CC
			result.put("grant_type", PrismeGrantType.CONSUMER_CREDENTIALS);
			result.put(PrismeParams.USERNAME, this.username);
			result.put(PrismeParams.PWD, this.password);
		} else if ("JWT".equals(this.cinematique)) {
			// cinematique = JWT
			result.put("grant_type", PrismeGrantType.JWT_TOKEN);
			result.put("assertion_type", PrismeParams.TOKEN.JWT_TYPE);
			try {
				// Recuperation privateKey
				RSAPrivateKey privateKey = RSAPrivateKeyUtility
						.convertToRSAPrivateKey(this.filePrivateKey);
				// Generation JWT entry
				JWTToken token = JWTTokenFactory.init()
						.setIssuer(this.clientId).setSubject(this.subject)
						.setIssueTime(new Date()).setScope(encodedScopes)
						.setPrivateKey(privateKey).build();
				result.put("assertion", token.value());
			} catch (PrismeInvalidTokenException e) {
				// Lancement Exception
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"PrismeInvalidTokenException, " + e.getMessage());
			}
		} else if ("InterOps".equals(this.cinematique)) {
			// cinematique = InterOps
			result.put("grant_type", PrismeGrantType.INTEROPS_TOKEN);
			result.put("assertion_type", PrismeParams.TOKEN.INTEROPS_TYPE);
			result.put("assertion", this.jetonInterOps);
		} else if ("Ocean".equals(this.cinematique)) {
			// cinematique = Ocean
			result.put("grant_type", PrismeGrantType.OCEAN_TOKEN);
			result.put("assertion_type", PrismeParams.TOKEN.OCEAN_TYPE);
			result.put("assertion", this.jetonOcean);
		}
		stringResult = JSONUtils.build(result);
		// Formatage
		stringResult = stringResult.replace("{", "{\n");
		stringResult = stringResult.replace("\",\"", "\",\n\"");
		stringResult = stringResult.replace("}", "\n}");
		// Retour
		return stringResult;
	}
}
