package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import net.minidev.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * JSONResponse.
 */
public class JSONResponse implements Serializable {

	private static final long serialVersionUID = 6122860758843554760L;

	// General
	@JsonProperty
	public String result;

	@Override
	public String toString() {
		JSONObject json = new JSONObject();
		json.put("result", result);
		return json.toJSONString();
	}
}
