package fr.recouv.securite.prisme.authzserver.anais;

import javax.naming.NamingException;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisUID;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisUser.
 */
public class PrismeAnaisUser {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisUser.class).build();

	private static final String CONTEXT_NAME = "reader";

	/**
	 * byUid.
	 * 
	 * @param uid
	 *            String
	 * @return AnaisUser
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 * @throws PrismeSystemException
	 *             exception
	 */
	public static AnaisUser byUID(String uid) throws AnaisExceptionFailure,
			AnaisExceptionServerCommunication, NamingException, PrismeSystemException {
		LOGGER.debug(" > byUid");
		AnaisUID anaisUID = AnaisUID.set(uid);
		if (!anaisUID.isAnValidateUID()) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"AnaisUser inconnu : " + uid);
		}
		AnaisUser anaisUser = AnaisUser.build.get(CONTEXT_NAME).by(anaisUID)
				.execute();
		if (anaisUser == null) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"AnaisUser inconnu : " + uid);
		}
		return anaisUser;
	}

	/**
	 * withAccount.
	 * 
	 * @param userId
	 *            String
	 * @param userSecret
	 *            String
	 * @return AnaisUser
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static AnaisUser withAccount(String userId, String userSecret)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException {
		LOGGER.debug(" > withAccount");
		AnaisUser anaisUser = AnaisUser.build.set(CONTEXT_NAME)
				.withAccount(userId, userSecret).authenticate();
		return anaisUser;
	}
}
