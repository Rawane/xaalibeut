package fr.recouv.securite.prisme.authzserver.provider;

import javax.servlet.http.HttpServletResponse;

import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisUID;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.response.PrismePopulateServerResponse;
import fr.recouv.securite.prisme.authzserver.response.PrismeTokenServerResponse;
import fr.recouv.securite.prisme.authzserver.store.AnaisUserStoreWithGuavaCache;
import fr.recouv.securite.prisme.authzserver.store.StoreManager;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.PrismeAnaisUser;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.PrismeProtocoleError;
import fr.recouv.securite.prisme.commun.message.response.PrismeResponse;
import fr.recouv.securite.prisme.commun.message.types.PrismePopulateType;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * IdentityProducer.
 */
public class IdentityProducer implements PrismePopulateServerProvider {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			IdentityProducer.class).build();

	private static AnaisUserStoreWithGuavaCache users = StoreManager.anaisUserStore;

	private String key;

	public IdentityProducer(String key) {
		this.key = key;
	}

	@Override
	public PrismeResponse compose() throws PrismeSystemException {

		AnaisUser anaisUser = null;
		try {
			AnaisUID uid = AnaisUID.set(key);
			if (uid.isAnValidateUID()) {
				anaisUser = users.get(key);
			}
		} catch (PrismeSystemException e) {
			LOGGER.debug("PrismeSystemException : " + e.getMessage());
			return onUserLoadError(e.getMessage());
		}
		// Si anaisUser
		if (anaisUser != null) {
			PrismeResponse response = PrismePopulateServerResponse
					.response(HttpServletResponse.SC_OK)
					.setParam(PrismeParams.POPULATE.TYPE,
							PrismePopulateType.IDENTITY.toString())
					.setParam(PrismeAnaisUser.UID.toString(),
							anaisUser.getUid().value())
					.setParam(PrismeAnaisUser.IDSNV2.toString(),
							anaisUser.getPersIdSnv2().value())
					.setParam(PrismeAnaisUser.CN.toString(),
							anaisUser.getCn().value())
					.setParam(PrismeAnaisUser.SN.toString(),
							anaisUser.getSn().value())
					.setParam(PrismeAnaisUser.GIVENNAME.toString(),
							anaisUser.getGivenName().value())
					.setParam(PrismeAnaisUser.CODEORG.toString(),
							anaisUser.getOu().value())
					.setParam(PrismeAnaisUser.MAIL.toString(),
							anaisUser.getMail().value())
					.setParam(PrismeAnaisUser.DATE_ENTREE_RH.toString(),
							anaisUser.getDateEntreeRh().value())
					.setParam(PrismeAnaisUser.DATE_SORTIE_RH.toString(),
							anaisUser.getDateSortieRh().value())
					.setParam(PrismeAnaisUser.CODE_EMPLOI_UCANSS.toString(),
							anaisUser.getPersCodeEmploiUcanss().value())
					.setParam(PrismeAnaisUser.LIBELLE_EMPLOI.toString(),
							anaisUser.getPersLibelleEmploi().value())
					.setParam(PrismeAnaisUser.CODEORG_GRH.toString(),
							anaisUser.getPersCodeOrgGrh().value())
					.setParam(PrismeAnaisUser.DONATIRMAIL.toString(),
							anaisUser.getPersDonatirmail().value())
					.setParam(PrismeAnaisUser.TYPECONTRAT.toString(),
							anaisUser.getPersTypeContrat().value())
					.setParam(PrismeAnaisUser.GIVENNAME_GRH.toString(),
							anaisUser.getPersGRHgivenname().value())
					.setParam(PrismeAnaisUser.TELEPHONE_MUMBER.toString(),
							anaisUser.getTelephoneNumber().value())
					.setParam(PrismeAnaisUser.MOBILE.toString(),
							anaisUser.getMobile().value())
					.setParam(PrismeAnaisUser.SIEGE_LIB.toString(),
							anaisUser.getO().value())
					.setParam(PrismeAnaisUser.SIEGE_ADRESSE.toString(),
							anaisUser.getL().value())
					.setParam(PrismeAnaisUser.ETAB_CODE.toString(),
							anaisUser.getPersEtabCode().value())
					.setParam(PrismeAnaisUser.ETAB_LIB.toString(),
							anaisUser.getPersEtabLib().value())
					.setParam(PrismeAnaisUser.ETAB_SIRET.toString(),
							anaisUser.getPersEtabSiret().value())
					.setParam(PrismeAnaisUser.ETAB_ADRESSE.toString(),
							anaisUser.getPersEtabAdresse().value())
					.setParam(PrismeAnaisUser.CODE_DEPT.toString(),
							anaisUser.getPersCodeDept().value())
					.setParam(PrismeAnaisUser.VILLE.toString(),
							anaisUser.getPersNomVille().value())
					.setParam(PrismeAnaisUser.TYPAGE_AGENT.toString(),
							anaisUser.getPersTypageAgent().value())
					.setParam(PrismeAnaisUser.ORIGINE_SOURCE.toString(),
							anaisUser.getOrigineSource().value())
					.buildJSONMessage();
			return response;
		} else {
			// message d'erreur
			LOGGER.debug("Exception : anaisUser null pour parametre " + key);
			return onUserLoadError(PrismeProtocoleError.POPULATE_PROTOCOLE.ERRORONUSERLOAD_MESSAGE);
		}
	}

	/**
	 * @param msg
	 *            String
	 * @return PrismeResponse
	 * @throws PrismeSystemException
	 *             exception
	 */
	private PrismeResponse onUserLoadError(String msg)
			throws PrismeSystemException {
		LOGGER.error("Exception sur Populate : " + msg);
		return PrismeTokenServerResponse
				.onError(HttpServletResponse.SC_BAD_REQUEST)
				.setErrorCode(
						PrismeProtocoleError.POPULATE_PROTOCOLE.ERRORONUSERLOAD_CODE)
				.setErrorMessage(msg).buildJSONMessage();
	}
}
