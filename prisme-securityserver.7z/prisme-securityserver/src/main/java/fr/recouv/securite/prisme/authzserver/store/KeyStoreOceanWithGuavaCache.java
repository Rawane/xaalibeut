package fr.recouv.securite.prisme.authzserver.store;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisAppKeyOcean;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisTechnicalAccount;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * KeyStoreOceanWithGuavaCache. <br>
 * 
 * Cache Local de clé OCEAN, egalement stockée dans Anais. <br>
 * Insertion cle : <br>
 * - Stockage cle local <br>
 * - Si Anais different, stockage sur Anais <br>
 * Recuperation cle : <br>
 * - Depuis cache local <br>
 * - Si absent, recuperation depuis Anais <br>
 */
public class KeyStoreOceanWithGuavaCache implements IStore {

	private static final PrismeLogger logger = new PrismeLogger().in(
			KeyStoreOceanWithGuavaCache.class).build();

	// Cache <String(client_id), RSAPublicKey>
	private static LoadingCache<String, String> cache;

	private static final long expireAfterWrite = 72000;

	/**
	 * Constructeur.
	 */
	public KeyStoreOceanWithGuavaCache() {
		// Init cache
		cache = CacheBuilder.newBuilder().recordStats()
				.expireAfterWrite(72000, TimeUnit.SECONDS)
				.build(new CacheLoader<String, String>() {
					@Override
					public String load(String clientId)
							throws PrismeSystemException {
						return loadOceanKeyFromAnais(clientId);
					}
				});
	}

	@Override
	public List<EntryCache> list() {
		List<EntryCache> liste = new ArrayList<EntryCache>();
		for (String key : cache.asMap().keySet()) {
			liste.add(new EntryCache(key, (String) cache.asMap().get(key)));
		}
		return liste;
	}

	@Override
	public String stats() {
		return CacheStatsUtility
				.getStatsFromGuavaCache(cache, expireAfterWrite);
	}

	@Override
	public int size() {
		if (cache != null) {
			return cache.asMap().size();
		}
		return 0;
	}


	@Override
	public void remove(final String key) {
		cache.invalidate(key);
	}

	@Override
	public void removeAll() {
		cache.invalidateAll();
	}

	/**
	 * Recuperation depuis cache.
	 * 
	 * @param clientId
	 *            String
	 * @return String
	 * @throws PrismeSystemException
	 *             exception
	 */
	public String get(String clientId) throws PrismeSystemException {
		try {
			// Recuperation depuis cache
			logger.debug("Recuperation cle par id:" + clientId);
			return cache.get(clientId);
		} catch (ExecutionException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur lors de la récupération de l'application sur Anais.");
		}
	}

	/**
	 * Mise en cache.
	 * 
	 * @param clientId
	 *            String
	 * @param localKey
	 *            String
	 * @throws PrismeSystemException
	 *             exception
	 */
	public void put(String clientId, String localKey)
			throws PrismeSystemException {
		try {
			// Mise en cache
			logger.debug("Enregistrement cle par id:" + clientId);
			cache.put(clientId, localKey);
			// Recuperation Anais
			AnaisTechnicalAccount technicalAccount = PrismeAnaisTechnicalAccount
					.byDN(clientId);
			String anaisPK = technicalAccount.getKeyOcean().value();
			// Si enregistrement Anais different de l'actuel
			if (!anaisPK.equals(localKey)) {
				// Sauvegarde Anais
				technicalAccount.setKeyOcean(AnaisAppKeyOcean.set(localKey));
				PrismeAnaisTechnicalAccount.save(technicalAccount);
			}
		} catch (NamingException e) {
			logger.error("NamingException - Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"NamingException : " + e.getMessage());
		} catch (AnaisExceptionFailure e) {
			logger.error("AnaisExceptionFailure - Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"AnaisExceptionFailure : " + e.getMessage());
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("AnaisExceptionServerCommunication - Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"AnaisExceptionServerCommunication : " + e.getMessage());
		}
	}

	/**
	 * Enrichissement du store pour le client ID par la cle OCEAN issu d ANAIS.
	 * 
	 * @param clientId
	 *            String
	 * @return OceanKey chaine de caractere representant la clé.
	 * @throws PrismeSystemException
	 *             exception
	 */
	private static String loadOceanKeyFromAnais(String clientId)
			throws PrismeSystemException {

		logger.debug("Enrichissement OceanKey pour:" + clientId);
		try {
			// Recuperation Anais
			AnaisTechnicalAccount technicalAccount = PrismeAnaisTechnicalAccount
					.byDN(clientId);
			// Si techAccount null, exception
			if (technicalAccount == null) {
				logger.error("Exception lors de la recuperation Anais : application inconnue");
				throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
						"Erreur Anais dans le chargement de l'application.");
			}
			String anaisPK = technicalAccount.getKeyOcean().value();
			// Retour
			return anaisPK;
		} catch (NamingException e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (AnaisExceptionFailure e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		} catch (AnaisExceptionServerCommunication e) {
			logger.error("Exception lors de la recuperation Anais : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur Anais : " + e.getMessage());
		}
	}
}
