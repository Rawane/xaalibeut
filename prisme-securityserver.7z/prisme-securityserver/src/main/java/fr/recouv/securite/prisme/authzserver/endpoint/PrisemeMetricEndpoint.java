/**
 * 
 */
package fr.recouv.securite.prisme.authzserver.endpoint;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.SortedMap;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.google.common.base.Splitter;

import fr.recouv.securite.prisme.authzserver.listener.PrismeMetricsServletContextListener;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * @author cer4495267
 * 
 */
@Path("/metrics/{version}")
public class PrisemeMetricEndpoint {
	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrisemeMetricEndpoint.class).build();

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String ping() {
		LOGGER.debug("ping");
		return "ping from PrisemeMetricEndpoint!";
	}

	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public Response metrics() {
		ResponseBuilder response = Response.status(
				HttpServletResponse.SC_BAD_REQUEST).entity(
				"Erreur lors de la récupération des métrics");
		MetricRegistry metricRegistry = PrismeMetricsServletContextListener.METRIC_REGISTRY;
		List<MetricJersey> metrics = new ArrayList<>();
		SortedMap<String, Timer> timers = metricRegistry.getTimers();
		for (String key : timers.keySet()) {
			Timer timer = timers.get(key);
			List<String> keyElements = Splitter.on(".").splitToList(key);
			MetricJersey metricJersey = new MetricJersey();
			String packageName = "";
			for (int i = 0; i < keyElements.size() - 2; i++) {
				packageName = packageName + keyElements.get(i) + ".";
			}
			metricJersey.setPackageName(packageName);
			metricJersey.setClassName(keyElements.get(keyElements.size() - 2));
			metricJersey.setMethod(keyElements.get(keyElements.size() - 1));
			try {
				Class<?> endPoint = Class.forName(metricJersey.getPackageName()
						+ metricJersey.getClassName());
				Path annotClasse = endPoint.getAnnotation(Path.class);
				metricJersey.setPath(annotClasse.value());
				// LOGGER.info("annotations " + annotClasse);
				// Method method = endPoint.getMethod(metricJersey.getMethod());
				Method[] methods = endPoint.getMethods();
				for (Method method : methods) {
					if (method.getName().equals(metricJersey.getMethod())) {
						Path pathAnnotation = method.getAnnotation(Path.class);
						if (pathAnnotation != null) {
							metricJersey.setPath(pathAnnotation.value());
						}
						break;
					}

				}
				metricJersey.setCount(timer.getCount());
				metricJersey.setMoy(timer.getMeanRate());
				metricJersey.setMin(timer.getSnapshot().getMin());
				metricJersey.setMax(timer.getSnapshot().getMax());
				LOGGER.info(" taille reservoire  "
						+ timer.getSnapshot().getValues().length);
			} catch (Exception exception) {
				// TODO Auto-generated catch block
				exception.printStackTrace();
			}
			LOGGER.info(key + " timer " + timer);
			metrics.add(metricJersey);
		}
		Comparator<? super MetricJersey> c = new Comparator<MetricJersey>() {
			@Override
			public int compare(MetricJersey o1, MetricJersey o2) {

				return (int) (o2.getCount() - o1.getCount());
			}
		};
		Collections.sort(metrics, c);
		response = Response.status(HttpServletResponse.SC_OK).entity(metrics);
		return response.build();
	}
}
