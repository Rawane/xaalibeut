package fr.recouv.securite.prisme.authzserver.store;

import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;

/**
 * StoreManager : <br>
 * Gestionnaire de Store.
 */
public class StoreManager {

	/** Mode DEV : false pour desactiver le chargement de PrismeContexteDescriptor **/
	private static boolean loadDescriptor = true;
	public static ScopeStoreWithGuavaCache scopeStore;
	public static KeyStoreWithGuavaCache keyStore;
	public static KeyStoreOceanWithGuavaCache keyStoreOcean;
	public static AnaisUserStoreWithGuavaCache anaisUserStore;
	public static AnaisClientStoreWithGuavaCache anaisClientStore;
	public static AnaisAppsStoreWithGuavaCache anaisAppsStore;
	public static PermissionsStoreFromAnaisWithGuavaCache permissionsStore;

	static {
		scopeStore = new ScopeStoreWithGuavaCache();
		if (loadDescriptor) {
			keyStore = (KeyStoreWithGuavaCache) PrismeContexteDescriptor
					.getKeyStore();
		} else {
			keyStore = new KeyStoreWithGuavaCache();
		}
		keyStoreOcean = new KeyStoreOceanWithGuavaCache();
		anaisUserStore = new AnaisUserStoreWithGuavaCache();
		if (loadDescriptor) {
			anaisClientStore = new AnaisClientStoreWithGuavaCache(
					PrismeContexteDescriptor
							.getAnaisClientStoreExpirationTime());
		} else {
			anaisClientStore = new AnaisClientStoreWithGuavaCache();
		}
		anaisAppsStore = new AnaisAppsStoreWithGuavaCache();
		permissionsStore = (PermissionsStoreFromAnaisWithGuavaCache) PrismeContexteDescriptor.getPermissionsStore();
	}

	/**
	 * Liste des Stores
	 */
	public enum NomStore {
		SCOPE_STORE("scope-store"),
		KEY_STORE("key-store"),
		KEY_STORE_OCEAN("key-store-ocean"),
		ANAIS_USER_STORE("anais-user-store"),
		ANAIS_CLIENT_STORE("anais-client-store"),
		ANAIS_APPS_STORE("anais-apps-store"),
		PERMISSIONS_STORE("permissions-store");

		private String nomStore;

		NomStore(final String nomStore) {
			this.nomStore = nomStore;
		}

		@Override
		public String toString() {
			return this.nomStore;
		}

		public static NomStore toValue(final String nomStore) {
			for (final NomStore enumNomStore : NomStore.values()) {
				if (enumNomStore.nomStore.equals(nomStore)) {
					return enumNomStore;
				}
			}
			return null;
		}
	}

	/**
	 * Valide le nom du store.
	 * 
	 * @param paramNomStore
	 *            String
	 * @return true si nom valide, false sinon.
	 */
	public static boolean isValidStore(final String paramNomStore) {
		return (NomStore.toValue(paramNomStore) != null);
	}

	/**
	 * Retourne le store correspondant au nom.
	 * 
	 * @param paramNomStore
	 *            String
	 * @return Object implementant IStore
	 */
	public static IStore getStore(final String paramNomStore) {
		// Conversion en nomStore
		NomStore nomStore = NomStore.toValue(paramNomStore);
		IStore store = null;
		if (nomStore != null) {
			switch (nomStore) {
			// Scope Store
			case SCOPE_STORE:
				store = scopeStore;
				break;
			// Key Store
			case KEY_STORE:
				store = keyStore;
				break;
			// Key Store Ocean
			case KEY_STORE_OCEAN:
				store = keyStoreOcean;
				break;
			// Anais User Store
			case ANAIS_USER_STORE:
				store = anaisUserStore;
				break;
			// Anais Client Store
			case ANAIS_CLIENT_STORE:
				store = anaisClientStore;
				break;
			// Anais Apps Store
			case ANAIS_APPS_STORE:
				store = anaisAppsStore;
				break;
			// Permissions Store
			case PERMISSIONS_STORE:
				store = permissionsStore;
				break;
			default:
				break;
			}
		}
		return store;
	}

	/**
	 * Retourne le nb total d'elements dans tous les stores.
	 * 
	 * @return int
	 */
	public static int sumSizeAllStore() {
		int nbTotal = 0;
		nbTotal += scopeStore.size();
		nbTotal += keyStore.size();
		nbTotal += keyStoreOcean.size();
		nbTotal += anaisUserStore.size();
		nbTotal += anaisClientStore.size();
		nbTotal += anaisAppsStore.size();
		nbTotal += permissionsStore.size();
		return nbTotal;
	}
}
