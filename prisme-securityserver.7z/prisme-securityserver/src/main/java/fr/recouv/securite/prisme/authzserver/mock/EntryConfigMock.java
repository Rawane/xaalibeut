package fr.recouv.securite.prisme.authzserver.mock;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.minidev.json.JSONObject;
import fr.recouv.securite.prisme.commun.config.bean.Config;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * EntryConfigMock : pour mocker contenu Registry Store.
 */
public class EntryConfigMock {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			EntryConfigMock.class).build();

	private static Map<String, Config> map;

	static {
		LOGGER.debug(" > init Mock ");
		// Initialisation liste Config
		EntryConfigMock.map = new HashMap<String, Config>();
		// Data
		Config config;

		// Mock 1
		config = new Config();
		config.nodeId = "2db1291127be11966377afaf2072cb13";
		config.version = "undefined";
		config.authenticator = "fr.recouv.securite.prisme.resourceserver.authenticator.JWTAuthenticator";
		config.authorizer = "fr.recouv.securite.prisme.resourceserver.authorizer.WithDualModeAuthorizer";
		config.client_id = "cn=USR_READ_NAT_APP_MIXTE-MOCK,ou=MIXTE-MOCK,ou=Applications,OU=Technique,dc=recouv";
		config.http_client = "fr.recouv.securite.prisme.client.HttpClientWithOkHttp3";
		config.token_endpoint = "http://pss.gidn.recouv/pss/endpoint/token/1/";
		config.authz_endpoint = "http://pss.gidn.recouv/pss/endpoint/authz/1/";
		config.registry_endpoint = "http://pss.gidn.recouv/pss/endpoint/registry/1/";
		config.populate_endpoint = "http://pss.gidn.recouv/pss/endpoint/populate/1/";
		config.token_store = "fr.recouv.securite.prisme.commun.store.TokenStoreWithGuavaCache";
		config.identity_store = "fr.recouv.securite.prisme.commun.store.IdentityStoreWithGuavaCache";
		config.permissions_store = "fr.recouv.securite.prisme.commun.store.PermissionsStoreWithGuavaCache";
		config.jmx_activated = "true";
		config.security_options = "private_key_file=/MIXTE-MOCK-PrivateKey.pem,public_key_file=/MIXTE-MOCK-PublicKey.pem";
		config.provider_permissions_loader = "fr.recouv.securite.prisme.commun.loader.ListUrlPermissionsLoader";
		config.provider_permissions_file = "listeUrlMetiersNat.txt";
		config.permissions_cache_max_entries = -1;
		config.permissions_validity_in_s = -1;
		config.identity_cache_max_entries = 5000;
		config.identity_validity_in_s = 900;
		config.token_cache_max_entries = 15000;
		config.token_validity_in_s = 36000;
		config.registry_date = new Date();
		config.pss_nodeId = "2da1f484e5947c3710876c33567dc49b";
		EntryConfigMock.map.put(config.nodeId, config);

		// Mock 2
		config = new Config();
		config.nodeId = "7089351dc7e262fee395fba0e5cc2f40";
		config.version = "1.0.6";
		config.authenticator = "fr.recouv.securite.prisme.resourceserver.authenticator.JWTAuthenticator";
		config.authorizer = "fr.recouv.securite.prisme.resourceserver.authorizer.WithDualModeAuthorizer";
		config.client_id = "cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv";
		config.http_client = "fr.recouv.securite.prisme.client.HttpClientWithOkHttp3";
		config.token_endpoint = "http://pss.gidn.recouv/pss/endpoint/token/1/";
		config.authz_endpoint = "http://pss.gidn.recouv/pss/endpoint/authz/1/";
		config.registry_endpoint = "http://pss.gidn.recouv/pss/endpoint/registry/1/";
		config.populate_endpoint = "http://pss.gidn.recouv/pss/endpoint/populate/1/";
		config.token_store = "fr.recouv.securite.prisme.commun.store.TokenStoreWithGuavaCache";
		config.identity_store = "fr.recouv.securite.prisme.commun.store.IdentityStoreWithGuavaCache";
		config.permissions_store = "fr.recouv.securite.prisme.commun.store.PermissionsStoreWithGuavaCache";
		config.jmx_activated = "true";
		config.security_options = "private_key_file=/CLIENT-MOCK-PrivateKey.pem,public_key_file=/CLIENT-MOCK-PublicKey.pem";
		config.provider_permissions_loader = "fr.recouv.securite.prisme.commun.loader.ListUrlPermissionsLoader";
		config.provider_permissions_file = "listeUrlMetiersNat.txt";
		config.permissions_cache_max_entries = -1;
		config.permissions_validity_in_s = -1;
		config.identity_cache_max_entries = 5000;
		config.identity_validity_in_s = 900;
		config.token_cache_max_entries = 15000;
		config.token_validity_in_s = 36000;
		config.registry_date = new Date();
		config.pss_nodeId = "f057b3c96d7b7ca835092e601011a448";
		EntryConfigMock.map.put(config.nodeId, config);
	}

	/**
	 * cacheRegistryMock : Mock le contenu du cache Registry.
	 * 
	 * @return Map String Config
	 */
	public static Map<String, Config> cacheRegistryMock() {
		return EntryConfigMock.map;
	}

	/**
	 * Contains Config.
	 * 
	 * @param nodeId
	 *            String
	 * @return boolean
	 */
	public static boolean contains(final String nodeId) {
		return EntryConfigMock.map.containsKey(nodeId);
	}

	/**
	 * Remove.
	 * 
	 * @param nodeId
	 *            String
	 */
	public static void remove(final String nodeId) {
		EntryConfigMock.map.remove(nodeId);
	}

	/**
	 * RemoveAll.
	 */
	public static void removeAll() {
		EntryConfigMock.map.clear();
	}

	/**
	 * Stats.
	 * 
	 * @return String
	 */
	public static String stats() {
		JSONObject response = new JSONObject();
		JSONObject detail = new JSONObject();
		detail.put("status", "NOT RUNNING");
		response.put("cache-registry", detail);
		return response.toJSONString();
	}

	/**
	 * @return String
	 */
	public static String start() {
		JSONObject response = new JSONObject();
		response.put("result", "OK");
		return response.toJSONString();
	}

	/**
	 * @return String
	 */
	public static String stop() {
		JSONObject response = new JSONObject();
		response.put("result", "OK");
		return response.toJSONString();
	}
}
