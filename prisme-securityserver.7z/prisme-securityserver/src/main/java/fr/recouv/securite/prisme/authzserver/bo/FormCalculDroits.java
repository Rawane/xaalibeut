package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * FormCalculDroits.
 */
public class FormCalculDroits implements Serializable {

	/** serialVersionUID. */
	private static final long serialVersionUID = 5269639175879789915L;

	@JsonProperty
	private String subject;

	@JsonProperty
	private String scope;

	/**
	 * Constructeur simple.
	 */
	public FormCalculDroits() {
		// Constructeur simple
	}

	/**
	 * @return the subject
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getSubject() {
		return this.subject;
	}

	/**
	 * @param subject
	 *            the subject to set
	 */
	public final void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the scope
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public final String getScope() {
		return this.scope;
	}

	/**
	 * @param scope
	 *            the scope to set
	 */
	public final void setScope(String scope) {
		this.scope = scope;
	}
}
