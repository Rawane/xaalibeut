package fr.recouv.securite.prisme.authzserver.mock;

import java.util.HashMap;
import java.util.Map;

import net.minidev.json.JSONObject;
import fr.recouv.securite.prisme.authzserver.bo.IDTokenStorable;
import fr.recouv.securite.prisme.logger.PrismeLogger;
import fr.recouv.securite.prisme.oidc.authz.exception.PrismeOIDCException;
import fr.recouv.securite.prisme.oidc.authz.token.IDToken;

/**
 * EntryIDTokenMock : pour mocker contenu IDToken Store.
 */
public class EntryIDTokenMock {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			EntryIDTokenMock.class).build();

	private static Map<String, IDTokenStorable> map;

	static {
		LOGGER.debug(" > init Mock ");
		// Initialisation liste IDTokenStorable
		EntryIDTokenMock.map = new HashMap<String, IDTokenStorable>();
		// Data
		IDTokenStorable idTokenStorable;
		String serializedValue;
		IDToken idToken;
		String state;

		try {
			// Mock 1
			serializedValue = 
					"eyJhbGciOiJSUzI1NiJ9.eyJleHAiOjE0ODg0OTU0OTIsInN1YiI6IkNF"
				+ "UjQ0OTUyNDAiLCJlbWFpbCI6ImRhdmlkLmZlcnJlaXJhQHVyc3NhZi5mciI"
				+ "sIm5vbmNlIjoiYmt4NE5YdXVaa0tyeW1VQTdQWXN2OE5DM1pORW5CWFJ2a0"
				+ "JaMWxWUFpsbyIsIm5hbWUiOiJEQVZJRCBGRVJSRUlSQSIsImF1ZCI6Ik9JR"
				+ "EMtTU9DSyIsImlzcyI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDgxXC9wcmlz"
				+ "bWUtc2VjdXJpdHlzZXJ2ZXIiLCJpYXQiOjE0ODg0NTIyOTJ9.CDE13iMWvg"
				+ "pDR22JiNOFL3XNTUTQ0bz_XXyHHrqoemF0FevoqAag2JHlFoVsgK9rgWdtX"
				+ "h_eeUEI3Scfn0Q6pw10zqpaGAWbCLKHLUsXXJi9R4IgLEbbOVikygZCLH9p"
				+ "GxYVJNQg57sk3QSUVL3t1PdlQHUcK4S-xcUikZgaqWQ";
			idToken = new IDToken();
			idToken.reverse(serializedValue);
			state = "A2A22B05351865AE5A5932F7F7323EFF";
			idTokenStorable = new IDTokenStorable(state, idToken);
			EntryIDTokenMock.map.put(idTokenStorable.state, idTokenStorable);

			// Mock 2
			serializedValue = 
					"eyJhbGciOiJSUzI1NiJ9.eyJleHAiOjE0ODg1MTQ2MTgsInN1YiI6IkNF"
				+ "UjQ0MDA0NjgiLCJlbWFpbCI6ImVyaWMuZGVzb3VzYUB1cnNzYWYuZnIiLCJ"
				+ "ub25jZSI6IjV4ZmprTHg5LURvRExxTHNkZnNkZnNkZnNmVExBVFBMLVFrT2"
				+ "ZnTEtNOCIsIm5hbWUiOiJFUklDIERFIFNPVVNBIiwiYXVkIjoiT0lEQy1NT"
				+ "0NLIiwiaXNzIjoiaHR0cDpcL1wvbG9jYWxob3N0OjgwODFcL3ByaXNtZS1z"
				+ "ZWN1cml0eXNlcnZlciIsImlhdCI6MTQ4ODQ3MTQxOH0.Gp-5AskGk0DN5f2"
				+ "w67xv3OpGTr33ydvnw2JtQDMBizoHPESJgIYwTNiQ-PtNz5axwvcE-4j_tH"
				+ "dZFCN6_zOpqdAxfaCLpQwDAUx28soJcXIo87N-NfEut2Sg1ZfEWNrRA7adg"
				+ "zOFPU0zNMocUymIafbk7-czf2X693-nKYDga0Q";
			idToken = new IDToken();
			idToken.reverse(serializedValue);
			state = "69351AB60D193423884084306DA6588D";
			idTokenStorable = new IDTokenStorable(state, idToken);
			EntryIDTokenMock.map.put(idTokenStorable.state, idTokenStorable);
		} catch (PrismeOIDCException e) {
			LOGGER.error("PrismeOIDCException exception : " + e.getMessage());
		}
	}

	/**
	 * cacheIDTokenMock : Mock le contenu du cache IDToken.
	 * 
	 * @return Map String Config
	 */
	public static Map<String, IDTokenStorable> cacheIDTokenMock() {
		return EntryIDTokenMock.map;
	}

	/**
	 * Contains IDToken.
	 * 
	 * @param nodeId
	 *            String
	 * @return boolean
	 */
	public static boolean contains(final String nodeId) {
		return EntryIDTokenMock.map.containsKey(nodeId);
	}

	/**
	 * Remove.
	 * 
	 * @param nodeId
	 *            String
	 */
	public static void remove(final String nodeId) {
		EntryIDTokenMock.map.remove(nodeId);
	}

	/**
	 * RemoveAll.
	 */
	public static void removeAll() {
		EntryIDTokenMock.map.clear();
	}

	/**
	 * Stats.
	 * 
	 * @return String
	 */
	public static String stats() {
		JSONObject response = new JSONObject();
		JSONObject detail = new JSONObject();
		detail.put("status", "TERMINATED");
		detail.put("cacheValidity", 3600);
		detail.put("allowInvocations", "false");
		detail.put("isStopping", "false");
		detail.put("isTerminated", "true");
		detail.put("needToDestroyFailedCache", "false");
		detail.put("needToInitializeBeforeStart", "true");
		detail.put("startAllowed", "false");
		detail.put("startingUp", "false");
		detail.put("stopAllowed", "false");
		response.put("cache-idtoken", detail);
		return response.toJSONString();
	}

	/**
	 * @return String
	 */
	public static String start() {
		JSONObject response = new JSONObject();
		response.put("result", "OK");
		return response.toJSONString();
	}

	/**
	 * @return String
	 */
	public static String stop() {
		JSONObject response = new JSONObject();
		response.put("result", "OK");
		return response.toJSONString();
	}

}
