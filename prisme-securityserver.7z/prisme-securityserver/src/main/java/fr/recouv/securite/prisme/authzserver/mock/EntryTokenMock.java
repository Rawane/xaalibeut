package fr.recouv.securite.prisme.authzserver.mock;

import java.util.HashMap;
import java.util.Map;

import net.minidev.json.JSONObject;

import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.token.AbstractToken;
import fr.recouv.securite.prisme.commun.token.JWTAccessToken;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * EntryTokenMock : pour mocker contenu Token Store.
 */
public class EntryTokenMock {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			EntryTokenMock.class).build();

	private static Map<String, AbstractToken> map;

	static {
		LOGGER.debug(" > init Mock ");
		// Initialisation liste Token
		EntryTokenMock.map = new HashMap<String, AbstractToken>();
		try {
			// Data
			String value;
			// Mock 1
			value = "eyJhbGciOiJSUzUxMiJ9.eyJleHAiOjE0NzA3NTE2NDYsInN1YiI6IkFDNzUwV"
				+ "DkwOTlAdXJuOmludGVyb3BzOmdpcC1pbmZvLXJldHJhaXRlOmNvbGxlY3RldXItb"
				+ "m9yZDppZHA6OSIsImF1ZCI6Ikg0c0lBQUFBQUFBQUFBc05NalEwdHdyMkN6UFNEU"
				+ "Wp5ZDdGeURBNzJEQTV4OUhOMmpYZno5M01POGZUMzgzUDE4WEdOOXpOU0NBMHlRV"
				+ "kViNHVyajZ1enZGK3pxNlJQdlp3aVVOalVoMGlnQXRXd0t0SFlBQUFBPSIsImlzc"
				+ "yI6Ijk1OGUyMThjN2YxYjQ1NjFiZWZmYWVjMWMyYmY5NGU4QFBTU19DTElFTlRJR"
				+ "CIsImlkX3N0b3JlIjoiSDRzSUFBQUFBQUFBQUhOME5qYzFDTEUwc0xTMEtpM0tzO"
				+ "HJNSzBrdHlpOG90a3JQTE5ETnpFdkwxeTFLTFNsS3pDeEp0VXJPejhsSlRTNUpMU"
				+ "zNTemNzdlNySEtUQ213c2xTTTlqQXA5blNFQWVmaWtzcjg0akp2M1wvemlxbXdqU"
				+ "Hg4TGMxK2ZaRU12SDlcL3NNb1Awa2dxWFFKTUt4MEFYUTVjc1kwZjNkSkFHVzl0W"
				+ "UFEYVlLdTZDQUFBQSIsImp0aSI6IjBjMzI5MzY2ZGFkZjU2OWVkZDk0OGMwMzliN"
				+ "2ZmMjIxIiwiaWF0IjoxNDcwNjY1MjQ2fQ.hgZ2m3k1b3N_FaJOdPMlQKb6ltumBz"
				+ "h6gyTDIFHuy2XY1VobTwyMOVtJELG2OOSdS5SBz39xZXEKOBiIM8tXBKXBng66On"
				+ "HlEPEoBxliHCll0ywlosMrvl-KT9XbunDj0ipT_Yx7yw7y6tTo3JFP3fN0LbUVbI"
				+ "Q7F1xin_3rwoU";
			EntryTokenMock.map.put("894bcdd4e3990974895c499993c9ed59",
					JWTAccessToken.set().with(value).build());

			// Mock 2
			value = "eyJhbGciOiJSUzUxMiJ9."
				+ "eyJleHAiOjE0NzUwNjY3ODMsInN1YiI6IkNFUjQ0MDA0NjhAY249VVNSX1JFQURfTk"
				+ "FUX0FQUF9DT1NJLE9VPUNPU0ksb3U9QXBwbGljYXRpb25zLG91PVRlY2huaXF1ZSxk"
				+ "Yz1yZWNvdXYiLCJhdWQiOiJINHNJQUFBQUFBQUFBRTJPTVE3RklBeERyOUlMXC9PRl"
				+ "RxaTkxaXlDdGtDQkJDYkRtXC9yZjR0Qk9UQjl2UDduTDQzNmswM0tjS3g3Tm1vSFNs"
				+ "QUMweEdYZXJJRkN3Q2R4b3d4bTVyY3V4cjVYQTFJUXpHdTFiUVBGKzhVQTFhUU1LYU"
				+ "JkVGVLQ0UrY20rSExkeWJ0UjNGR0pKTkZzeVB3eTBpR3FCUzIxVDZmc0hWWDZHaHJB"
				+ "QUFBQT0iLCJpc3MiOiI0Mjg4MjgxNTI0Mzc2NzFhZWUwYzg1ZTBlYTEzZmI2ZUBQU1"
				+ "NfQ0xJRU5USUQiLCJpZF9zdG9yZSI6Ikg0c0lBQUFBQUFBQUFITjJEVEl4TVRBd01i"
				+ "T3dTczZ6RFEwT2lnOXlkWFNKOTNNTWlYY01DSWgzOWdcLzIxUEVQdFFYVCthVzJqZ1"
				+ "VGT1puSmlTV1orWG5GSUg1SWFuSkdYbVpoYWFwT1NySnRVV3B5Zm1tWllyU0hTYkdu"
				+ "SXd6NCtWYzZsMFg2K0ZwNitqa0hlQms3QmpxN0pGYWFoVG1YZ3lSdGJXTUJwQ2FxR2"
				+ "9FQUFBQT0iLCJqdGkiOiI0MDkzNzUzMTcwNWYzOGZkMGI4Mzc4NDEwMGU5YmJkOCIs"
				+ "ImlhdCI6MTQ2NzAzMTU4M30.rCaQnggd1zG3paTglG-l9gft69Nju-JfYi1kEyO2rc"
				+ "BbuSizWM5KqPD6V5swXol4R0msaOPzdUByhi8j067Z3Ki79BWrjUsR6npYVaedT-1Q"
				+ "puNZFhRblDqVf3oX91Vpyng2Jsk_X4TbfZ0e94UUurA7CZ_4xeffWEvH3EtI_LA";
			EntryTokenMock.map.put("68062abb354ff063d8c24c2018f1cc91",
					JWTAccessToken.set().with(value).build());

			// Mock 3
			value = "eyJhbGciOiJSUzUxMiJ9.eyJleHAiOjE0NzA3NDcyMTksInN1YiI6IkNFUjQ0M"
				+ "DA0NjhAY249VVNSX1JFQURfTkFUX0FQUF9QU05FWFQsb3U9UFNORVhULG91PUFwc"
				+ "GxpY2F0aW9ucyxvdT1UZWNobmlxdWUsZGM9cmVjb3V2IiwiYXVkIjoiSDRzSUFBQ"
				+ "UFBQUFBQUUyT01RN0ZJQXhEcjlJTFwvT0ZUcWk5MWl5Q3RrQ0JCQ2JEbVwvcmY0d"
				+ "EJPVEI5dlA3bkw0MzZrMDNLY0t4N05tb0hTbEFDMHhHWGVySUZDd0NkeG93eG01c"
				+ "mN1eHI1WEExSVF6R3UxYlFQRis4VUExYVFNS2FCZFRlS0NFK2NtK0hMZHlidFIzR"
				+ "kdKSk5Gc3lQd3kwaUdxQlMyMVQ2ZnNIVlg2R2hyQUFBQUE9IiwiaXNzIjoiMjdmO"
				+ "Tc1MzRhYzc2MGRlNjg1NDI0NWY3MzYzMzVlNDJAUFNTX0NMSUVOVElEIiwiaWRfc"
				+ "3RvcmUiOiJINHNJQUFBQUFBQUFBSE4yRFRJeE1UQXdNYk93U3M2ekRRME9pZzl5Z"
				+ "FhTSjkzTU1pWGNNQ0lnUENQWnpqUWpSeVMrMVJiQWNDd3B5TXBNVFN6THo4NHBCX"
				+ "C9KRFU1SXk4ek1MU1ZKMlVaTnVpMU9UODBqTEZhQStUWWs5SEdQRHpyM1F1aVwvV"
				+ "Hh0ZlQwY3c3d01uWU1kSFpKckRRTGN5NEhTZHJheGdJQVozTDNSSVVBQUFBPSIsI"
				+ "mp0aSI6IjQyYTdmMWI5Mzc5NGNiOGU4OTQ2OGU1MTdjMzExYmQxIiwiaWF0IjoxN"
				+ "DcwNjYwODE5fQ.WbYWh_bT_olZARBKPSGXILvTlqKIWV1Pbo8BU4h02w3GglMCR7"
				+ "RZXZhhDsc-uV4Lv1onfSOS2GQHqU-LNgfMUA8s7pne5cqZCSJWGtXe5aDky5UGj6"
				+ "qx5ZDr6R6ioNjOLYs7ILPAXRAUsXVhPJy90sK3zhi8YZOUZbOg-5DsMAQ";
			EntryTokenMock.map.put("3822f4a8d2b14193685bacde7e60991f",
					JWTAccessToken.set().with(value).build());
		} catch (PrismeInvalidTokenException e) {
			LOGGER.error("Exception EntryTokenMock init : " + e.getMessage());
		}
	}

	/**
	 * cacheTokenMock : Mock le contenu du cache Token.
	 * 
	 * @return Map String AbstractToken
	 */
	public static Map<String, AbstractToken> cacheTokenMock() {
		return EntryTokenMock.map;
	}

	/**
	 * Contains Token.
	 * 
	 * @param uid
	 *            String
	 * @return boolean
	 */
	public static boolean contains(final String uid) {
		return EntryTokenMock.map.containsKey(uid);
	}

	/**
	 * Remove.
	 * 
	 * @param uid
	 *            String
	 */
	public static void remove(final String uid) {
		EntryTokenMock.map.remove(uid);
	}

	/**
	 * RemoveAll.
	 */
	public static void removeAll() {
		EntryTokenMock.map.clear();
	}

	/**
	 * Stats.
	 * 
	 * @return String
	 */
	public static String stats() {
		JSONObject response = new JSONObject();
		JSONObject detail = new JSONObject();
		detail.put("status", "RUNNING");
		detail.put("cacheValidity", 3600);
		detail.put("allowInvocations", "true");
		detail.put("isStopping", "false");
		detail.put("isTerminated", "false");
		detail.put("needToDestroyFailedCache", "false");
		detail.put("needToInitializeBeforeStart", "false");
		detail.put("startAllowed", "false");
		detail.put("startingUp", "false");
		detail.put("stopAllowed", "true");
		detail.put("averageReadTime", 0);
		detail.put("averageRemoveTime", 0);
		detail.put("averageWriteTime", 0);
		detail.put("evictions", 0);
		detail.put("retrievals", 0);
		detail.put("hits", 0);
		detail.put("misses", 0);
		detail.put("numberOfEntries", 0);
		detail.put("totalNumberOfEntries", 0);
		detail.put("removeHits", 0);
		detail.put("removeMisses", 0);
		detail.put("timeSinceReset", 0);
		detail.put("timeSinceStart", 0);
		response.put("cache-token", detail);
		return response.toJSONString();
	}

	/**
	 * @return String
	 */
	public static String start() {
		JSONObject response = new JSONObject();
		response.put("result", "OK");
		return response.toJSONString();
	}

	/**
	 * @return String
	 */
	public static String stop() {
		JSONObject response = new JSONObject();
		response.put("result", "OK");
		return response.toJSONString();
	}
}
