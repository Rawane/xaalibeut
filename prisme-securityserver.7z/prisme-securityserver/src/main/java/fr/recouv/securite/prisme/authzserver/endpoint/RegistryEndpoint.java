package fr.recouv.securite.prisme.authzserver.endpoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.codahale.metrics.annotation.Timed;

import fr.recouv.securite.prisme.authzserver.provider.PrismeRegistryServerProvider;
import fr.recouv.securite.prisme.authzserver.provider.RegistryConfigProducer;
import fr.recouv.securite.prisme.authzserver.request.PrismeRegistryRequest;
import fr.recouv.securite.prisme.authzserver.response.PrismeTokenServerResponse;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.PrismeProtocoleError;
import fr.recouv.securite.prisme.commun.message.response.PrismeResponse;
import fr.recouv.securite.prisme.commun.message.types.PrismeRegistryType;
import fr.recouv.securite.prisme.logger.PrismeLogger;

@Path("/registry/{version}")
public class RegistryEndpoint {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			RegistryEndpoint.class).build();

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Timed
	public String ping() {
		_logger.debug("ping");
		return "ping from RegistryEndpoint!";
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response request(@Context HttpServletRequest request)
			throws PrismeSystemException {

		// Extraire les donnees relatif aux traitements de la requete
		PrismeRegistryRequest registryRequest;
		try {
			registryRequest = new PrismeRegistryRequest(request);

			_logger.debug("Registry type   : "
					+ registryRequest.getParam(PrismeParams.REGISTRY.TYPE));
			_logger.debug("client id    : "
					+ registryRequest.getParam(PrismeParams.CLIENT_ID));
			_logger.debug("client secret: "
					+ registryRequest.getParam(PrismeParams.CLIENT_SECRET));

			PrismeRegistryServerProvider provider = this
					.getProvider(registryRequest);
			if (provider == null) {
				return onProtocoleError(
						PrismeProtocoleError.REGISTRY_PROTOCOLE.INVALID_CODE,
						PrismeProtocoleError.REGISTRY_PROTOCOLE.INVALID_MESSAGE);
			}

			PrismeResponse response = provider.compose();
			return Response.status(response.getResponseStatus())
					.entity(response.getBody()).build();
		} catch (PrismeSystemException e) {
			_logger.error("Erreur lors du traitement : " + e.getMessage());
			return onProtocoleError(
					e.getCodeException().toString(),
					e.getMessage());
		}
	}

	/**
	 * @return Response response
	 * @throws PrismeSystemException exception
	 */
	private Response onProtocoleError(String code, String msg)
			throws PrismeSystemException {
		PrismeResponse response = PrismeTokenServerResponse
				.onError(HttpServletResponse.SC_BAD_REQUEST).setErrorCode(code)
				.setErrorMessage(msg).buildJSONMessage();
		return Response.status(response.getResponseStatus())
				.entity(response.getBody()).build();
	}

	/**
	 * Retourne le provider
	 * 
	 * @param registryType
	 *            String
	 * @return PrismeRegistryServerProvider
	 */
	private PrismeRegistryServerProvider getProvider(
			PrismeRegistryRequest registryRequest) {

		final PrismeRegistryType enumRegistryType = PrismeRegistryType
				.toValue(registryRequest.getParam(PrismeParams.REGISTRY.TYPE));
		if (enumRegistryType == null) {
			return null;
		}
		PrismeRegistryServerProvider provider = null;
		switch (enumRegistryType) {
		case CONFIG:
			// Enregistrement config
			provider = new RegistryConfigProducer(registryRequest);
			break;
		// case RESOURCE_SERVER
		default:
			// Defaut
			break;
		}
		return provider;
	}
}
