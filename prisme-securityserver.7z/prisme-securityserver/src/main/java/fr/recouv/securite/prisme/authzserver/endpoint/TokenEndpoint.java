package fr.recouv.securite.prisme.authzserver.endpoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.codahale.metrics.annotation.Timed;

import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAuthenticator;
import fr.recouv.securite.prisme.authzserver.issuer.AuthorizationCodeAccessTokenProducer;
import fr.recouv.securite.prisme.authzserver.issuer.ConsumerAccessTokenProducer;
import fr.recouv.securite.prisme.authzserver.issuer.InterOpsAccessTokenProducer;
import fr.recouv.securite.prisme.authzserver.issuer.JWTAccessTokenProducer;
import fr.recouv.securite.prisme.authzserver.issuer.OceanAccessTokenProducer;
import fr.recouv.securite.prisme.authzserver.issuer.PrismeIssuer;
import fr.recouv.securite.prisme.authzserver.issuer.RefreshAccessTokenProducer;
import fr.recouv.securite.prisme.authzserver.issuer.TrustedEndUserAccessTokenProducer;
import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.authzserver.response.PrismeTokenServerResponse;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.PrismeProtocoleError;
import fr.recouv.securite.prisme.commun.message.response.PrismeResponse;
import fr.recouv.securite.prisme.commun.message.types.PrismeGrantType;
import fr.recouv.securite.prisme.commun.token.AbstractAccessToken;
import fr.recouv.securite.prisme.commun.token.AbstractRefreshToken;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * Ce service permet de fabriquer des jetons en reponse a un type de demande. <br>
 * (method POST) Il permet eventuellement de valider un jeton d acces. (hors JWT
 * et bearer) <br>
 * (method GET) Il compose en retour un message tel quel attendu par le client
 */
@Path("/token/{version}")
public class TokenEndpoint {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			TokenEndpoint.class).build();

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String ping() {
		_logger.debug("ping");
		return "ping from TokenEndpoint!";
	}

	/**
	 * Verifie qu'un token existe dans le tokenStore
	 * 
	 * @param token
	 *            String
	 * @return String exist
	 */
	@GET
	@Path("/{token}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public String exists(@PathParam("token") String token) {
		_logger.debug("Exist Token:" + token);
		try {
			_logger.debug(PrismeSecurityServer.tokenStore().stats());
			if (PrismeSecurityServer.tokenStore().contains(token)) {
				return PrismeParams.TRUE;
			}
		} catch (PrismeSystemException e) {
			_logger.error("PrismeSystemException: " + e.getMessage());
		} catch (PrismeException e) {
			_logger.error("PrismeException: " + e.getMessage());
		} catch (Exception e) {
			_logger.error("Exception: " + e.getMessage());
		}
		return PrismeParams.FALSE;
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response authorize(@Context HttpServletRequest request)
			throws PrismeSystemException {

		long debut = System.currentTimeMillis();
		try {
			_logger.debug("----- START TOKEN ENDPOINT --- ");

			// Extraire les donnees relatif aux traitements de la requete
			PrismeTokenRequest prismeRequest = new PrismeTokenRequest(request);

			_logger.debug("grant type   : "
					+ prismeRequest.getParam(PrismeParams.GRANT_TYPE));
			_logger.debug("client id    : "
					+ prismeRequest.getParam(PrismeParams.CLIENT_ID));
			_logger.debug("client secret: "
					+ prismeRequest.getParam(PrismeParams.CLIENT_SECRET));

			// Authentification Client_id + Client_secret sur Anais
			PrismeAnaisAuthenticator.authenticateClient(
					prismeRequest.getParam(PrismeParams.CLIENT_ID),
					prismeRequest.getParam(PrismeParams.CLIENT_SECRET));

			PrismeIssuer issuer = this.getIssuer(prismeRequest);
			// Si issuer null, pb de grantType
			if (issuer == null) {
				return onProtocoleError(
						PrismeProtocoleError.TOKEN_PROTOCOLE.INVALID_CODE,
						PrismeProtocoleError.TOKEN_PROTOCOLE.INVALID_MESSAGE);
			}
			// Si scope vide, droits insuffisants
			if (issuer.getScope() == null || issuer.getScope().isEmpty()) {
				return onProtocoleError(
						PrismeProtocoleError.TOKEN_PROTOCOLE.INVALID_ACCESS,
						PrismeProtocoleError.TOKEN_PROTOCOLE.INVALID_ACCESS_MESSAGE);
			}

			// Recuperation Token
			AbstractAccessToken accessToken = issuer.accessToken();
			AbstractRefreshToken refreshToken = issuer.refreshToken();
			String scope = issuer.getScope().encode();
			String tokenType = issuer.getTokenType();

			// Stockage Token
			PrismeSecurityServer.tokenStore().add(accessToken.UID(),
					accessToken);
			// PrismeSecurityServer.tokenStore().add(refreshToken.UID(),
			// refreshToken);
			_logger.debug(PrismeSecurityServer.tokenStore().stats());

			// Response
			PrismeResponse response = PrismeTokenServerResponse
					.tokenResponse(HttpServletResponse.SC_OK)
					.setAccessToken(accessToken).setRefreshToken(refreshToken)
					.setExpiresIn(PrismeSecurityServer.tokenDelayedTime())
					.setScope(scope)
					.setParam(PrismeParams.ASSERTION_TYPE, tokenType)
					.buildJSONMessage();

			_logger.debug("----- END TOKEN ENDPOINT --- ");

			return Response.status(response.getResponseStatus())
					.entity(response.getBody()).build();
		} catch (PrismeSystemException e) {
			_logger.error("Erreur lors du traitement : " + e.getMessage());
			return onProtocoleError(e.getCodeException().toString(),
					e.getMessage());
		} catch (PrismeException e) {
			_logger.error("Erreur lors du traitement : " + e.getMessage());
			return onProtocoleError(e.getCodeException().toString(),
					e.getMessage());
		} finally {
			long interval = System.currentTimeMillis() - debut;
			_logger.debug("Duree generation jeton (ms):" + interval);
		}
	}

	/**
	 * @param code
	 *            String
	 * @param msg
	 *            String
	 * @return Response
	 * @throws PrismeSystemException
	 */
	private Response onProtocoleError(String code, String msg)
			throws PrismeSystemException {
		PrismeResponse response = PrismeTokenServerResponse
				.onError(HttpServletResponse.SC_BAD_REQUEST).setErrorCode(code)
				.setErrorMessage(msg).buildJSONMessage();
		return Response.status(response.getResponseStatus())
				.entity(response.getBody()).build();
	}

	/**
	 * Retourne le issuer en fonction du GrantType
	 * 
	 * @param grantType
	 *            String
	 * @return PrismeIssuer
	 * @throws PrismeSystemException
	 */
	private PrismeIssuer getIssuer(PrismeTokenRequest prismeRequest)
			throws PrismeSystemException {

		final PrismeGrantType enumGrantType = PrismeGrantType
				.toValue(prismeRequest.getParam(PrismeParams.GRANT_TYPE));
		if (enumGrantType == null) {
			return null;
		}
		PrismeIssuer issuer = null;
		switch (enumGrantType) {
		case CONSUMER_CREDENTIALS:
			// Producteur de jeton pour la cinematique CONSUMER_CREDENTIALS
			issuer = new ConsumerAccessTokenProducer(prismeRequest);
			break;
		case JWT_TOKEN:
			// Producteur de jeton pour la cinematique JWT_TOKEN
			issuer = new JWTAccessTokenProducer(prismeRequest);
			break;
		case INTEROPS_TOKEN:
			// Producteur de jeton pour la cinematique INTEROPS_TOKEN
			issuer = new InterOpsAccessTokenProducer(prismeRequest);
			break;
		case REFRESH_TOKEN:
			// Producteur de jeton pour la cinematique REFRESH_TOKEN
			issuer = new RefreshAccessTokenProducer(prismeRequest);
			break;
		case AUTHORIZATION_CODE:
			// Producteur de jeton pour la cinematique AUTHORIZATION_CODE
			issuer = new AuthorizationCodeAccessTokenProducer(prismeRequest);
			break;
		case TRUSTED_USER:
			// Producteur de jeton pour la cinematique ENDUSER_TRUSTED
			issuer = new TrustedEndUserAccessTokenProducer(prismeRequest);
			break;
		case OCEAN_TOKEN:
			// Producteur de jeton pour la cinematique OCEAN_TOKEN
			issuer = new OceanAccessTokenProducer(prismeRequest);
			break;
		default:
			// Defaut
			break;
		}
		return issuer;
	}
}
