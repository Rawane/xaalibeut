package fr.recouv.securite.prisme.authzserver.endpoint;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.codahale.metrics.annotation.Timed;

import fr.recouv.securite.prisme.authzserver.bo.JSONRequest;
import fr.recouv.securite.prisme.authzserver.bo.JSONResponse;
import fr.recouv.securite.prisme.authzserver.bo.UserSession;
import fr.recouv.securite.prisme.authzserver.listener.PrismeServletSession;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * SessionAuthEndpoint : <br>
 * 
 * Utilisé dans la gestion des sessions utilisateurs sur PSS.
 */
@Path("/session/{version}")
public class SessionAuthEndpoint {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			SessionAuthEndpoint.class).build();

	@Context
	private HttpServletRequest request;

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Timed
	public String ping() {
		_logger.debug("ping");
		return "ping from SessionAuthEndpoint!";
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/login")
	@Timed
	public JSONResponse login(JSONRequest user) {
		_logger.debug(" >>> login [username : " + user.username + "]");
		JSONResponse response = new JSONResponse();
		try {
			// Recuperation utilisateur et mise en session
			PrismeServletSession.setUserSession(this.request, user.username, user.password);
			// Result
			response.result = PrismeParams.TRUE;
		} catch (PrismeSystemException e) {
			response.result = PrismeParams.FALSE;
		}
		_logger.debug(" result ? " + response.result);
		_logger.debug(" <<< login");
		return response;
	}

	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/logout")
	@Timed
	public JSONResponse logout() {
		_logger.debug(" >>> logout");
		JSONResponse response = new JSONResponse();
		response.result = PrismeParams.FALSE;
		// Suppression session
		PrismeServletSession.resetUserSession(this.request);
		if (!PrismeServletSession.isUserSession(this.request)) {
			response.result = PrismeParams.TRUE;
		}
		_logger.debug(" result ? " + response.result);
		_logger.debug(" <<< logout");
		// Retour
		return response;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/context")
	@Timed
	public UserSession context() {
		_logger.debug(" >>> context"); 
		// Si personne connectee
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation utilisateur
			return PrismeServletSession.getUserSession(this.request);
		} else {
			return new UserSession();
		}
	}
}
