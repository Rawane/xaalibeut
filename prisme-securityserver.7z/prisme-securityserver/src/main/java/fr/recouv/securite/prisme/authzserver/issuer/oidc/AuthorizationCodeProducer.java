package fr.recouv.securite.prisme.authzserver.issuer.oidc;

import com.nimbusds.oauth2.sdk.AuthorizationCode;
import com.nimbusds.oauth2.sdk.ResponseType;

import fr.recouv.securite.prisme.logger.PrismeLogger;
import fr.recouv.securite.prisme.oidc.authz.request.PrismeAuthenticationRequest;

/**
 * AuthorizationCodeProducer.
 */
public class AuthorizationCodeProducer {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			AuthorizationCodeProducer.class).build();

	/**
	 * Produce.
	 * 
	 * @param authRequest
	 *            PrismeAuthenticationRequest
	 * @return AuthorizationCode code
	 */
	public static AuthorizationCode produce(
			PrismeAuthenticationRequest authRequest) {
		LOGGER.debug(" > produce");
		// Si code non demande
		if (!authRequest.getResponseType().contains(ResponseType.Value.CODE)) {
			return null;
		}

		// Generation code
		return new AuthorizationCode();
	}
}
