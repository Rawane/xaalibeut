package fr.recouv.securite.prisme.authzserver;

import java.io.IOException;
import java.security.interfaces.RSAPrivateKey;

import org.infinispan.Cache;
import org.infinispan.manager.EmbeddedCacheManager;

import fr.recouv.securite.prisme.authzserver.bo.IDTokenStorable;
import fr.recouv.securite.prisme.authzserver.engine.NoneEngine;
import fr.recouv.securite.prisme.authzserver.listener.PrismeThreadsManager;
import fr.recouv.securite.prisme.authzserver.store.IDTokenStoreWithInfiniSpanCache;
import fr.recouv.securite.prisme.authzserver.store.RegistryStoreWithInfiniSpanCache;
import fr.recouv.securite.prisme.authzserver.store.infinispan.InfinispanConfig;
import fr.recouv.securite.prisme.authzserver.store.infinispan.InfinispanLogger;
import fr.recouv.securite.prisme.commun.claims.UserIdentity;
import fr.recouv.securite.prisme.commun.config.bean.Config;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.providers.bean.PermissionsData;
import fr.recouv.securite.prisme.commun.store.ISecurityStore;
import fr.recouv.securite.prisme.commun.token.AbstractToken;
import fr.recouv.securite.prisme.commun.token.engine.IEngine;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeSecurityServer : <br>
 * Contient les stores (Token, Identite, Permissions, Registry).
 */
public class PrismeSecurityServer {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			PrismeSecurityServer.class).build();

	static ISecurityStore<Config> registry_store;

	static ISecurityStore<IDTokenStorable> idToken_store;

	static EmbeddedCacheManager cacheManager;

	static Cache<String, AbstractToken> cacheToken;

	static Cache<String, Config> cacheRegistry;

	static Cache<String, IDTokenStorable> cacheIDToken;

	static NoneEngine noneEngine = new NoneEngine();

	static {
		try {
			_logger.info("Chargement de la configuration InfiniSpan.");
			// Chargement cacheManager
			cacheManager = InfinispanConfig.getCacheManager();
			// Cache Token
			_logger.info("Chargement cache Token.");
			cacheToken = cacheManager.getCache("cache-token");
			cacheToken.addListener(new InfinispanLogger());
			_logger.info(String.format(
					"Started cache %s on %s with members: %s",
					cacheToken.getName(), cacheManager.getClusterName(),
					cacheToken.getAdvancedCache().getRpcManager().getMembers()));
			// Cache Registry
			_logger.info("Chargement cache Registry.");
			cacheRegistry = cacheManager.getCache("cache-registry");
			cacheRegistry.addListener(new InfinispanLogger());
			_logger.info(String.format(
					"Started cache %s on %s with members: %s",
					cacheRegistry.getName(), cacheManager.getClusterName(),
					cacheRegistry.getAdvancedCache().getRpcManager().getMembers()));
			// Cache IDToken
			_logger.info("Chargement cache IDToken.");
			cacheIDToken = cacheManager.getCache("cache-idtoken");
			cacheIDToken.addListener(new InfinispanLogger());
			_logger.info(String.format(
					"Started cache %s on %s with members: %s",
					cacheIDToken.getName(), cacheManager.getClusterName(),
					cacheIDToken.getAdvancedCache().getRpcManager().getMembers()));
		} catch (IOException e) {
			_logger.error(
					"Exception lors de la creation du cache : "
							+ e.getMessage(), e);
		}
		// Creation RegistryStore
		registry_store = new RegistryStoreWithInfiniSpanCache();
		// Creation IDTokenStore
		idToken_store = new IDTokenStoreWithInfiniSpanCache();
	}

	public static void start() {
		// Chargement implicite du constructeur static
	}

	public synchronized static void stop() {
		// Affichage liste Threads avant arret
		PrismeThreadsManager.showThread();

		// Arret du cache Manager
		cacheManager.stop();

		// Sleep Thread
		PrismeThreadsManager.sleepThread();

		// Stop Thread
		PrismeThreadsManager.stopThread();

		// Check Thread
		PrismeThreadsManager.checkThread();
	}

	public static ISecurityStore<AbstractToken> tokenStore() throws PrismeSystemException {
		_logger.debug("> TokenStore");
		if (PrismeContexteDescriptor.getTokenStore() == null) {
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR, "TokenStore null");
		}
		return PrismeContexteDescriptor.getTokenStore();
	}

	public static ISecurityStore<UserIdentity> identityStore() throws PrismeSystemException {
		_logger.debug("> IdentityStore");
		if (PrismeContexteDescriptor.getIdentityStore() == null) {
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR, "IdentityStore null");
		}
		return PrismeContexteDescriptor.getIdentityStore();
	}

	public static ISecurityStore<PermissionsData> permissionsStore() throws PrismeSystemException {
		_logger.debug("> PermissionsStore");
		if (PrismeContexteDescriptor.getPermissionsStore() == null) {
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR, "PermissionsStore null");
		}
		return PrismeContexteDescriptor.getPermissionsStore();
	}

	public static ISecurityStore<Config> registryStore() throws PrismeSystemException {
		_logger.debug("> RegistryStore");
		if (registry_store == null) {
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR, "RegistryStore null");
		}
		return registry_store;
	}

	public static ISecurityStore<IDTokenStorable> idTokenStore() throws PrismeSystemException {
		_logger.debug("> IDTokenStore");
		if (idToken_store == null) {
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR, "IDTokenStore null");
		}
		return idToken_store;
	}

	public static IEngine getOceanEngine() {
		if (PrismeContexteDescriptor.getOceanEngine() != null) {
			return PrismeContexteDescriptor.getOceanEngine();
		} else {
			return noneEngine;
		}
	}

	public static IEngine getInterOpsEngine() {
		if (PrismeContexteDescriptor.getInterOpsEngine() != null) {
			return PrismeContexteDescriptor.getInterOpsEngine();
		} else {
			return noneEngine;
		}
	}

	public static String tokenDelayedTime() {
		return Integer.toString(PrismeContexteDescriptor.getTokenDelayedTime());
	}

	public static int getTokenDelayedTimeInteger() {
		return PrismeContexteDescriptor.getTokenDelayedTime();
	}

	public static int getIDTokenDelayedTime() {
		return PrismeContexteDescriptor.getIDTokenDelayedTime();
	}

	public static String getIssuer() {
		return PrismeContexteDescriptor.nodeId() + "@"
				+ PrismeContexteDescriptor.clientId();
	}

	public static RSAPrivateKey getPrivateKeyFile() {
		return PrismeContexteDescriptor.getPrivateKeyFile();
	}

	public static EmbeddedCacheManager cacheManager() {
		return cacheManager;
	}

	public static Cache<String, AbstractToken> cacheToken() {
		return cacheToken;
	}

	public static Cache<String, Config> cacheRegistry() {
		return cacheRegistry;
	}

	public static Cache<String, IDTokenStorable> cacheIDToken() {
		return cacheIDToken;
	}
}
