package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import fr.recouv.securite.prisme.commun.store.ElementStorable;
import fr.recouv.securite.prisme.oidc.authz.token.IDToken;

/**
 * IDTokenStorable : Fait le lien entre un objet IDToken a storer cote PSS et
 * l'interface ElementStorable. 
 */
public class IDTokenStorable implements ElementStorable, Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 5057019183218010333L;

	public String state;

	public IDToken idToken;

	/**
	 * Constructeur simple.
	 */
	public IDTokenStorable() {
		super();
	}

	/**
	 * Constructeur.
	 * @param state String
	 * @param idToken IDToken
	 */
	public IDTokenStorable(String state, IDToken idToken) {
		super();
		this.state = state;
		this.idToken = idToken;
	}

	@Override
	public String value() {
		return "subject:" + this.idToken.getSubject();
	}
}
