package fr.recouv.securite.prisme.authzserver.store;

import javax.management.MBeanException;
import javax.management.ObjectName;

/**
 * IStoreMBean.
 */
public interface IStoreMBean {

	// -----------
	// MBean
	// -----------

	/**
	 * getMBeanObject.
	 * 
	 * @return Object
	 * @throws MBeanException
	 *             exception
	 */
	Object getMBeanObject() throws MBeanException;

	/**
	 * getMBeanObjectName.
	 * 
	 * @return Object
	 * @throws MBeanException
	 *             exception
	 */
	ObjectName getMBeanObjectName() throws MBeanException;

	// -----------
	// operations
	// -----------

	/**
	 * Remise a zero du cache.
	 * 
	 * @throws MBeanException
	 *             exception
	 */
	void invalidate() throws MBeanException;

	/**
	 * Suppression d'une entree par cle.
	 * 
	 * @param key
	 *            String
	 * @throws MBeanException
	 *             exception
	 */
	void invalidateByKey(String key) throws MBeanException;

	/**
	 * Taille du cache.
	 * 
	 * @return long
	 * @throws MBeanException
	 *             exception
	 */
	long cacheSize() throws MBeanException;

	/**
	 * Stats du cache.
	 * 
	 * @return String
	 * @throws MBeanException
	 *             exception
	 */
	String stats() throws MBeanException;

	// -----------
	// attributes
	// -----------

	/**
	 * @param validityPeriod
	 *            int
	 * @throws MBeanException
	 *             exception
	 */
	void setCacheValidity(int validityPeriod) throws MBeanException;

	/**
	 * @return int
	 */
	int getCacheValidity();

	/**
	 * @param maxEntries
	 *            int
	 * @throws MBeanException
	 *             exception
	 */
	void setCacheMaxEntries(int maxEntries) throws MBeanException;

	/**
	 * @return int
	 */
	int getCacheMaxEntries();

	// -----
	// Ajout
	// -----

	boolean contains(String key) throws Exception;

	/**
	 * Start.
	 * 
	 * @throws MBeanException
	 *             exception
	 */
	void start() throws MBeanException;

	/**
	 * Stop.
	 * 
	 * @throws MBeanException
	 *             exception
	 */
	void stop() throws MBeanException;
}
