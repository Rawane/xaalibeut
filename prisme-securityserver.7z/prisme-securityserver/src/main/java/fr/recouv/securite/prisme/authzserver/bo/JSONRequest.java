package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * JSONRequest.
 */
public class JSONRequest implements Serializable {
	private static final long serialVersionUID = -4415580962628496325L;

	// login
	@JsonProperty
	public String username;
	@JsonProperty
	public String password;
	// login - oidc
	@JsonProperty
	public String requestOrigin;

	// role
	@JsonProperty
	public String role;

	// revoke
	@JsonProperty
	public String uid;
	@JsonProperty
	public String nodeId;
	@JsonProperty
	public String key;
	@JsonProperty
	public String state;

	// application
	@JsonProperty
	public String cn;

	// logger
	@JsonProperty
	public String name;
	@JsonProperty
	public String level;

	// pdp
	@JsonProperty
	public String routage_servicename;
	@JsonProperty
	public String routage_perimetre;
	@JsonProperty
	public String assertion;
}