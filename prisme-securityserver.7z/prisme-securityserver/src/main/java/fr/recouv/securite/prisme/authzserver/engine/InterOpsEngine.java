package fr.recouv.securite.prisme.authzserver.engine;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.common.base.Joiner;

import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.InterOpsToken;
import fr.recouv.securite.prisme.commun.token.engine.IEngine;
import fr.recouv.securite.prisme.commun.utils.PropertiesUtility;
import fr.recouv.securite.prisme.commun.utils.ScopeUtility;
import fr.recouv.securite.prisme.commun.utils.StringUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * InterOpsEngine.
 */
public class InterOpsEngine implements IEngine {

	private static final PrismeLogger _logger = new PrismeLogger().in(
			InterOpsEngine.class).build();

	private static final String SEPARATOR_PAGMS = ",";
	private static final String SEPARATOR = ".";
	private static final String SUBJECT="subject";
	private static final String VALIDATE="validate";
	
	private static final String ENDPOINT_SERVICE="iops.endpoint";
	private static final String SERVICE_NAME="iops.wsdl";

	/** Fichier de Properties */
	private static PropertiesUtility PROPERTIE_RESOURCE;

	/** Nom de fichier de Properties */
	public final static String NAME_RESSOURCE = "interOps.properties";

	private String subject;
	private String issuer;
	private String audience;
	private String idStore;
	private String scope;

	@Override
	public IEngine parse(PrismeTokenRequest prismeRequest)
			throws PrismeSystemException {

		// Chargement properties
		getPropertiesResource();

		// - InterOpsToken
		InterOpsToken iopsToken = new InterOpsToken(
				prismeRequest.getParam(PrismeParams.ASSERTION));
		String targetCleaned = "";
		if (StringUtility.isNotNullOrEmpty(iopsToken.getTarget())) {
			targetCleaned = iopsToken.getTarget().replaceAll(":", "_");
		}
		if (isValidated(targetCleaned)) {
			validateIopsToken(iopsToken);
		}
		// - Subject
		this.buildSubject(targetCleaned);
		// - Issuer
		this.issuer = iopsToken.getIssuer();
		// - Audience (scope request)
		// - Scope Response
		this.buildAudienceAndScope(targetCleaned, iopsToken.getPAGMS());
		// - Id Store
		try {
			this.idStore = ScopeUtility.encodeIdStore(this.subject,
					this.issuer, "[" + this.audience + "]");
		} catch (IOException e) {
			_logger.error("Erreur generation id store InterOpsToken : "
					+ e.getMessage());
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					"Erreur generation id store InterOpsToken");
		}
		return this;
	}

	/**
	 * @param iopsToken
	 * @throws PrismeSystemException
	 */
	private void validateIopsToken(InterOpsToken iopsToken)
			throws PrismeSystemException {
		String endpoint = StringUtils.trimToEmpty(PROPERTIE_RESOURCE
				.getProperty(ENDPOINT_SERVICE));
		String wsdlurl = StringUtils.trimToEmpty(PROPERTIE_RESOURCE
				.getProperty(SERVICE_NAME));
		iopsToken.validate(wsdlurl, endpoint);
	}

	private boolean isValidated(String targetCleaned) {
		if ("true".equalsIgnoreCase(StringUtils.trimToEmpty(PROPERTIE_RESOURCE
				.getProperty(targetCleaned + SEPARATOR + VALIDATE)))) {
			return true;
		}
		return false;
	}

	@Override
	public String getSubject() {
		return this.subject;
	}

	@Override
	public String getIssuer() {
		return this.issuer;
	}

	@Override
	public String getAudience() {
		return this.audience;
	}

	@Override
	public String getIdStore() {
		return this.idStore;
	}

	/**
	 * Référence vers le fichier de définition des ressources de l'application.
	 */
	public static void getPropertiesResource() {
		if (PROPERTIE_RESOURCE == null) {
			PROPERTIE_RESOURCE = PropertiesUtility.build(NAME_RESSOURCE);
		}
		_logger.debug(">>> propertiesResource: " + PROPERTIE_RESOURCE.getNameProperty());
	}

	/**
	 * buildSubject
	 * 
	 * @param target
	 *            String
	 */
	private void buildSubject(String target) {
		_logger.debug(">>> buildSubject");

		this.subject = "";
		if (StringUtility.isNotNullOrEmpty(target)) {
			this.subject = StringUtils.trimToEmpty(PROPERTIE_RESOURCE.getProperty(target
					+ SEPARATOR + SUBJECT));
		}
		_logger.debug("subject:" + this.subject);

		_logger.debug("<<< buildSubject");
	}

	/**
	 * buildAudienceAndScope
	 * 
	 * @param target
	 * @param pagmList
	 */
	private void buildAudienceAndScope(String target, List<String> pagmList)
			throws PrismeSystemException {
		_logger.debug(">>> buildAudienceAndScope");

		// cumul des pagms.
		// regle : (*)padm => (1)scope - separateur[,]
		String pagms = Joiner.on(SEPARATOR_PAGMS).skipNulls().join(pagmList);
		_logger.debug("pagms:" + pagms);

		String scopeRequest = target;
		if (StringUtility.isNotNullOrEmpty(pagms)) {
			scopeRequest = target + SEPARATOR + pagms;
		}
		_logger.debug("scopeRequest:" + scopeRequest);
		this.audience = PrismeRequestScope.set().addScopeComplete(scopeRequest)
				.build().encode();

		String scope = StringUtils.trimToEmpty(PROPERTIE_RESOURCE
				.getProperty(scopeRequest));
		_logger.debug("scope:" + scope);
		this.scope = scope;

		_logger.debug("<<< buildAudienceAndScope");
	}

	@Override
	public String getScope() {
		return this.scope;
	}
}