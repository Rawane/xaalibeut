package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;
import java.security.interfaces.RSAPublicKey;

import net.minidev.json.JSONObject;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.providers.bean.PermissionsData;
import fr.recouv.securite.prisme.commun.security.utility.RSAPublicKeyUtility;

/**
 * EntryCache
 */
public class EntryCache implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = -4721529678343500463L;

	// Attributs
	private String key;

	private String value;

	/**
	 * Constructeur simple.
	 */
	public EntryCache() {
		super();
	}

	/**
	 * Constructeur depuis PrismeResponseScope.
	 * 
	 * @param key
	 *            String
	 * @param scope
	 *            PrismeResponseScope
	 */
	public EntryCache(final String key, final PrismeResponseScope scope) {
		this.key = key;
		this.value = scope.serialize();
	}

	/**
	 * Constructeur depuis RSAPublicKey.
	 * 
	 * @param key
	 *            String
	 * @param rsaKey
	 *            RSAPublicKey
	 */
	public EntryCache(final String key, final RSAPublicKey rsaKey) {
		this.key = key;
		try {
			this.value = RSAPublicKeyUtility.convertRSAPublicKey(rsaKey);
		} catch (PrismeInvalidTokenException e) {
			this.value = "EXCEPTION PrismeInvalidTokenException : " + e.getMessage();
		}
	}

	/**
	 * Constructeur depuis String.
	 * 
	 * @param key
	 *            String
	 * @param value
	 *            String
	 */
	public EntryCache(final String key, final String value) {
		this.key = key;
		this.value = value;
	}

	/**
	 * Constructeur depuis AnaisUser.
	 * 
	 * @param key
	 *            String
	 * @param user
	 *            AnaisUser
	 */
	public EntryCache(final String key, final AnaisUser user) {
		this.key = key;
		this.value = user.getUid().value() + " - " + user.getCn().value() + "/" + user.getOu().value();
	}

	/**
	 * Constructeur depuis AnaisApplication.
	 * 
	 * @param key
	 *            String
	 * @param app
	 *            AnaisApplication
	 */
	public EntryCache(final String key, final AnaisApplication app) {
		this.key = key;
		this.value = app.getCn().value() + " - " + app.getAppDescription().value();
	}

	/**
	 * Constructeur depuis PermissionsData.
	 * 
	 * @param key
	 *            String
	 * @param permission
	 *            PermissionsData
	 */
	public EntryCache(final String key, final PermissionsData permission) {
		this.key = key;
		this.value = permission.getListeActionsUnitaire().replaceAll(",", " ");
	}

	/**
	 * @return the key
	 */
	public final String getKey() {
		return this.key;
	}

	/**
	 * @return the value
	 */
	public final String getValue() {
		return this.value;
	}

	@Override
	public String toString() {
		JSONObject response = new JSONObject();
		response.put("key", this.key);
		response.put("value", this.value);
		return response.toJSONString();
	}
}
