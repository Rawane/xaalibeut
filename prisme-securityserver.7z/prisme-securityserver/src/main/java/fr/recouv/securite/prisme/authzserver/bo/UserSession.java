package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAuthenticator;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.utils.PropertiesUtility;

/**
 * UserSession : <br>
 * Represente la personne connectée et ses informations de context de session.<br>
 * Object sous structure JSON.
 */
public class UserSession implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 5027852757719254213L;

	// CONSTANTES

	/**
	 * INDEFINI.
	 */
	public static final String INDEFINI = "indéfini";

	/**
	 * LIBELLE_PROFIL_ADMINSECU.
	 */
	public static final String LIBELLE_PROFIL_ADMINSECU = "ADMINSECU";

	/**
	 * LIBELLE_PROFIL_EXPLOITATION.
	 */
	public static final String LIBELLE_PROFIL_EXPLOITATION = "EXPLOITATION";

	/**
	 * LIBELLE_PROFIL_MOE.
	 */
	public static final String LIBELLE_PROFIL_MOE = "MOE";

	// ATTRIBUTS

	private AnaisUser anaisUser;

	// ATTRIBUTS (JSON)

	@JsonProperty
	private String nom;

	@JsonProperty
	private String identifiant;

	@JsonProperty
	private String role;

	@JsonProperty
	private String versionPrisme;

	@JsonProperty
	private String versionPSS;

	@JsonProperty
	public List<JSONMenu> listeMenu = new ArrayList<JSONMenu>();

	/**
	 * Element du menu (href, class, title).
	 */
	public class JSONMenu implements Serializable {
		/** serialVersionUID */
		private static final long serialVersionUID = -5952942196325024473L;

		@JsonProperty
		public String menuHref;

		@JsonProperty
		public String menuClass;

		@JsonProperty
		public String menuTitle;
	}

	// CONSTRUCTEUR

	/**
	 * Constructeur simple.
	 */
	public UserSession() {
		this.anaisUser = null;
		// Init UserSession sur INDEFINI
		this.nom = UserSession.INDEFINI;
		this.identifiant = UserSession.INDEFINI;
		this.role = UserSession.INDEFINI;
		// Versions
		this.versionPrisme = UserSession.INDEFINI;
		this.versionPSS = UserSession.INDEFINI;
	}

	/**
	 * Constructeur.
	 * 
	 * @param username
	 *            String
	 * @param password
	 *            String
	 * @throws PrismeSystemException
	 *             exception
	 */
	public UserSession(final String username, final String password)
			throws PrismeSystemException {
		// Authentification Anais
		this.anaisUser = PrismeAnaisAuthenticator.authenticateUser(username,
				password);
		// Recuperation valeurs
		// - nom connecte
		this.nom = anaisUser.getCn().value();
		// - identifiant
		this.identifiant = anaisUser.getUid().value();
		// Recuperation liste Habilitations
		List<AnaisAccessRightInstance> liste = PrismeAnaisAuthenticator
				.listeHabilitationsPrisme(this.anaisUser);
		if (liste == null || liste.isEmpty() || liste.size() != 1) {
			throw new PrismeSystemException(ExceptionCode.SECURITY,
					"Erreur lors de la recuperation des habilitations Prisme sur Anais.");
		} else {
			// - role
			this.role = liste.get(0).getCn().value();
		}
		// Construction menu
		this.buildMenu();
		// Recuperation version
		this.buildVersion();
	}

	// METHODES

	/**
	 * buildMenu : construction menu selon profil.
	 */
	public void buildMenu() {

		// Init Liste Menu
		this.listeMenu = new ArrayList<JSONMenu>();

		// Dashboard
		JSONMenu dashboard = new JSONMenu();
		dashboard.menuHref = "dashboard.jsp";
		dashboard.menuClass = "fa fa-dashboard fa-fw";
		dashboard.menuTitle = "Dashboard";
		this.listeMenu.add(dashboard);

		// Applications
		if (hasRole(UserSession.LIBELLE_PROFIL_ADMINSECU)
				|| hasRole(UserSession.LIBELLE_PROFIL_MOE)) {
			JSONMenu applications = new JSONMenu();
			applications.menuHref = "applications.jsp";
			applications.menuClass = "fa fa-files-o fa-fw";
			applications.menuTitle = "Applications";
			this.listeMenu.add(applications);
		}

		// TokenStore
		if (hasRole(UserSession.LIBELLE_PROFIL_ADMINSECU)
				|| hasRole(UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			JSONMenu tokenStore = new JSONMenu();
			tokenStore.menuHref = "tokenStore.jsp";
			tokenStore.menuClass = "fa fa-ticket fa-fw";
			tokenStore.menuTitle = "Store Jeton";
			this.listeMenu.add(tokenStore);
		}

		// ConfigStore
		if (hasRole(UserSession.LIBELLE_PROFIL_ADMINSECU)
				|| hasRole(UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			JSONMenu configStore = new JSONMenu();
			configStore.menuHref = "configStore.jsp";
			configStore.menuClass = "fa fa-sliders fa-fw";
			configStore.menuTitle = "Store Config";
			this.listeMenu.add(configStore);
		}

		// IDTokenStore
		if (hasRole(UserSession.LIBELLE_PROFIL_ADMINSECU)
				|| hasRole(UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			JSONMenu idTokenStore = new JSONMenu();
			idTokenStore.menuHref = "idTokenStore.jsp";
			idTokenStore.menuClass = "fa fa-user fa-fw";
			idTokenStore.menuTitle = "Store ID Token";
			this.listeMenu.add(idTokenStore);
		}

		// Caches
		if (hasRole(UserSession.LIBELLE_PROFIL_ADMINSECU)
				|| hasRole(UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			JSONMenu caches = new JSONMenu();
			caches.menuHref = "caches.jsp";
			caches.menuClass = "fa fa-database fa-fw";
			caches.menuTitle = "Caches";
			this.listeMenu.add(caches);
		}

		// Parametres
		if (hasRole(UserSession.LIBELLE_PROFIL_ADMINSECU)
				|| hasRole(UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			JSONMenu parametres = new JSONMenu();
			parametres.menuHref = "parametres.jsp";
			parametres.menuClass = "fa fa-cog fa-fw";
			parametres.menuTitle = "Parametres";
			this.listeMenu.add(parametres);
		}

		// Tools
		if (hasRole(UserSession.LIBELLE_PROFIL_ADMINSECU)
				|| hasRole(UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			JSONMenu tools = new JSONMenu();
			tools.menuHref = "tools.jsp";
			tools.menuClass = "fa fa-wrench fa-fw";
			tools.menuTitle = "Outils";
			this.listeMenu.add(tools);
		}

		// A Propos
		JSONMenu aPropos = new JSONMenu();
		aPropos.menuHref = "aPropos.jsp";
		aPropos.menuClass = "fa fa-info fa-fw";
		aPropos.menuTitle = "A Propos";
		this.listeMenu.add(aPropos);
	}

	/**
	 * buildVersion.
	 */
	public void buildVersion() {
		PropertiesUtility properties = PropertiesUtility.build("version.prop");
		if (properties != null) {
			this.versionPrisme = properties.getProperty("versionPrisme");
			this.versionPSS = properties.getProperty("versionPSS");
			// Traitement local
			if (this.versionPrisme.equals("%PRISME_VERSION%") || this.versionPSS.equals("%PSS_VERSION%")) {
				this.versionPrisme = INDEFINI;
				this.versionPSS = INDEFINI;
			}
		}
	}

	// ACCESSEURS / MDOFICATEURS

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getNom() {
		return this.nom;
	}

	/**
	 * @param nom
	 *            String
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getIdentifiant() {
		return this.identifiant;
	}

	/**
	 * @param identifiant
	 *            String
	 */
	public void setIdentifiant(String identifiant) {
		this.identifiant = identifiant;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getRole() {
		return this.role;
	}

	/**
	 * @param role
	 *            String
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @param role
	 *            String
	 * @return boolean
	 */
	public boolean hasRole(String role) {
		return (role != null && role.equals(this.role));
	}

	/**
	 * @return List JSONMenu
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public List<JSONMenu> getListeMenu() {
		return this.listeMenu;
	}

	/**
	 * @return AnaisUser
	 */
	@JsonIgnore
	public AnaisUser getAnaisUser() {
		return this.anaisUser;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getVersionPrisme() {
		return this.versionPrisme;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getVersionPSS() {
		return this.versionPSS;
	}
}
