package fr.recouv.securite.prisme.authzserver.endpoint;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.codahale.metrics.annotation.Timed;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAuthenticator;
import fr.recouv.securite.prisme.authzserver.bo.IDTokenStorable;
import fr.recouv.securite.prisme.authzserver.bo.JSONRequest;
import fr.recouv.securite.prisme.authzserver.bo.JSONResponse;
import fr.recouv.securite.prisme.authzserver.client.HttpRequestUtility;
import fr.recouv.securite.prisme.authzserver.issuer.oidc.AccessTokenProducer;
import fr.recouv.securite.prisme.authzserver.issuer.oidc.AuthorizationCodeProducer;
import fr.recouv.securite.prisme.authzserver.issuer.oidc.IDTokenProducer;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;
import fr.recouv.securite.prisme.oidc.authz.exception.PrismeOIDCException;
import fr.recouv.securite.prisme.oidc.authz.request.PrismeAuthenticationRequest;
import fr.recouv.securite.prisme.oidc.authz.response.PrismeAuthenticationResponse;

@Path("/authz/{version}")
public class AuthzEndpoint {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			AuthzEndpoint.class).build();

	/**
	 * Methode ping.
	 * 
	 * @return String
	 */
	@Timed
	public String ping() {
		LOGGER.debug("ping");
		return "ping from AuthzEndpoint!";
	}

	// GET (Authz)
	/**
	 * AuthzEndpoint method GET type form_url_encoded.
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @throws Exception
	 *             exception
	 * @return Response response
	 */
	@GET
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Timed
	public Response authzGet(@Context HttpServletRequest request) throws Exception {
		// Adaptation pour ping
		if (request.getQueryString() == null) {
			// Return response
			return Response
					.status(HttpServletResponse.SC_OK)
					.entity(ping())
					.build();
		} else {
			LOGGER.debug(" > authzGet ");

			// Utiliser PrismeAuthenticationRequest
			// TODO

			// Gerer AuthenticationErrorResponse
			// TODO

			// Recuperation requestOrigin
			String requestOrigin = "?requestOrigin=" + URLEncoder.encode(request.getQueryString(), "UTF-8");

			// Determination urlLogin
			StringBuilder urlLogin = new StringBuilder();
			urlLogin.append(HttpRequestUtility.getURLRequest(request))
				.append("/oidc/login.jsp");
			// Redirection vers login.jsp
			URI uriLogin = new URL(urlLogin.toString() + requestOrigin).toURI();
			LOGGER.debug("uriLogin: " + uriLogin.toString());

			// Return response
			return Response
					.status(HttpServletResponse.SC_MOVED_TEMPORARILY)
					.location(uriLogin)
					.build();
		}
	}

	// POST (Authz)
	// TODO

	// LOGIN (submit)
	@POST
	@Path("/login")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response login(@Context HttpServletRequest request, JSONRequest user) {
		LOGGER.debug(" > login");
		// Par Defaut
		JSONResponse response = new JSONResponse();
		response.result = "Erreur dans le traitement de la requête";
		int status = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;

		try {
			// Variables
			AnaisUser anaisUser;
			// Parametres
			String username = user.username;
			String password = user.password;
			String requestOrigin = "";
			String urlIssuer = HttpRequestUtility.getURLRequest(request);

			// Traitement RequestOrigin
			if (user.requestOrigin == null || "".equals(user.requestOrigin)) {
				throw new UnsupportedEncodingException("RequestOrigin null ou vide");
			}
			// Decode RequestOrigin
			requestOrigin = URLDecoder.decode(user.requestOrigin, "UTF-8");
			// Recuperation AuthRequest
			PrismeAuthenticationRequest authRequest = PrismeAuthenticationRequest.builder()
					.buildFromQueryParam(requestOrigin);

			// Authentification Anais
			anaisUser = PrismeAnaisAuthenticator.authenticateUser(username, password);

			// Creation Response
			PrismeAuthenticationResponse authResponse = PrismeAuthenticationResponse.builder()
					.setRequestOrigin(requestOrigin)
					.setAuthorizationCode(AuthorizationCodeProducer.produce(authRequest))
					.setIDToken(IDTokenProducer.produce(authRequest, urlIssuer, anaisUser))
					.setAccessToken(AccessTokenProducer.produce(authRequest))
					.build();

			// Store IDToken
			if (authResponse.getIDToken() != null) {
				PrismeSecurityServer.idTokenStore().add(
						authRequest.getState().getValue(),
						new IDTokenStorable(authRequest.getState().getValue(), authResponse.getIDToken()));
			}

			// Response Success
			response.result = authResponse.getURI().toString();
			status = HttpServletResponse.SC_OK;

		} catch (UnsupportedEncodingException e) {
			LOGGER.debug("UnsupportedEncodingException: " + e.getMessage());
			response.result = "Erreur dans le traitement RequestOrigin de la requête";
		} catch (PrismeSystemException e) {
			LOGGER.debug("PrismeSystemException: " + e.getMessage());
			response.result = e.getMessage();
		} catch (PrismeOIDCException e) {
			LOGGER.debug("PrismeOIDCException: " + e.getMessage());
			response.result = e.getMessage();
		} catch (PrismeException e) {
			LOGGER.debug("PrismeException: " + e.getMessage());
			response.result = e.getMessage();
		}

		LOGGER.debug(" result: " + response.result);
		LOGGER.debug(" status: " + status);
		LOGGER.debug(" < login ");
		// Retour
		return Response
				.status(status)
				.entity(response)
				.build();
	}
}
