package fr.recouv.securite.prisme.authzserver.store;

import java.util.ArrayList;
import java.util.List;

import com.google.common.cache.CacheLoader;

import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisPermissions;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.utility.CacheStatsUtility;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.PrismeConfigurationException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.providers.bean.PermissionsData;
import fr.recouv.securite.prisme.commun.store.PermissionsStoreWithGuavaCache;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PermissionsStoreFromAnaisWithGuavaCache. <br>
 * Surcharge du cacheLoader de PermissionsStoreWithGuavaCache.
 */
public class PermissionsStoreFromAnaisWithGuavaCache extends PermissionsStoreWithGuavaCache implements IStore {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PermissionsStoreFromAnaisWithGuavaCache.class).build();

	/**
	 * Constructeur
	 * 
	 * @throws PrismeConfigurationException
	 *             exception
	 */
	public PermissionsStoreFromAnaisWithGuavaCache()
			throws PrismeConfigurationException {
		super();
		this.setDualMode(true);
	}

	// 
	// MANAGER
	// 

	@Override
	public List<EntryCache> list() {
		List<EntryCache> liste = new ArrayList<EntryCache>();
		for (String key : cachePermission.asMap().keySet()) {
			liste.add(new EntryCache(key, (PermissionsData) cachePermission.asMap().get(key)));
		}
		return liste;
	}

	@Override
	public int size() {
		if (cachePermission != null) {
			return cachePermission.asMap().size();
		}
		return 0;
	}

	@Override
	public String stats() {
		return CacheStatsUtility.getStatsFromGuavaCache(cachePermission,
				PrismeContexteDescriptor.getPermissionsCacheValidity());
	}

	// 
	// ACCESSEURS
	// 

	@Override
	public boolean isProviderLoaderSimpleFile() {
		return false;
	}

	// 
	// METHODES IMPLEMENTABLES
	// 

	@Override
	protected CacheLoader<String, PermissionsData> setCacheLoader() {
		// Cache Loader
		return new CacheLoader<String, PermissionsData>() {
			@Override
			public PermissionsData load(final String key)
					throws PrismeSystemException {
				// Appel Chargement par Anais
				LOGGER.debug("Enrichissement permissions pour:" + key);
				// Recuperation permissionData
				PermissionsData pData = PermissionsData.createByKey(key);
				// Retour permissions
				return PrismeAnaisPermissions.getPermissionsData(pData.getCodeApp(), pData.getCodeOrg(), pData.getLibDroit());
			}
		};
	}
}
