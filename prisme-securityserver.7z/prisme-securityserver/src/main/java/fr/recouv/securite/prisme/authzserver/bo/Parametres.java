package fr.recouv.securite.prisme.authzserver.bo;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

import org.yaml.snakeyaml.Yaml;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.io.Resources;

import fr.recouv.securite.prisme.authzserver.store.infinispan.InfinispanConfig;
import fr.recouv.securite.prisme.commun.config.business.YamlConfigurationLoader;
import fr.recouv.securite.prisme.commun.exceptions.PrismeConfigurationException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * Parametres : <br>
 * Object representant les parametres.
 */
public class Parametres extends YamlConfigurationLoader implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 8459377551934113647L;

	private final static String DEFAULT_CONFIGURATION = "infinispanConfig.yaml";

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			Parametres.class).build();

	/**
	 * INDEFINI.
	 */
	public static final String INDEFINI = "indéfini";

	@JsonProperty
	private String clusterName;

	@JsonProperty
	private String nodeName;

	@JsonProperty
	private String bindAddr;

	@JsonProperty
	private String bindPort;

	@JsonProperty
	private String initialHost;

	/**
	 * Constructeur.
	 */
	public Parametres() {
		// Objet vide
	}

	/**
	 * Chargement des parametres.
	 */
	public void load() {
		try {
			// Chargement InfinispanConfig.yaml
			URL url = getStorageConfigURL("prisme.infinispanConfig",
					DEFAULT_CONFIGURATION);
			// Lecture Guava
			InputStream isGuava = Resources.asByteSource(url).openStream();
			// Parsing Yaml
			Yaml yaml = new Yaml();
			InfinispanConfig config = yaml.loadAs(isGuava,
					InfinispanConfig.class);
			// Enregistrement config Infinispan
			this.clusterName = config.infinispan_clusterName;
			this.nodeName = config.infinispan_nodeName;
			this.bindAddr = config.jgroups_bind_addr;
			this.bindPort = config.jgroups_bind_port;
			this.initialHost = config.jgroups_tcpping_initial_hosts;
		} catch (MalformedURLException e) {
			LOGGER.error("Url yaml invalide : " + e.getMessage());
		} catch (IOException e) {
			LOGGER.error("Fichier infinispan yaml invalide : " + e.getMessage());
		} catch (PrismeConfigurationException e) {
			LOGGER.error("PrismeConfigurationException : " + e.getMessage());
		}
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getClusterName() {
		return this.clusterName;
	}

	/**
	 * @param clusterName
	 *            String
	 */
	public void setClusterName(final String clusterName) {
		this.clusterName = clusterName;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getNodeName() {
		return this.nodeName;
	}

	/**
	 * @param nodeName
	 *            String
	 */
	public void setNodeName(final String nodeName) {
		this.nodeName = nodeName;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getBindAddr() {
		return this.bindAddr;
	}

	/**
	 * @param bindAddr
	 *            String
	 */
	public void setBindAddr(final String bindAddr) {
		this.bindAddr = bindAddr;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getBindPort() {
		return this.bindPort;
	}

	/**
	 * @param bindPort
	 *            String
	 */
	public void setBindPort(final String bindPort) {
		this.bindPort = bindPort;
	}

	/**
	 * @return String
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInitialHost() {
		return this.initialHost;
	}

	/**
	 * @param initialHost
	 *            String
	 */
	public void setInitialHost(final String initialHost) {
		this.initialHost = initialHost;
	}
}
