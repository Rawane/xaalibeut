package fr.recouv.securite.prisme.authzserver.bo;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.BindingProvider;

import net.minidev.json.JSONObject;

import org.infinispan.Cache;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.fluent.get.AnaisEntityGet;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.api.anais.api.source.model.primary.HawaiOldTechnicalSupportAccessRightInstance;
import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisHabilitation;
import fr.recouv.securite.prisme.authzserver.listener.PrismeServletSession;
import fr.recouv.securite.prisme.authzserver.store.StoreManager;
import fr.recouv.securite.prisme.commun.config.bean.Config;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.AbstractToken;
import fr.recouv.securite.prisme.commun.utils.PropertiesUtility;
import fr.recouv.securite.prisme.commun.utils.StringUtility;
import fr.recouv.securite.prisme.norsys.iops.wsclient.CheckTokenInput;
import fr.recouv.securite.prisme.norsys.iops.wsclient.JetonV3;
import fr.recouv.securite.prisme.norsys.iops.wsclient.JetonV3PortType;

/**
 * Dashboard.
 */
public class Dashboard implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 8663299569964341884L;

	private String nbApplications;

	private String nbTokens;

	private String nbConfigs;

	private String nbCaches;

	private String anaisStatus;

	private String anaisHost;

	private String anaisResult;

	private String interOpsStatus;

	private String interOpsHost;

	private String interOpsResult;

	private String oceanStatus;

	private String oceanHost;

	private String oceanResult;

	/**
	 * Constructeur simple.
	 */
	public Dashboard() {
		super();
	}

	/**
	 * @return the nbApplications
	 */
	public final String getNbApplications() {
		return this.nbApplications;
	}

	/**
	 * @param nbApplications
	 *            the nbApplications to set
	 */
	public final void setNbApplications(final String nbApplications) {
		this.nbApplications = nbApplications;
	}

	/**
	 * @return the nbTokens
	 */
	public final String getNbTokens() {
		return this.nbTokens;
	}

	/**
	 * @param nbTokens
	 *            the nbTokens to set
	 */
	public final void setNbTokens(final String nbTokens) {
		this.nbTokens = nbTokens;
	}

	/**
	 * @return the nbConfigs
	 */
	public final String getNbConfigs() {
		return this.nbConfigs;
	}

	/**
	 * @param nbConfigs
	 *            the nbConfigs to set
	 */
	public final void setNbConfigs(final String nbConfigs) {
		this.nbConfigs = nbConfigs;
	}

	/**
	 * @return the nbCaches
	 */
	public final String getNbCaches() {
		return this.nbCaches;
	}

	/**
	 * @param nbCaches
	 *            the nbCaches to set
	 */
	public final void setNbCaches(final String nbCaches) {
		this.nbCaches = nbCaches;
	}

	/**
	 * @return the anaisStatus
	 */
	public final String getAnaisStatus() {
		return this.anaisStatus;
	}

	/**
	 * @param anaisStatus
	 *            the anaisStatus to set
	 */
	public final void setAnaisStatus(String anaisStatus) {
		this.anaisStatus = anaisStatus;
	}

	/**
	 * @return the anaisHost
	 */
	public final String getAnaisHost() {
		return this.anaisHost;
	}

	/**
	 * @param anaisHost
	 *            the anaisHost to set
	 */
	public final void setAnaisHost(final String anaisHost) {
		this.anaisHost = anaisHost;
	}

	/**
	 * @return the anaisResult
	 */
	public final String getAnaisResult() {
		return this.anaisResult;
	}

	/**
	 * @param anaisResult the anaisResult to set
	 */
	public final void setAnaisResult(final String anaisResult) {
		this.anaisResult = anaisResult;
	}

	/**
	 * @return the interOpsStatus
	 */
	public final String getInterOpsStatus() {
		return this.interOpsStatus;
	}

	/**
	 * @param interOpsStatus
	 *            the interOpsStatus to set
	 */
	public final void setInterOpsStatus(final String interOpsStatus) {
		this.interOpsStatus = interOpsStatus;
	}

	/**
	 * @return the interOpsHost
	 */
	public final String getInterOpsHost() {
		return this.interOpsHost;
	}

	/**
	 * @param interOpsHost
	 *            the interOpsHost to set
	 */
	public final void setInterOpsHost(final String interOpsHost) {
		this.interOpsHost = interOpsHost;
	}

	/**
	 * @return the interOpsResult
	 */
	public final String getInterOpsResult() {
		return this.interOpsResult;
	}

	/**
	 * @param interOpsResult
	 *            the interOpsResult to set
	 */
	public final void setInterOpsResult(final String interOpsResult) {
		this.interOpsResult = interOpsResult;
	}

	/**
	 * @return the oceanStatus
	 */
	public final String getOceanStatus() {
		return this.oceanStatus;
	}

	/**
	 * @param oceanStatus
	 *            the oceanStatus to set
	 */
	public final void setOceanStatus(final String oceanStatus) {
		this.oceanStatus = oceanStatus;
	}

	/**
	 * @return the oceanHost
	 */
	public final String getOceanHost() {
		return this.oceanHost;
	}

	/**
	 * @param oceanHost
	 *            the oceanHost to set
	 */
	public final void setOceanHost(final String oceanHost) {
		this.oceanHost = oceanHost;
	}

	/**
	 * @return the oceanResult
	 */
	public final String getOceanResult() {
		return this.oceanResult;
	}

	/**
	 * @param oceanResult
	 *            the oceanResult to set
	 */
	public final void setOceanResult(final String oceanResult) {
		this.oceanResult = oceanResult;
	}

	@Override
	public String toString() {
		JSONObject response = new JSONObject();
		response.put("result", "OK");
		if (StringUtility.isNotNullOrEmpty(this.nbApplications)) {
			response.put("nbApplications", this.nbApplications);
		}
		if (StringUtility.isNotNullOrEmpty(this.nbTokens)) {
			response.put("nbTokens", this.nbTokens);
		}
		if (StringUtility.isNotNullOrEmpty(this.nbConfigs)) {
			response.put("nbConfigs", this.nbConfigs);
		}
		if (StringUtility.isNotNullOrEmpty(this.nbCaches)) {
			response.put("nbCaches", this.nbCaches);
		}
		if (StringUtility.isNotNullOrEmpty(this.anaisStatus)) {
			response.put("anaisStatus", this.anaisStatus);
		}
		if (StringUtility.isNotNullOrEmpty(this.anaisHost)) {
			response.put("anaisHost", this.anaisHost);
		}
		if (StringUtility.isNotNullOrEmpty(this.anaisResult)) {
			response.put("anaisResult", this.anaisResult);
		}
		if (StringUtility.isNotNullOrEmpty(this.interOpsStatus)) {
			response.put("interOpsStatus", this.interOpsStatus);
		}
		if (StringUtility.isNotNullOrEmpty(this.interOpsHost)) {
			response.put("interOpsHost", this.interOpsHost);
		}
		if (StringUtility.isNotNullOrEmpty(this.interOpsResult)) {
			response.put("interOpsResult", this.interOpsResult);
		}
		if (StringUtility.isNotNullOrEmpty(this.oceanStatus)) {
			response.put("oceanStatus", this.oceanStatus);
		}
		if (StringUtility.isNotNullOrEmpty(this.oceanHost)) {
			response.put("oceanHost", this.oceanHost);
		}
		if (StringUtility.isNotNullOrEmpty(this.oceanResult)) {
			response.put("oceanResult", this.oceanResult);
		}
		return response.toJSONString();
	}

	//
	// Indicateurs
	//

	/**
	 * updateApplication.
	 * 
	 * @param request
	 *            HttpServletRequest
	 */
	public void updateApplication(final HttpServletRequest request) {
		this.nbApplications = "0";
		try {
			// Recuperation anaisUser connecte
			AnaisUser anaisUser = PrismeServletSession.getUserSession(request).getAnaisUser();
			// Recuperation listeHabilitations sur Applications
			final List<HawaiOldTechnicalSupportAccessRightInstance> liste = PrismeAnaisHabilitation
					.listeHabilitationsSurApplication(anaisUser);
			if (liste != null && !liste.isEmpty()) {
				this.nbApplications = Integer.toString(liste.size());
			}
		} catch (PrismeSystemException e) {
			// Exception recuperation listeApplications
		}
	}

	/**
	 * updateToken.
	 */
	public void updateToken() {
		this.nbTokens = "0";
		Cache<String, AbstractToken> cacheToken = PrismeSecurityServer.cacheToken();
		if (cacheToken != null && cacheToken.getAdvancedCache().getStatus().allowInvocations()) {
			this.nbTokens = Integer.toString(cacheToken.values().size());
		}
	}

	/**
	 * updateConfig.
	 */
	public void updateConfig() {
		this.nbConfigs = "0";
		Cache<String, Config> cacheConfig = PrismeSecurityServer.cacheRegistry();
		if (cacheConfig != null && cacheConfig.getAdvancedCache().getStatus().allowInvocations()) {
			this.nbConfigs = Integer.toString(cacheConfig.values().size());
		}
	}

	/**
	 * updateCache.
	 */
	public void updateCache() {
		this.nbCaches = Integer.toString(StoreManager.sumSizeAllStore());
	}

	/**
	 * Liste des Indicateurs.
	 */
	public enum Indicator {
		APPLICATION("application"),
		TOKEN("token"),
		CONFIG("config"),
		CACHE("cache");

		private String indicator;

		Indicator(final String indicator) {
			this.indicator = indicator;
		}

		@Override
		public String toString() {
			return this.indicator;
		}

		public static Indicator toValue(final String indicator) {
			for (final Indicator enumIndicator : Indicator.values()) {
				if (enumIndicator.indicator.equals(indicator)) {
					return enumIndicator;
				}
			}
			return null;
		}
	}

	/**
	 * RefreshIndicator
	 * 
	 * @param nom
	 *            String
	 * @param request
	 *            HttpServletRequest
	 */
	public final void refreshIndicator(final String nom, final HttpServletRequest request) {
		Indicator indicator = Indicator.toValue(nom);
		if (indicator != null) {
			switch (indicator) {
			case APPLICATION:
				this.updateApplication(request);
				break;
			case TOKEN:
				this.updateToken();
				break;
			case CONFIG:
				this.updateConfig();
				break;
			case CACHE:
				this.updateCache();
				break;
			default:
				break;
			}
		}
	}

	//
	// Validateurs
	//

	/**
	 * resolveAnais.
	 */
	public void resolveAnais() {
		// Gestion cas erreur
		this.anaisStatus = "false";
		this.anaisHost = "Host impossible à déterminer.";
		this.anaisResult = "Erreur lors de la lecture de la configuration.";
		// Resolve
		try {
			// Recuperation anaisProperties
			PropertiesUtility anaisProperties = PropertiesUtility.build("anais.properties");
			if (anaisProperties != null
					&& StringUtility.isNotNullOrEmpty(anaisProperties.getProperty("reader.hostname"))) {
				// Mise a jour Host
				this.anaisHost = anaisProperties.getProperty("reader.hostname");
				// Teste la connection anais
				new AnaisEntityGet("reader").execute();
				// Si pas d'exception, OK
				this.anaisStatus = "true";
				this.anaisResult = "OK";
			}
		} catch (AnaisExceptionFailure e) {
			// Recuperation Exception
			this.anaisResult = "Exception AnaisExceptionFailure, message: " + e.getMessage();
		} catch (AnaisExceptionServerCommunication e) {
			// Recuperation Exception
			this.anaisResult = "Exception AnaisExceptionServerCommunication, message: " + e.getMessage();
		} catch (NamingException e) {
			// Recuperation Exception
			this.anaisResult = "Exception NamingException, message: " + e.getMessage();
		}
	}

	/**
	 * resolveInterOps.
	 */
	public void resolveInterOps() {
		// Gestion cas erreur
		this.interOpsStatus = "false";
		this.interOpsHost = "Host impossible à déterminer.";
		this.interOpsResult = "Erreur lors de la lecture de la configuration.";
		// Resolve
		try {
			// Recuperation interOpsProperties
			PropertiesUtility interOpsProperties = PropertiesUtility.build("interOps.properties");
			if (interOpsProperties != null
					&& StringUtility.isNotNullOrEmpty(interOpsProperties.getProperty("iops.endpoint"))
					&& StringUtility.isNotNullOrEmpty(interOpsProperties.getProperty("iops.wsdl"))) {
				// Mise a jour Host
				this.interOpsHost = interOpsProperties.getProperty("iops.endpoint");
				// Teste la connection interOps
				String endpoint = interOpsProperties.getProperty("iops.endpoint");
				String wsdlurl = interOpsProperties.getProperty("iops.wsdl");
				// Creation Jeton InterOps
				final JetonV3 ss = new JetonV3(Thread.currentThread().getContextClassLoader().getResource(wsdlurl));
				final JetonV3PortType port = ss.getJetonV3();
				final BindingProvider provider = (BindingProvider) port;
				provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
				final CheckTokenInput checkTokenInputPart = new CheckTokenInput();
				checkTokenInputPart.setAssertionSAML("");
				checkTokenInputPart.setAssertionFormat(0);
				// Verification
				port.checkToken(checkTokenInputPart);
				// Si pas d'exception, OK
				this.interOpsStatus = "true";
				this.interOpsResult = "OK";
			}
		} catch (Exception e) {
			// Recuperation Exception
			this.interOpsResult = "Exception, message: " + e.getMessage();
		}
	}

	/**
	 * resolveOcean.
	 */
	@SuppressWarnings("deprecation")
	public void resolveOcean() {
		// Gestion cas erreur
		this.oceanStatus = "false";
		this.oceanHost = "Host impossible à déterminer.";
		this.oceanResult = "Erreur lors de la lecture de la configuration.";
		// Resolve
		try {
			// Recuperation oceanProperties
			PropertiesUtility oceanProperties = PropertiesUtility.build("ocean.properties");
			if (oceanProperties != null
					&& StringUtility.isNotNullOrEmpty(oceanProperties.getProperty("ocean.url.status"))) {
				// Mise a jour Host
				this.oceanHost = oceanProperties.getProperty("ocean.url.status");
				// HttpClient resolve
				URL baseUrl = new URL(this.oceanHost);
				String result = PrismeContexteDescriptor.getHttpClient().resolve(baseUrl);
				// Si pas d'exception et si OK
				if (result != null && "OK".equals(result.trim())) {
					this.oceanStatus = "true";
					this.oceanResult = "OK";
				} else {
					this.oceanResult = result;
				}
			}
		} catch (MalformedURLException e) {
			// Recuperation Exception
			this.oceanResult = "Exception MalformedURLException, message: " + e.getMessage();
		} catch (PrismeSystemException e) {
			// Recuperation Exception
			this.oceanResult = "Exception PrismeSystemException, message: " + e.getMessage();
		}
	}

	/**
	 * Liste des Validateurs.
	 */
	public enum Validator {
		ANAIS("anais"),
		INTEROPS("interOps"),
		OCEAN("ocean");

		private String validator;

		Validator(final String validator) {
			this.validator = validator;
		}

		@Override
		public String toString() {
			return this.validator;
		}

		public static Validator toValue(final String validator) {
			for (final Validator enumValidator : Validator.values()) {
				if (enumValidator.validator.equals(validator)) {
					return enumValidator;
				}
			}
			return null;
		}
	}

	/**
	 * RefreshValidator
	 * 
	 * @param nom
	 *            String
	 */
	public final void refreshValidator(final String nom) {
		Validator validator = Validator.toValue(nom);
		if (validator != null) {
			switch (validator) {
			case ANAIS:
				this.resolveAnais();
				break;
			case INTEROPS:
				this.resolveInterOps();
				break;
			case OCEAN:
				this.resolveOcean();
				break;
			default:
				break;
			}
		}
	}
}
