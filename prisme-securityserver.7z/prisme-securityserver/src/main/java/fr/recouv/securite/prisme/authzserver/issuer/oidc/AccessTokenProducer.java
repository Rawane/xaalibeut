package fr.recouv.securite.prisme.authzserver.issuer.oidc;

import com.nimbusds.oauth2.sdk.ResponseType;
import com.nimbusds.oauth2.sdk.token.BearerAccessToken;

import fr.recouv.securite.prisme.logger.PrismeLogger;
import fr.recouv.securite.prisme.oidc.authz.request.PrismeAuthenticationRequest;

/**
 * AccessTokenProducer.
 */
public class AccessTokenProducer {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			AccessTokenProducer.class).build();

	/**
	 * Produce.
	 * 
	 * @param authRequest
	 *            PrismeAuthenticationRequest
	 * @return BearerAccessToken accessToken
	 */
	public static BearerAccessToken produce(
			PrismeAuthenticationRequest authRequest) {
		LOGGER.debug(" > produce");
		// Si AccessToken non demande
		if (!authRequest.getResponseType().contains(ResponseType.Value.TOKEN)) {
			return null;
		}

		// Generation accessToken
		return new BearerAccessToken();
	}
}
