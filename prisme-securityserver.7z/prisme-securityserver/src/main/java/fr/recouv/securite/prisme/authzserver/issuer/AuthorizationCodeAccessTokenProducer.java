package fr.recouv.securite.prisme.authzserver.issuer;

import fr.recouv.securite.prisme.authzserver.request.PrismeTokenRequest;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.AbstractAccessToken;
import fr.recouv.securite.prisme.commun.token.AbstractRefreshToken;

public class AuthorizationCodeAccessTokenProducer implements PrismeIssuer {

	public AuthorizationCodeAccessTokenProducer(PrismeTokenRequest prismeRequest)
			throws PrismeSystemException {
		// TODO
	}

	@Override
	public AbstractAccessToken accessToken() throws PrismeSystemException {
		// TODO
		return null;
	}

	@Override
	public AbstractRefreshToken refreshToken() throws PrismeSystemException {
		// TODO
		return null;
	}

	@Override
	public PrismeResponseScope getScope() throws PrismeSystemException {
		// TODO
		return null;
	}

	@Override
	public String getTokenType() {
		return PrismeParams.TOKEN.JSON_TYPE;
	}
	/* (non-Javadoc)
	 * @see fr.recouv.securite.prisme.authzserver.issuer.PrismeIssuer#getSubject()
	 */
	@Override
	public String getSubject() {		
		return null;
	}
}
