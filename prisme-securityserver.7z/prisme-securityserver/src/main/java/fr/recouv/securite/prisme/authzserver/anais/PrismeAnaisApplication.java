package fr.recouv.securite.prisme.authzserver.anais;

import javax.naming.NamingException;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisApplication.
 */
public class PrismeAnaisApplication {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisApplication.class).build();

	private static final String CONTEXT_NAME = "reader";

	/**
	 * getApplicationByCN.
	 * 
	 * @param cn
	 *            String
	 * @return AnaisApplication
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static AnaisApplication getApplicationByCN(String cn)
			throws AnaisExceptionFailure, AnaisExceptionServerCommunication,
			NamingException {
		LOGGER.debug("> getApplicationByCN");
		AnaisApplication anaisApplication = AnaisApplication.build
				.get(CONTEXT_NAME).by(AnaisCN.set(cn)).execute();
		return anaisApplication;
	}

	/**
	 * withAccount.
	 * 
	 * @param clientId
	 *            String
	 * @param clientSecret
	 *            String
	 * @return AnaisApplication
	 * @throws AnaisExceptionFailure
	 *             exception
	 * @throws AnaisExceptionServerCommunication
	 *             exception
	 * @throws NamingException
	 *             exception
	 */
	public static AnaisApplication withAccount(String clientId,
			String clientSecret) throws AnaisExceptionFailure,
			AnaisExceptionServerCommunication, NamingException {
		LOGGER.debug("> withAccount");
		AnaisApplication anaisApplication = AnaisApplication.build
				.set(CONTEXT_NAME).withAccount(clientId, clientSecret)
				.authenticate();
		return anaisApplication;
	}
}
