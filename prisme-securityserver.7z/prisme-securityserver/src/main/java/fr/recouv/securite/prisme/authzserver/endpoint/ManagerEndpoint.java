package fr.recouv.securite.prisme.authzserver.endpoint;

import java.security.interfaces.RSAPrivateKey;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.infinispan.Cache;
import org.slf4j.LoggerFactory;

import com.codahale.metrics.annotation.Metered;
import com.codahale.metrics.annotation.Timed;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.api.anais.api.source.model.primary.HawaiOldTechnicalSupportAccessRightInstance;
import fr.recouv.securite.prisme.authzserver.PrismeSecurityServer;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAccessRightInstance;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisApplication;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisHabilitation;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisPermissions;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisUser;
import fr.recouv.securite.prisme.authzserver.bo.Application;
import fr.recouv.securite.prisme.authzserver.bo.Dashboard;
import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.bo.EntryConfig;
import fr.recouv.securite.prisme.authzserver.bo.EntryIDToken;
import fr.recouv.securite.prisme.authzserver.bo.EntryLogger;
import fr.recouv.securite.prisme.authzserver.bo.EntryToken;
import fr.recouv.securite.prisme.authzserver.bo.FormAccessToken;
import fr.recouv.securite.prisme.authzserver.bo.FormCalculDroits;
import fr.recouv.securite.prisme.authzserver.bo.FormDeEnCryptor;
import fr.recouv.securite.prisme.authzserver.bo.FormGeneratorConfig;
import fr.recouv.securite.prisme.authzserver.bo.FormLoadMetiersNatRef;
import fr.recouv.securite.prisme.authzserver.bo.IDTokenStorable;
import fr.recouv.securite.prisme.authzserver.bo.JSONRequest;
import fr.recouv.securite.prisme.authzserver.bo.JSONResponse;
import fr.recouv.securite.prisme.authzserver.bo.Parametres;
import fr.recouv.securite.prisme.authzserver.bo.UserSession;
import fr.recouv.securite.prisme.authzserver.config.ConfigGenerator;
import fr.recouv.securite.prisme.authzserver.internal.TokenEndpointInternal;
import fr.recouv.securite.prisme.authzserver.listener.PrismeServletSession;
import fr.recouv.securite.prisme.authzserver.mock.PrismeAnaisMock;
import fr.recouv.securite.prisme.authzserver.security.PrismeSecurityUtility;
import fr.recouv.securite.prisme.authzserver.store.StoreManager;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.config.bean.Config;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.PrismeProtocoleError;
import fr.recouv.securite.prisme.commun.token.AbstractToken;
import fr.recouv.securite.prisme.commun.token.JWTAccessToken;
import fr.recouv.securite.prisme.commun.token.reverse.JWTReverse;
import fr.recouv.securite.prisme.commun.utils.ScopeUtility;
import fr.recouv.securite.prisme.commun.utils.StringUtility;
import fr.recouv.securite.prisme.commun.utils.json.JSONUtils;
import fr.recouv.securite.prisme.logger.PrismeLogger;

@Path("/manager/{version}")
public class ManagerEndpoint {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			ManagerEndpoint.class).build();

	@Context
	private HttpServletRequest request;

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String ping() {
		LOGGER.debug("ping");
		return "ping from ManagerEndpoint!";
	}

	// Dashboard

	@GET
	@Path("/dashboard/indicateur/all")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getAllIndicateur() {
		LOGGER.debug("> dashboard indicator all ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu Dashboard.");
		// Si utilisateur connecte
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation dashboard
			Dashboard dashboard = new Dashboard();
			// NbApplications
			dashboard.updateApplication(this.request);
			// NbTokens
			dashboard.updateToken();
			// NbConfigs
			dashboard.updateConfig();
			// NbCaches
			dashboard.updateCache();
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(dashboard.toString());
		}
		return response.build();
	}

	@GET
	@Path("/dashboard/indicateur/refresh/{nom}")
	@Produces(MediaType.APPLICATION_JSON)	
	@Timed
	public Response refreshIndicateur(@PathParam("nom") String nom) {
		LOGGER.debug("> dashboard resfresh indicator, nom : " + nom);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu Dashboard.");
		// Si utilisateur connecte
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation dashboard
			Dashboard dashboard = new Dashboard();
			// Refresh Indicator
			dashboard.refreshIndicator(nom, this.request);
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(dashboard.toString());
		}
		return response.build();
	}

	@GET
	@Path("/dashboard/validateur/all")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getAllValidateur() {
		LOGGER.debug("> dashboard validator all ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu Dashboard.");
		// Si utilisateur connecte
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation dashboard
			Dashboard dashboard = new Dashboard();
			// Anais
			dashboard.resolveAnais();
			// InterOps
			dashboard.resolveInterOps();
			// Ocean
			dashboard.resolveOcean();
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(dashboard.toString());
		}
		return response.build();
	}

	@GET
	@Path("/dashboard/validateur/refresh/{nom}")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response refreshValidateur(@PathParam("nom") String nom) {
		LOGGER.debug("> dashboard resfresh validator, nom : " + nom);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu Dashboard.");
		// Si utilisateur connecte
		if (PrismeServletSession.isUserSession(this.request)) {
			// Recuperation dashboard
			Dashboard dashboard = new Dashboard();
			// Refresh Validator
			dashboard.refreshValidator(nom);
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(dashboard.toString());
		}
		return response.build();
	}

	// Applications

	@GET
	@Path("/application/liste")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public List<Application> listeApplications() {
		LOGGER.debug("> listeApplications");
		List<Application> listeApplications = new ArrayList<Application>();
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_MOE)) {
			// Recuperation anaisUser connecte
			AnaisUser anaisUser = PrismeServletSession.getUserSession(this.request).getAnaisUser();
			try {
				// Recuperation listeHabilitations sur Applications
				final List<HawaiOldTechnicalSupportAccessRightInstance> liste = PrismeAnaisHabilitation
						.listeHabilitationsSurApplication(anaisUser);
				for (final HawaiOldTechnicalSupportAccessRightInstance ari : liste) {
					listeApplications.add(new Application(ari));
				}
			} catch (PrismeSystemException e) {
				LOGGER.error("Exception recuperation listeApplications.");
				// Mock Anais si NamingException
				listeApplications = PrismeAnaisMock.mockListeApplication();
			}
		}
		return listeApplications;
	}

	@GET
	@Path("/application/detail/{cn}")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Application detailApplication(@PathParam("cn") String cn) {
		LOGGER.debug("> detailApplication, cn : " + cn);
		Application application = new Application();
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_MOE)) {
			try {
				// Recuperation technicalAccount
				AnaisTechnicalAccount technicalAccount = PrismeAnaisHabilitation
						.getTechnicalAccount(cn);
				if (technicalAccount != null) {
					application.parseFrom(technicalAccount);
				}
			} catch (PrismeSystemException e) {
				LOGGER.error("Exception recuperation detail Application.");
				// Mock Anais si NamingException
				application = PrismeAnaisMock.mockApplication();
			}
		}
		return application;
	}

	@POST
	@Path("/application/generateKey")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	@Timed
	public Response generateKey(JSONRequest entry) {
		LOGGER.debug("> generateKey : " + entry.cn);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur dans la génération des clés de l'application.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_MOE)) {
			try {
				// Recuperation technicalAccount
				AnaisTechnicalAccount technicalAccount = PrismeAnaisHabilitation
						.getTechnicalAccount(entry.cn);
				Application application = new Application();
				if (technicalAccount != null) {
					application.parseFrom(technicalAccount);
				}
				// Generation cles
				PrismeSecurityUtility.generateKey(application);
				// Sauvegarde cle publique
//				PrismeAnaisHabilitation.saveTechnicalAccount(technicalAccount,
//						application.getKeyPrismePublic());
				if (application.getKeyPrismePrivate() != null) {
					// Creation response
					response = Response.ok(PrismeSecurityUtility.formatPrivateKey(application.getKeyPrismePrivate()));
					response.header("Content-Disposition",
						"attachment; filename=\"" + application.getNom() + "-PrivateKey.pem\"");
				}
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception recuperation public Key.");
			}
		}
		return response.build();
	}

	@POST
	@Path("/application/publicKey")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	@Timed
	public Response getPublicKey(JSONRequest entry) {
		LOGGER.debug("> getPublicKey : " + entry.cn);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur dans la récupération de la clé publique de l'application.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_MOE)) {
			try {
				// Recuperation technicalAccount
				AnaisTechnicalAccount technicalAccount = PrismeAnaisHabilitation
						.getTechnicalAccount(entry.cn);
				Application application = new Application();
				if (technicalAccount != null) {
					application.parseFrom(technicalAccount);
				}
				if (application.getKeyPrismePublic() != null) {
					// Creation response
					response = Response.ok(application.getKeyPrismePublicFormated());
					response.header("Content-Disposition",
						"attachment; filename=\"" + application.getNom() + "-PublicKey.pem\"");
				}
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception recuperation public Key.");
			}
		}
		return response.build();
	}

	@POST
	@Path("/application/generatorConfig")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public Response generatorConfig(FormGeneratorConfig form) {
		LOGGER.debug("> generatorConfig : " + form.getMode());
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur dans la génération du fichier de configuration.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_MOE)) {
			try {
				// Recuperation version Prisme
				String versionPrisme = PrismeServletSession.getUserSession(this.request).getVersionPrisme();
				// Generation Config
				String config = ConfigGenerator.generateConfig(form, versionPrisme);
				if (StringUtility.isNotNullOrEmpty(config)) {
					// Creation response
					response = Response.ok(config);
					response.header("Content-Disposition",
						"attachment; filename=\"prisme.yaml\"");
				}
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception génération fichier de configuration.");
			}
		}
		return response.build();
	}

	@POST
	@Path("/application/accessToken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getAccessToken(FormAccessToken form) {
		LOGGER.debug("> getAccessToken ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la demande de jeton d'accès.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_MOE)) {
			try {
				// Creation requete Demande
				String request = form.buildRequeteDemande();
				// Appel TokenEndpoint Internal
				Response responseEndpoint = TokenEndpointInternal.getInstance().authorize(request);
				Map<String, Object> mapResponse = JSONUtils.parse((String) responseEndpoint.getEntity());
				// Creation result
				Map<String, Object> result = new HashMap<String, Object>();
				// Si error_code
				if (mapResponse.get(PrismeProtocoleError.ERROR_CODE) != null
						&& !mapResponse.get(PrismeProtocoleError.ERROR_CODE).equals("")) {
					// Construit Reponse en erreur
					response = Response
							.status(HttpServletResponse.SC_BAD_REQUEST)
							.entity(mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
				} else {
					// Recuperation accessToken
					result.put("access_token",
							mapResponse.get(PrismeParams.ACCESS_TOKEN));
					// Construit Reponse
					response = Response
						.status(HttpServletResponse.SC_OK)
						.entity(JSONUtils.build(result));
				}
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception génération de la requête de Demande.");
			}
		}
		return response.build();
	}

	@POST
	@Path("/application/requeteDemande")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getRequeteDemande(FormAccessToken form) {
		LOGGER.debug("> getRequeteDemande ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la génération de la requête de Demande.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_MOE)) {
			try {
				// Cast en requete Demande
				Map<String, Object> result = new HashMap<String, Object>();
				result.put("requete_demande", form.buildRequeteDemande());
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(JSONUtils.build(result));
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception génération de la requête de Demande.");
			}
		}
		return response.build();
	}

	// Token Store

	@GET
	@Path("/tokenStore/liste")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getListeTokenStore() {
		LOGGER.debug("> tokenStore List");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu TokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Recuperation liste EntryToken
				List<EntryToken> liste = new ArrayList<EntryToken>();
				Cache<String, AbstractToken> cache = PrismeSecurityServer.cacheToken();
				if (cache != null && cache.getAdvancedCache().getStatus().allowInvocations()) {
					for (AbstractToken abstractToken : cache.values()) {
						liste.add(new EntryToken(abstractToken));
					}
				}
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"data\": " + liste + " }");
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception récupération du contenu TokenStore.");
			}
		}
		return response.build();
	}

	@GET
	@Path("/tokenStore/stats")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getTokenStoreStats() {
		LOGGER.debug("> tokenStore Stats");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération des stats pour TokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(PrismeSecurityServer.tokenStore().stats());
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			}
		}
		return response.build();
	}

	@GET
	@Path("/tokenStore/start")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response startTokenStore() {
		LOGGER.debug("> start tokenStore");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur TokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Start Token Store
				PrismeSecurityServer.tokenStore().start();
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"status\": \"OK\"}");
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception : " + e.getMessage());
			}
		}
		return response.build();
	}

	@GET
	@Path("/tokenStore/stop")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response stopTokenStore() {
		LOGGER.debug("> stop tokenStore");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur TokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Stop Token Store
				PrismeSecurityServer.tokenStore().stop();
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"status\": \"OK\"}");
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception : " + e.getMessage());
			}
		}
		return response.build();
	}

	// Config Store

	@GET
	@Path("/configStore/liste")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getListeConfigStore() {
		LOGGER.debug("> configStore List");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu RegistryStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Recuperation liste EntryConfig
				List<EntryConfig> liste = new ArrayList<EntryConfig>();
				Cache<String, Config> cache = PrismeSecurityServer.cacheRegistry();
				if (cache != null && cache.getAdvancedCache().getStatus().allowInvocations()) {
					for (Config config : cache.values()) {
						liste.add(new EntryConfig(config));
					}
				}
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"data\": " + liste + " }");
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception récupération du contenu RegistryStore.");
			}
		}
		return response.build();
	}

	@GET
	@Path("/configStore/stats")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getConfigStoreStats() {
		LOGGER.debug("> configStore Stats");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération des stats pour ConfigStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(PrismeSecurityServer.registryStore().stats());
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			}
		}
		return response.build();
	}

	@GET
	@Path("/configStore/start")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response startConfigStore() {
		LOGGER.debug("> start configStore");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur ConfigStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Start Token Store
				PrismeSecurityServer.registryStore().start();
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"status\": \"OK\"}");
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception : " + e.getMessage());
			}
		}
		return response.build();
	}

	@GET
	@Path("/configStore/stop")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response stopConfigStore() {
		LOGGER.debug("> stop configStore");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur ConfigStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Stop Token Store
				PrismeSecurityServer.registryStore().stop();
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"status\": \"OK\"}");
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception : " + e.getMessage());
			}
		}
		return response.build();
	}

	// ID Token Store

	@GET
	@Path("/idTokenStore/liste")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getListeIDTokenStore() {
		LOGGER.debug("> IDTokenStore List");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu IDTokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Recuperation liste EntryIDToken
				List<EntryIDToken> liste = new ArrayList<EntryIDToken>();
				Cache<String, IDTokenStorable> cache = PrismeSecurityServer.cacheIDToken();
				if (cache != null && cache.getAdvancedCache().getStatus().allowInvocations()) {
					for (IDTokenStorable idToken : cache.values()) {
						liste.add(new EntryIDToken(idToken));
					}
				}
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"data\": " + liste + " }");
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error("Exception récupération du contenu RegistryStore.");
			}
		}
		return response.build();
	}

	@GET
	@Path("/idTokenStore/stats")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getIDTokenStoreStats() {
		LOGGER.debug("> IDTokenStore Stats");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération des stats pour IDTokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(PrismeSecurityServer.idTokenStore().stats());
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			}
		}
		return response.build();
	}

	@GET
	@Path("/idTokenStore/start")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response startIDTokenStore() {
		LOGGER.debug("> start IDTokenStore");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur IDTokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Start IDToken Store
				PrismeSecurityServer.idTokenStore().start();
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"status\": \"OK\"}");
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception : " + e.getMessage());
			}
		}
		return response.build();
	}

	@GET
	@Path("/idTokenStore/stop")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response stopIDTokenStore() {
		LOGGER.debug("> stop IDTokenStore");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'action sur IDTokenStore.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Stop IDToken Store
				PrismeSecurityServer.idTokenStore().stop();
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity("{\"status\": \"OK\"}");
			} catch (PrismeSystemException e) {
				LOGGER.error("PrismeSystemException : " + e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception : " + e.getMessage());
			}
		}
		return response.build();
	}

	// Caches

	@GET
	@Path("/cache/{nom}/liste")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getListeDetailCache(@PathParam("nom") String nom) {
		LOGGER.debug("> cache List, nom : " + nom);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu pour le cache.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Recuperation liste EntryCache
			List<EntryCache> liste = new ArrayList<EntryCache>();
			if (StoreManager.isValidStore(nom)) {
				liste.addAll(StoreManager.getStore(nom).list());
			}
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity("{\"data\": " + liste + " }");
		}
		return response.build();
	}

	@GET
	@Path("/cache/{nom}/stats")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getDetailCacheStats(@PathParam("nom") String nom) {
		LOGGER.debug("> cache Stats, nom : " + nom);
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération des stats pour le cache.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Recuperation Stats
			String stats = "";
			if (StoreManager.isValidStore(nom)) {
				stats = StoreManager.getStore(nom).stats();
			}
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity(stats);
		}
		return response.build();
	}

	@POST
	@Path("/cache/{nom}/remove")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse removeEntryCache(@PathParam("nom") String nom,
			JSONRequest entry) throws PrismeException {
		LOGGER.debug("> cache revoke, nom : " + nom + ", entry : " + entry.key);
		JSONResponse response = new JSONResponse();
		if (entry.key != null && StoreManager.isValidStore(nom)) {
			StoreManager.getStore(nom).remove(entry.key);
			response.result = PrismeParams.TRUE;
		} else {
			response.result = PrismeParams.FALSE;
		}
		return response;
	}

	@POST
	@Path("/cache/{nom}/removeAll")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse removeAllEntryCache(@PathParam("nom") String nom) throws PrismeException {
		LOGGER.debug("> cache revoke all, nom : " + nom);
		JSONResponse response = new JSONResponse();
		if (StoreManager.isValidStore(nom)) {
			StoreManager.getStore(nom).removeAll();
			response.result = PrismeParams.TRUE;
		} else {
			response.result = PrismeParams.FALSE;
		}
		return response;
	}

	// Parametres

	@GET
	@Path("/parametres/liste")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Parametres listeParametres() {
		LOGGER.debug("> listeParametres");
		Parametres parametres = new Parametres();
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Chargement parametres
			parametres.load();
		}
		return parametres;
	}

	@GET
	@Path("/parametres/logger/liste")
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response getListeLogger() {
		LOGGER.debug("> Logger List ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de la récupération du contenu de la liste des Logger.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			// Recuperation liste Logger
			List<EntryLogger> liste = new ArrayList<EntryLogger>();
			// Recuperation LoggerContext
			LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
			for (Logger logger : lc.getLoggerList()) {
				Iterator<Appender<ILoggingEvent>> iterator = logger.iteratorForAppenders();
				List<Appender<ILoggingEvent>> appenders = new LinkedList<Appender<ILoggingEvent>>();
				while (iterator.hasNext()) {
					appenders.add(iterator.next());
				}
				// Si appenders
				if (!appenders.isEmpty()) {
					// Ajout EntryLogger
					liste.add(new EntryLogger(liste.size(), logger));
				}
			}
			// Construit Reponse
			response = Response
				.status(HttpServletResponse.SC_OK)
				.entity("{\"data\": " + liste + " }");
		}
		return response.build();
	}

	@POST
	@Path("/parametres/logger/edit")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public JSONResponse editLogger(JSONRequest loggerRequest)
			throws PrismeException {
		LOGGER.debug("> Edit Logger : " + loggerRequest.name);
		JSONResponse response = new JSONResponse();
		response.result = PrismeParams.FALSE;
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
		Logger logger = lc.getLogger(loggerRequest.name);
		if (logger != null) {
			logger.setLevel(Level.toLevel(loggerRequest.level));
			response.result = PrismeParams.TRUE;
		}
		return response;
	}

	// Decryptor / Encryptor

	@POST
	@Path("/decryptor")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response decrypt(FormDeEnCryptor form) {
		LOGGER.debug("> decrypt ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors du decrypt du jeton d'accès.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Decrypt accessToken
				JWTReverse jwt = JWTReverse.set(form.getAccessTokenValue()).build();
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(jwt);
			} catch (ParseException e) {
				LOGGER.debug("ParseException : " + e.getMessage());
				LOGGER.error("Exception lors du decrypt du jeton d'accès.");
			}
		}
		return response.build();
	}

	@POST
	@Path("/encryptor")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response encrypt(FormDeEnCryptor form) {
		LOGGER.debug("> encrypt ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors de l'encrypt du jeton d'accès.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Encrypt accessToken
				JWTAccessToken jwtAccessToken = new JWTAccessToken();
				// jwtid
				jwtAccessToken.setJWTID(form.getJwtid());
				// idStore (encode)
				jwtAccessToken.setCustomClaim(PrismeParams.ID_STORE,
						ScopeUtility.encodeIdStoreComplete(form.getIdStore()));
				// issuer
				jwtAccessToken.setIssuer(form.getIssuer());
				// subject
				jwtAccessToken.setSubject(form.getSubject());
				// scope (encode)
				jwtAccessToken.setScope(PrismeResponseScope.set()
						.addScopeComplete(form.getScope()).build().encode());

				SimpleDateFormat formater = new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss");
				// issueTime
				if (form.getIssueTime() != null
						&& !form.getIssueTime().equals("")) {
					jwtAccessToken.setIssueTime(formater.parse(form
							.getIssueTime()));
				}
				// expirationTime
				if (form.getExpirationTime() != null
						&& !form.getExpirationTime().equals("")) {
					jwtAccessToken.setExpirationTime(formater.parse(form
							.getExpirationTime()));
				}

				// Signature
				RSAPrivateKey privateKey = PrismeContexteDescriptor
						.getPrivateKeyFile();
				jwtAccessToken.sign(privateKey);

				LOGGER.debug("Value :" + jwtAccessToken.value());
				// Creation result
				Map<String, Object> result = new HashMap<String, Object>();
				// Recuperation accessToken
				result.put("accessTokenValue", jwtAccessToken.value());
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(JSONUtils.build(result));
			} catch (Exception e) {
				LOGGER.debug("Exception : " + e.getMessage());
				LOGGER.error("Exception lors de l'encrypt du jeton d'accès.");
			}
		}
		return response.build();
	}

	// Tools

	@POST
	@Path("/calculListeDroits")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response calculListeDroits(FormCalculDroits form) {
		LOGGER.debug("> calculListeDroits ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors du calcul de la liste des droits.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				StringBuilder listResult = new StringBuilder();

				// Recuperation AnaisUser
				AnaisUser anaisUser = PrismeAnaisUser.byUID(form.getSubject());

				if (StringUtility.isNullOrEmpty(form.getScope())) {
					// Cas : Sans scope

					// Recuperation List AccessRight
					List<AnaisAccessRightInstance> listAccessRight = PrismeAnaisAccessRightInstance
							.listeAccessRightByAnaisUser(anaisUser);

					// Parcours pour ajout final
					for (AnaisAccessRightInstance ari : listAccessRight) {
						if (listResult.length() > 0 ) {
							listResult.append("\n");
						}
						listResult.append(ari.getOrgCode().value() + ":"
								+ ari.getApplicationCode().value() + ":"
								+ ari.getCn().value());
					}
				} else {
					// Cas : Avec Scope

					// Calcul Scope
					String requestScope = PrismeRequestScope.set().addScopeComplete(form.getScope()).encode();
					Map<String, List<String>> mapScope = ScopeUtility
							.extractMapCodeAppliListCodeOrg(requestScope);
					if (mapScope.isEmpty()) {
						throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
								"Scope incorrect");
					}

					// Pour chaque application
					for (String codeAppli : mapScope.keySet()) {
						List<AnaisAccessRightInstance> listAccessRight = null;
						// Recuperation AnaisApplication
						AnaisApplication anaisApplication = PrismeAnaisApplication.getApplicationByCN(codeAppli);
						if (anaisApplication == null) {
							throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
									"AnaisApplication inconnu : " + codeAppli);
						}

						// Determination CodeOrg
						if (mapScope.get(codeAppli).contains(PrismeRequestScope.ALL)) {
							// RequeteAnais (sans CodeOrg)
							listAccessRight = PrismeAnaisAccessRightInstance.listeAccessRightByUserApp(
									anaisUser, anaisApplication);
						} else {
							List<AnaisOrgCode> listOfOrgCode = new ArrayList<AnaisOrgCode>();
							for (String codeOrg : mapScope.get(codeAppli)) {
								listOfOrgCode.add(AnaisOrgCode.build(codeOrg));
							}
							// RequeteAnais (avec CodeOrg)
							listAccessRight = PrismeAnaisAccessRightInstance.listeAccessRightByUserAppCodeOrg(
									anaisUser, anaisApplication, listOfOrgCode);
						}

						// Parcours pour ajout final
						for (AnaisAccessRightInstance ari : listAccessRight) {
							if (listResult.length() > 0 ) {
								listResult.append("\n");
							}
							listResult.append(ari.getOrgCode().value() + ":"
									+ ari.getApplicationCode().value() + ":"
									+ ari.getCn().value());
						}
					}
				}

				// Creation result
				Map<String, Object> result = new HashMap<String, Object>();
				// Recuperation resultat
				result.put("resultat", listResult.toString());
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(JSONUtils.build(result));
			} catch (Exception e) {
				StringBuilder labelError = new StringBuilder();
				labelError.append("Exception lors du calcul de la liste des droits");
				LOGGER.debug("Exception : " + e.getMessage());
				if (StringUtility.isNotNullOrEmpty(e.getMessage())) {
					labelError.append(" (").append(e.getMessage()).append(")");
				}
				LOGGER.error(labelError.toString());
				response = Response
						.status(HttpServletResponse.SC_BAD_REQUEST)
						.entity(labelError.toString());
			}
		}
		return response.build();
	}

	// LoadMetiersNatRef

	@POST
	@Path("/loadMetiersNatRef")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timed
	public Response loadMetiersNatRef(FormLoadMetiersNatRef form) {
		LOGGER.debug("> loadMetiersNatRef ");
		// Gestion response erreur (par defaut)
		ResponseBuilder response = Response
			.status(HttpServletResponse.SC_BAD_REQUEST)
			.entity("Erreur lors du chargement du fichier MetiersNatRef.");
		// Si utilisateur connecte
		if (PrismeServletSession.hasUserSessionRole(
				this.request, UserSession.LIBELLE_PROFIL_EXPLOITATION)) {
			try {
				// Patch DSN
				if (StringUtility.isNullOrEmpty(form.getCodeOrg())) {
					form.setCodeOrg("DEFAULT");
				}
				// Appel saveDescription
				PrismeAnaisPermissions.saveDescription(form.getCodeApp(),
						form.getCodeOrg(), form.getMetiersNatRef());
				// Creation result
				Map<String, Object> result = new HashMap<String, Object>();
				// Recuperation resultat
				result.put("resultat", "success");
				// Construit Reponse
				response = Response
					.status(HttpServletResponse.SC_OK)
					.entity(JSONUtils.build(result));
			} catch (PrismeSystemException e) {
				LOGGER.debug("PrismeSystemException : " + e.getMessage());
				LOGGER.error(e.getMessage());
				response = Response
						.status(HttpServletResponse.SC_BAD_REQUEST)
						.entity(e.getMessage());
			}
		}
		return response.build();
	}
}
