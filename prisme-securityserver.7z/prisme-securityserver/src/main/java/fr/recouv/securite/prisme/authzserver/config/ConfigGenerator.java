package fr.recouv.securite.prisme.authzserver.config;

import java.io.IOException;
import java.net.URL;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;

import fr.recouv.securite.prisme.authzserver.bo.FormGeneratorConfig;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;

public class ConfigGenerator {

	/**
	 * Generate Config.
	 * 
	 * @param form FormGeneratorConfig
	 * @param versionPrisme String
	 * @return String
	 * @exception PrismeSystemException exception
	 */
	public static String generateConfig(FormGeneratorConfig form,
			String versionPrisme) throws PrismeSystemException {
		String content = "";
		try {
			// Fichier modele
			String fileUrl = "modeles/prisme-modele-" + form.getMode() + ".yaml";
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			URL url = loader.getResource(fileUrl);

			// Lecture fichier (Guava)
			content = Resources.toString(url, Charsets.UTF_8);

			// Remplace variables
			content = content.replaceAll("CONFIG_PRISME_VERSION", versionPrisme);
			content = content.replaceAll("CONFIG_HTTP_CLIENT", form.getHttpClient());
			content = content.replaceAll("CONFIG_TOKEN_ENDPOINT", form.getTokenEndpoint());
			content = content.replaceAll("CONFIG_AUTHZ_ENDPOINT", form.getAuthzEndpoint());
			content = content.replaceAll("CONFIG_REGISTRY_ENDPOINT", form.getRegistryEndpoint());
			content = content.replaceAll("CONFIG_POPULATE_ENDPOINT", form.getPopulateEndpoint());
			content = content.replaceAll("CONFIG_IDENTITY_STORE", form.getIdentityStore());
			content = content.replaceAll("CONFIG_TOKEN_STORE", form.getTokenStore());
			content = content.replaceAll("CONFIG_SECURITY_OPTIONS", form.getSecurityOptions());
			content = content.replaceAll("CONFIG_CLIENT_ID", form.getClientId());
			content = content.replaceAll("CONFIG_CLIENT_SECRET", form.getClientSecret());
			// Si client ou complet
			if (form.getMode().equals("client") || form.getMode().equals("complet")) {
				content = content.replaceAll("CONFIG_URL_CLIENT_CALLBACK", form.getUrlClientCallback());
				content = content.replaceAll("CONFIG_URL_BACKEND_REDIRECT_AFTER_AUTH", form.getUrlBackendRedirectAfterAuth());
				content = content.replaceAll("CONFIG_URL_BACKEND_LOGOUT", form.getUrlBackendLogout());
			}
			// Si resource ou complet
			if (form.getMode().equals("resource") || form.getMode().equals("complet")) {
				content = content.replaceAll("CONFIG_AUTHENTICATOR", form.getAuthenticator());
				content = content.replaceAll("CONFIG_AUTHORIZER", form.getAuthorizer());
				content = content.replaceAll("CONFIG_PROVIDER_PERMISSIONS_LOADER", form.getProviderPermissionsLoader());
				content = content.replaceAll("CONFIG_PROVIDER_PERMISSIONS_FILE", form.getProviderPermissionsFile());
				content = content.replaceAll("CONFIG_PERMISSIONS_STORE", form.getPermissionsStore());
			}
			// Si complet
			if (form.getMode().equals("complet")) {
				content = content.replaceAll("CONFIG_IDENTITY_CACHE_MAX_ENTRIES", form.getIdentityCacheMaxEntries());
				content = content.replaceAll("CONFIG_IDENTITY_VALIDITY", form.getIdentityValidity());
				content = content.replaceAll("CONFIG_TOKEN_CACHE_MAX_ENTRIES", form.getTokenCacheMaxEntries());
				content = content.replaceAll("CONFIG_TOKEN_VALIDITY", form.getTokenValidity());
				content = content.replaceAll("CONFIG_PERMISSIONS_CACHE_MAX_ENTRIES", form.getPermissionsCacheMaxEntries());
				content = content.replaceAll("CONFIG_PERMISSIONS_VALIDITY", form.getPermissionsValidity());
				content = content.replaceAll("CONFIG_JMX_ACTIVATED", form.getJmxActivated());
			}
		} catch (IOException e) {
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR,
					"Erreur lors de la recuperation du fichier de configuration modele");
		} catch (NullPointerException e) {
			throw new PrismeSystemException(ExceptionCode.CONFIG_ERROR,
					"Erreur lors de la recuperation du fichier de configuration modele");
		}
		return content;
	}
}
