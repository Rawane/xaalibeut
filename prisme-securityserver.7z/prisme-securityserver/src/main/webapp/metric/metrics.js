/**
 * reporting des metrics.
 * 
 * @returns
 */
function Metrics() {

}
Metrics.prototype.loadMetric = function() {
	// Appel Ajax
	$.ajax({
		type : 'GET',
		url : '../endpoint/metrics/1/all',
		dataType : 'json',
		success : function(dataResult, status, response) {
			console.log(dataResult);
			$.each(dataResult,function(key,metric){
				metrics.createIndicateur($('#indicateurs'),metric);
			});
		},
		error : function(dataResult, status, response) {
			console.log('dataResult');
			
		},
		complete : function() {

		}
	});
};
Metrics.prototype.createIndicateur = function(parent, metricJson) {
	console.log(parent+' json '+metricJson);
	var contentIndicateur = "<div class='col-lg-3 col-md-6'><div class='panel panel-primary' > <div class='panel-heading'>"
			+ "<div class='row'><div class='col-xs-3'><div id='icon-indicator-application' ><i class='fa fa-files-o fa-5x'></i></div></div>"
			+ "<div class='col-xs-9 text-right'><div id='nb-indicator-application' class='huge'>"+metricJson['count']+"</div>"
			+ "<div id='label-indicator-application'>"+metricJson['path']+"/path</div></div></div>	</div>"
			+ "<div class='panel-footer'><a href='#application' class='refresh-indicator disabled' id='link-indicator-application'>"
			+ "<span class='pull-left spanLeft' >"+metricJson['min']+"</span> <span class='spanMoyenne' >"+metricJson['moy']+"</span> "
			+ " <span class='pull-right spanRigth'>"+metricJson['max']+"</i></span></a>	<div class='clearfix'></div></div>	</div>";
	$(parent).append(contentIndicateur);
};
metrics = new Metrics();