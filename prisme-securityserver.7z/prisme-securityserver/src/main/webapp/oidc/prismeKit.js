// prismeKit.js
var prismeKit = (function() {
	// Data
	// TODO

	// Fonction privee
	// TODO

	// Fonction publique
	// Build
	return {
		// RequestOrigin
		"getRequestOrigin" : function() {
			console.log(" > requestOrigin ");
			if (window.location.href.indexOf('requestOrigin=') == -1) {
				return "";
			}
			return window.location.href.substring(window.location.href.indexOf('requestOrigin=')+'requestOrigin='.length);
		},
		// Construction bandeau
		"buildBandeau" : function(authContextJS) {
			console.log(" > buildBandeau ");
			// Nettoyage champs
			authContextJS = authContextJS.replace(/&quot;/g, '\\"').replace(/\\/g, '');
			// JSONParse
			var authContext = JSON.parse(authContextJS);
			// Traitement
			var resultHTML = "";
			if (!authContext.isLogged) {
				// Non connecte
				resultHTML = "<a href='" + authContext.uriLogin + "'><div class='img_PrismeKit'></div></a>";
			} else {
				// Connecte
				resultHTML = "<h3>Connecté en tant que " + authContext.subject;
				if (authContext.uriLogout) {
					resultHTML = resultHTML + " | <a href='" + authContext.uriLogout + "'>Logout</a>";
				}
				resultHTML = resultHTML + "</h3>";
			}
			// Affichage
			document.querySelector("#bandeau_PrismeKit").innerHTML = resultHTML;
		},
		// Callback
		"callback" : function(urlAction) {
			console.log(" > callback ");
			// Recuperation parametres
			var hash = location.hash.substring(1);
			var search = location.search.substring(1);
			// Creation formulaire
			var form = document.createElement("form");
			form.name = "formCallback";
			form.action = urlAction;
			form.method = "POST";
			// Ajout valeur hidden
			var inputResultCallback = document.createElement("input");
			inputResultCallback.type = "hidden";
			inputResultCallback.name = "resultCallback";
			inputResultCallback.value = (hash != "" ? hash : search);
			form.appendChild(inputResultCallback);
			// Ajout formulaire
			document.body.appendChild(form);
			// Soumission formulaire
			form.submit();
		},
		// Ping
		"ping" : function() {
			return "ping from PrismeKit !";
		}
	};
})();