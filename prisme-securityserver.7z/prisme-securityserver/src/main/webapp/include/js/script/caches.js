
// 
// Cache
// 
var cacheModule = (function() {
	// Data
	var pListeCaches = $( "#p-liste-caches" );
	var panelDetailCache = $( "#panel-detail-cache" );
	var panelAlertDetailCache = $( "#panel-alert-detail-cache" );
	var panelAlertStatsCache = $( "#panel-alert-stats-cache" );
	var dataListeEntryCache = null;
	var currentId = "";
	var btnRevokeAllCache = $( ".btn-revoke-all-cache" );

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Ajout event sur btnCache
		pListeCaches.delegate(".btn-cache", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Sauvegarde currentId
			currentId = event.target.id;
			// Ajout classe outline sur tous boutons
			$('.btn-cache').addClass("btn-outline");
			// Suppression classe outline sur bouton courant
			$(this).removeClass("btn-outline");
			// Affichage panelDetailCache
			panelDetailCache.removeClass("hide");
			// Go To Detail Cache
			$('.nav-tabs li:nth-child(1) a').click();
			// Load detail Cache
			loadDetailCache();
			// Load Stats
			loadStatsCache();
			// Masquage Loading
			$.stopLoading();
		});
		// Ajout event sur btn-refresh-detail-cache
		panelDetailCache.delegate(".btn-refresh-detail-cache", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertDetailCache);
			// Actualisation liste
			dataListeEntryCache.ajax.reload(callbackListeEntryCache);
			// Masquage Loading
			$.stopLoading();
			// Load Stats
			loadStatsCache();
		});
		// Ajout event sur btn-revoke-all-cache
		panelDetailCache.delegate(".btn-revoke-all-cache", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertDetailCache);
			// Gestion Mock
			var url = '../endpoint/manager/1/cache/' + currentId + '/removeAll';
			if (MOCK) {
				url = '../endpoint/mock/1/cache/' + currentId + '/removeAll';
			}
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la suppression de tout le cache ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel Ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								success: function( dataResult, status, response ) {
									$.log("> revokeAllCache - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertDetailCache, "La révocation de tout le cache s'est correctement déroulée.");
										// Actualisation liste
										dataListeEntryCache.ajax.reload(callbackListeEntryCache);
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur revoke Cache
										$.errorMessage(panelAlertDetailCache, "Erreur lors de la révocation de tout le cache.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertDetailCache, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertDetailCache, "Erreur lors de la révocation de tout le cache.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			});
		});
		// Ajout event sur btn-refresh-stats-cache
		panelDetailCache.delegate(".btn-refresh-stats-cache", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Load Stats
			loadStatsCache();
		});
	}
	// Load Liste Cache
	function loadDetailCache() {
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertDetailCache);
		// Gestion url
		var url = '../endpoint/manager/1/cache/' + currentId + '/liste';
		if (MOCK) {
			url = '../endpoint/mock/1/cache/' + currentId + '/liste';
		}
		// Si dataListeEntry null
		if (dataListeEntryCache == null) {
			// Init Detail Cache
			initDetailCache(url);
			// Event apres affichage
			callbackListeEntryCache();
		} else {
			// Sinon actualisation
			$.log("> reloadDetailCache ");
			// Actualisation liste
			dataListeEntryCache.ajax.url(url).load(callbackListeEntryCache);
		}
		// Masquage Loading
		$.stopLoading();
	}
	// Init Detail Cache
	function initDetailCache(url) {
		$.log("> initDetailCache ");
		// Recuperation liste Cache
		dataListeEntryCache =  $( "#listeEntryCache" ).DataTable({
			"paging": true,
			"info": true,
			"searching": true,
			"ajax": {
				"url": url,
				"async": false,
				"dataSrc": "data",
				"error": function( dataResult, status, response ) {
					// Erreur Recuperation Caches
					$.errorMessage(panelAlertDetailCache, dataResult.responseText);
					// Ecriture Message
					$( "#listeEntryCache .dataTables_empty" ).html(dataResult.responseText);
				}
			},
			"columns": [
				{ "data": "key" },
				{ "data": "value" },
				{ "data": null }
				// Additionals Hidden Columns
			],
			"columnDefs": [
				// Value
				{
					"targets": [1],
					"render": function ( data ) {
						if (currentId == "key-store") {
							return $.formatPublicKey( data );
						} else {
							return data;
						}
					}
				// Action
				}, {
					"targets": [2],
					"orderable" : false,
					"searchable": false,
					"class" : "align-center valign-middle",
					"defaultContent": 
						"<button class='btn btn-danger btn-circle btn-remove-entry-cache' type='button'><i class='fa fa-trash-o' aria-hidden='true'></i></button>"
				// Additionals Hidden Columns
				}
			],
			"order": [[0, "asc"]],
			"language": $.configDatatable()
		});
		// Event : btn-remove-entry-cache
		dataListeEntryCache.on('click', '.btn-remove-entry-cache', function (e) {
			e.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertDetailCache);
			// Recuperation dataEntryCache
			var dataEntryCache = dataListeEntryCache.row($(this).parents('tr')).data();
			// Gestion Mock
			var url = '../endpoint/manager/1/cache/' + currentId + '/remove';
			if (MOCK) {
				url = '../endpoint/mock/1/cache/' + currentId + '/remove';
			}
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la suppression de l'entrée du cache ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								contentType: 'application/json',
								data: JSON.stringify({
									"key": dataEntryCache.key
								}),
								success: function( dataResult, status, response ) {
									$.log("> removeCache - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertDetailCache, "La révocation de l'entrée du cache s'est correctement déroulée.");
										// Actualisation liste
										dataListeEntryCache.ajax.reload(callbackListeEntryCache);
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur revoke Config
										$.errorMessage(panelAlertDetailCache, "Erreur lors de la révocation de l'entrée du cache.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertDetailCache, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertDetailCache, "Erreur lors de la révocation de l'entrée du cache.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			});
		});
	}
	// Callback Liste Config
	function callbackListeEntryCache() {
		$.log("> callbackListeEntryCache ");
		// Gestion bouton Revoke All Cache
		if (dataListeEntryCache.data().count() > 0) {
			btnRevokeAllCache.removeAttr('disabled');
		} else {
			btnRevokeAllCache.attr('disabled', '');
		}
	}
	// Fonction loadStatsCache
	function loadStatsCache() {
		$.log("> loadStatsCache ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsCache);
		// Gestion url
		var url = '../endpoint/manager/1/cache/' + currentId + '/stats';
		if (MOCK) {
			url = '../endpoint/mock/1/cache/' + currentId + '/stats';
		}
		// Masquage stats complementaires
		$( ".div-stats-advanced" ).addClass("hide");
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Si data
				if (Object.keys(data).length > 0) {
					// Affichage stats complementaires
					$( ".div-stats-advanced" ).removeClass("hide");
					// Ajout informations
					panelDetailCache.find("#size").html(data.size);
					panelDetailCache.find("#expireAfterWrite").html(data.expireAfterWrite
							+ $.formatExpireAfter(data.expireAfterWrite));
					panelDetailCache.find("#hitCount").html(data.hitCount);
					panelDetailCache.find("#missCount").html(data.missCount);
					panelDetailCache.find("#loadSuccessCount").html(data.loadSuccessCount);
					panelDetailCache.find("#loadExceptionCount").html(data.loadExceptionCount);
					panelDetailCache.find("#totalLoadTime").html(data.totalLoadTime
							+ $.formatNanoseconds(data.totalLoadTime));
					panelDetailCache.find("#evictionCount").html(data.evictionCount);
				} else {
					// Affichage message warning
					$.warningMessage(panelAlertStatsCache, "Le cache n'est actuellement pas disponible.");
				}
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsCache, "Erreur récuperation statistiques.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build cacheModule");
			// Affichage Loading
			$.startLoading();
			// Mise en place Listener sur Event
			setEventListener();
			// Masquage Loading
			$.stopLoading();
		}
	};
})();