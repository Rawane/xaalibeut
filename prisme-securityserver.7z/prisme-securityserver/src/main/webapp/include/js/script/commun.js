
// 
// Commun
// 
var INDEFINI = "indéfini";
var LOG = true;
var MOCK = false;

// 
// Fonctions globales
// 
// LOG
$.log = function(msg) {
	if (LOG) {
		console.log(msg);
	}
};
// Recuperation PARAM dans URL
$.urlParam = function(name) {
	var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
	if (results == null) {
		return null;
	} else {
		return results[1] || 0;
	}
};
// alert
$.alert = function(msg) {
	$.log("> alert : " + msg);
	window.alert(msg);
};
// Tooltip
$.tooltip = function() {
	$('[data-toggle="tooltip"]').tooltip();	
}; 
// Popover
$.popover = function() {
	$('[data-toggle="popover"]').popover();
};

// Var global pour Loading
var nbLoading = 0;
var timer;
var divLoading = $( "#div-loading" );
var divCloseLoading = $( "#div-close-loading" );
// Start Loading
$.startLoading = function() {
	nbLoading++;
	$.log("> startLoading / nbLoading : " + nbLoading);
	// Affichage divLoading
	divLoading.removeClass("hide");
	// Timer sur closeLoading
	divCloseLoading.addClass("hide");
	clearTimeout(timer);
	timer = setTimeout(function() {
		if (!divLoading.hasClass("hide")) {
			$.log("> setTimeOut closeLoading ");
			divCloseLoading.removeClass("hide");
		}
	}, 10000);
};
// Stop Loading
$.stopLoading = function() {
	nbLoading--;
	$.log("> stopLoading / nbLoading : " + nbLoading);
	// Masquage divLoading
	if (nbLoading <= 0) {
		nbLoading = 0;
		divLoading.addClass("hide");
	}
};
// Close Loading
$.closeLoading = function() {
	nbLoading = 0;
	$.log("> closeLoading / nbLoading : " + nbLoading);
	// Masquage divLoading
	divLoading.addClass("hide");
};
// Clean Message
$.cleanMessage = function(panel) {
	panel.removeClass("alert-warning");
	panel.removeClass("alert-danger");
	panel.removeClass("alert-success");
	panel.addClass("hide");
	panel.html("&nbsp;");
};
// Message Succes
$.successMessage = function(panel, label) {
	panel.removeClass("hide");
	panel.removeClass("alert-warning");
	panel.removeClass("alert-danger");
	panel.addClass("alert-success");
	panel.html(label);
};
// Message Warning
$.warningMessage = function(panel, label) {
	panel.removeClass("hide");
	panel.removeClass("alert-success");
	panel.removeClass("alert-danger");
	panel.addClass("alert-warning");
	panel.html(label);
};
// Message Error
$.errorMessage = function(panel, label) {
	panel.removeClass("hide");
	panel.removeClass("alert-success");
	panel.removeClass("alert-warning");
	panel.addClass("alert-danger");
	panel.html(label);
};
// Telechargement fichier apres envoi formulaire
$.downloadFileXHR = function(url, tabParam, callbackSuccess, callbackError) {
	// Affichage Loading
	$.startLoading();
	// XHttpRequest
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (xhttp.readyState === 4) {
			if (xhttp.status === 200) {
				// Recuperation filename
				var disposition = xhttp.getResponseHeader("Content-Disposition");
				var filename = "";
				var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
				var matches = filenameRegex.exec(disposition);
				if (matches != null && matches[1]) { 
					filename = matches[1].replace(/['"]/g, '');
				}
				// Generation lien
				var a = document.createElement('a');
				a.href = window.URL.createObjectURL(xhttp.response);
				a.download = filename;
				a.style.display = 'none';
				document.body.appendChild(a);
				a.click();
				// callbackSuccess
				if (callbackSuccess) {
					callbackSuccess.call(this);
				}
				// Masquage Loading
				$.stopLoading();
			} else {
				// callbackError
				if (callbackError) {
					callbackError.call(this);
				}
				// Masquage Loading
				$.stopLoading();
			}
		}
	};
	xhttp.open("POST", url, true);
	xhttp.setRequestHeader("Content-Type", "application/json");
	xhttp.responseType = 'blob';
	xhttp.send(JSON.stringify(tabParam));
};
// Teste si le navigateur est compatible FileReader
$.isFileReaderAvailable = function() {
	return (typeof window.FileReader == 'function');
};
// Recuperation contentFile pour upload
$.readContentFileUpload = function(id, onLoadCallback) {
	var input, file, fr;
	// Recuperation par FileReader
	input = document.getElementById(id);
	file = input.files[0];
	if (file != undefined) {
		// Fonction callback apres onLoad
		fr = new FileReader();
		fr.onload = onLoadCallback;
		fr.readAsText(file);
	} else {
		onLoadCallback.call();
	}
};
// Go To
$.goTo = function(label) {
	if ($(label) != null) {
		$(document).scrollTop( $(label).offset().top );
	}
};
// Configuration Datatable
$.configDatatable = function() {
	return {
		"decimal":        ",",
		"emptyTable":     "Aucune donnée présente",
		"info":           "Affichage de la page _PAGE_ sur _PAGES_",
		"infoEmpty":      "Aucun élément à afficher",
		"infoFiltered":   "(filtré sur _MAX_ entrées au total)",
		"infoPostFix":    "",
		"thousands":      " ",
		"lengthMenu":     "Afficher _MENU_ éléments",
		"loadingRecords": "Chargement...",
		"processing":     "Traitement en cours...",
		"search":         "Filtrer:",
		"zeroRecords":    "Aucun élément",
		"paginate": {
			"first":      "Premier",
			"last":       "Dernier",
			"next":       "Suivant",
	 		"previous":   "Précédent"
		},
		"aria": {
			"sortAscending":  ": trier la colonne par ordre ascendant",
			"sortDescending": ": trier la colonne par ordre descendant"
		}
	};
};
// Formate Date
$.formatDate = function(date) {
	return moment(date).format('DD/MM/YYYY HH:mm:ss');
};
// Formate Nanoseconds en Seconds
$.formatNanoseconds = function(nanoseconds) {
	return $.formatTime('milliseconds', nanoseconds/1000000);
};
// Formate ExpireAfter
$.formatExpireAfter = function(seconds) {
	if (seconds == '-1') {
		return " (illimité)";
	} else if (seconds == 0) {
		return " (pas de cache)";
	} else {
		return $.formatTime('seconds', seconds);
	}
};
// Formate Time
$.formatTime = function(unit, value) {
	// Conversion time
	var timeConverted = "";
	if (value == 0) {
		return timeConverted;
	}
	var time = moment.duration(value, unit);
	if (time.asHours() == 1) {
		timeConverted = " (" + time.asHours() + " heure)";
	} else if (time.asHours() > 1) {
		timeConverted = " (" + time.asHours().toFixed(2) + " heures)";
	} else if (time.asMinutes() == 1) {
		timeConverted = " (" + time.asMinutes() + " minute)";
	} else if (time.asMinutes() > 1) {
		timeConverted = " (" + time.asMinutes().toFixed(2) + " minutes)";
	} else if (time.asSeconds() == 1) {
		timeConverted = " (" + time.asSeconds() + " seconde)";
	} else {
		timeConverted = " (" + time.asSeconds().toFixed(2) + " secondes)";
	}
	return timeConverted;
};
// Canvas
$.formatCanvas = function() {
	$('.uid-canvas').each(function( i, obj ) {
		var canvas = document.getElementById(obj.id);
		if (canvas && canvas.getContext) {
			var ctx = canvas.getContext("2d");
			var uid = obj.id.replace("canvas_", "");
			var iX = 0, deb = 0, fin = 6;
			for (var i = 0; i < 5; i++) {
				ctx.fillStyle = "#" + uid.substring(deb, fin);
				ctx.fillRect(iX, 0, 10, 10);
				iX = iX + 12, deb = deb + 6, fin = fin + 6;
			}
		}
	});
};
// PublicKey
$.formatPublicKey = function( data ) {
	var result = "-----BEGIN RSA PUBLIC KEY-----<br />";
	var listeData = data.match(/.{1,63}/g);
	for (var i = 0; i < listeData.length; i++) {
		result += listeData[i] + "<br />";
	}
	result += "-----END RSA PUBLIC KEY-----";
	return result;
};
// Format Boolean Icon
$.formatBooleanIcon = function ( booleanValue ) {
	if ( booleanValue == true || booleanValue == "true" ) {
		return "<button type=\"button\" class=\"btn btn-success btn-circle btn-no-pointer\"><i class=\"fa fa-check\"> </i></button>";
	} else {
		return "<button type=\"button\" class=\"btn btn-danger btn-circle btn-no-pointer\"><i class=\"fa fa-times\"> </i></button>";
	}
};
// WriteStatsStore (TokenStore / ConfigStore)
$.writeStatsStore = function (panelStore, panelAlert, data) {
	// Ajout informations
	panelStore.find("#status").html(data.status);
	// Desactivation boutons start et stop
	panelStore.find(".btn-start-store").attr('disabled', '');
	panelStore.find(".btn-stop-store").attr('disabled', '');
	// Masquage status et stats
	$( ".div-status" ).addClass("hide");
	$( ".div-stats" ).addClass("hide");
	// Si Not Running
	if (data.status == "NOT RUNNING") {
		// Message Warning
		$.warningMessage(panelAlert, "Le cache n'est actuellement pas disponible.");
	} else {
		// Affichage status
		$( ".div-status" ).removeClass("hide");
		panelStore.find("#cacheValidity").html(data.cacheValidity 
				+ $.formatTime("seconds", data.cacheValidity));
		panelStore.find("#allowInvocations").html($.formatBooleanIcon(data.allowInvocations));
		panelStore.find("#isStopping").html($.formatBooleanIcon(data.isStopping));
		panelStore.find("#isTerminated").html($.formatBooleanIcon(data.isTerminated));
		panelStore.find("#needToDestroyFailedCache").html($.formatBooleanIcon(data.needToDestroyFailedCache));
		panelStore.find("#needToInitializeBeforeStart").html($.formatBooleanIcon(data.needToInitializeBeforeStart));
		panelStore.find("#startAllowed").html($.formatBooleanIcon(data.startAllowed));
		panelStore.find("#startingUp").html($.formatBooleanIcon(data.startingUp));
		panelStore.find("#stopAllowed").html($.formatBooleanIcon(data.stopAllowed));
		if (data.status != "TERMINATED") {
			// Affichage stats
			$( ".div-stats" ).removeClass("hide");
			panelStore.find("#averageReadTime").html(data.averageReadTime
					+ $.formatTime("milliseconds", data.averageReadTime));
			panelStore.find("#averageRemoveTime").html(data.averageRemoveTime
					+ $.formatTime("milliseconds", data.averageRemoveTime));
			panelStore.find("#averageWriteTime").html(data.averageWriteTime
					+ $.formatTime("milliseconds", data.averageWriteTime));
			panelStore.find("#evictions").html(data.evictions);
			panelStore.find("#retrievals").html(data.retrievals);
			panelStore.find("#hits").html(data.hits);
			panelStore.find("#misses").html(data.misses);
			panelStore.find("#numberOfEntries").html(data.numberOfEntries);
			panelStore.find("#totalNumberOfEntries").html(data.totalNumberOfEntries);
			panelStore.find("#removeHits").html(data.removeHits);
			panelStore.find("#removeMisses").html(data.removeMisses);
			panelStore.find("#timeSinceReset").html(data.timeSinceReset
					+ $.formatTime("seconds", data.timeSinceReset));
			panelStore.find("#timeSinceStart").html(data.timeSinceStart
					+ $.formatTime("seconds", data.timeSinceStart));
		}
	}
	// Actualisation boutons
	if (data.status == "INSTANTIATED" || data.status == "TERMINATED") {
		panelStore.find(".btn-start-store").removeAttr('disabled');
	}
	if (data.status == "RUNNING" || data.status == "FAILED") {
		panelStore.find(".btn-stop-store").removeAttr('disabled');
	}
};
// Compare version
$.compareVersion = function ( a, b, inf, sup ) {
	if (a == "undefined" || a == "") {
		return inf;
	}
	if (b == "undefined" || b == "") {
		return sup;
	}
	if (a == b) {
		return 0;
	}
	var ta = a.split(".");
	var tb = b.split(".");
	if (ta.length > tb.length) {
		var da = ta.length - tb.length;
		for (var ia = 0; ia < da; ia++) {
			tb.push("0");
		}
	}
	if (tb.length > ta.length) {
		var db = tb.length - ta.length;
		for (var ib = 0; ib < db; ib++) {
			ta.push("0");
		}
	}
	for (var j = 0; j < tb.length; j++) {
		if (ta[j] != tb[j]) {
			var xa = parseFloat(ta[j]);
			var xb = parseFloat(tb[j]);
			if (xa < xb) {
				return inf;
			}
			if (xa > xb) {
				return sup;
			}
		}
	}
	return 0;
};
jQuery.extend( jQuery.fn.dataTableExt.oSort, {
	"numeric-version-asc": function ( a, b ) {
		return $.compareVersion(a, b, -1, 1);
	},
	"numeric-version-desc": function ( a, b ) {
		return $.compareVersion(a, b, 1, -1);
	}
});
