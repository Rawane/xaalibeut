
// 
// TokenStore
// 
var tokenStoreModule = (function() {
	// Data
	var panelTokenStore = $( "#panel-token-store" );
	var panelAlertStatsTokenStore = $( "#panel-alert-stats-token-store" );
	var panelAlertListeToken = $( "#panel-alert-liste-token" );
	var panelDetailToken = $( "#panel-detail-token" );
	var dataListeToken = null;
	var btnRevokeAllToken = $( ".btn-revoke-all-token" );

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Event bouton btn-refresh-token-store
		panelTokenStore.delegate(".btn-refresh-token-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeToken);
			// Actualisation liste
			dataListeToken.ajax.reload(callbackListeToken);
			// Masquage Loading
			$.stopLoading();
			// Recuperation Stats TokenStore
			getTokenStoreStats();
		});
		// Event bouton Revoke All
		panelTokenStore.delegate(".btn-revoke-all-token", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeToken);
			// Gestion Mock
			var url = '../endpoint/revoke/1/revokeAllToken';
			if (MOCK) {
				url = '../endpoint/mock/1/revokeAllToken';
			}
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la suppression de tous les jetons d'accès ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel Ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								success: function( dataResult, status, response ) {
									$.log("> revokeAllToken - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertListeToken, "La révocation de tous les jetons d'accès s'est correctement déroulée.");
										// Actualisation liste
										dataListeToken.ajax.reload(callbackListeToken);
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur revoke Token
										$.errorMessage(panelAlertListeToken, "Erreur lors de la révocation de tous les jetons d'accès.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertListeToken, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertListeToken, "Erreur lors de la révocation de tous les jetons d'accès.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			});
		});
		// Event bouton btn-refresh-stats-token-store
		panelTokenStore.delegate(".btn-refresh-stats-token-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Recuperation Stats TokenStore
			getTokenStoreStats();
		});
		// Event bouton btn-start-token-store
		panelTokenStore.delegate(".btn-start-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Start Token Store
			startTokenStore();
		});
		// Event bouton btn-stop-token-store
		panelTokenStore.delegate(".btn-stop-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Stop Token Store
			stopTokenStore();
		});
	}

	// Callback Liste Token
	function callbackListeToken() {
		$.log("> callbackListeToken ");
		// Traitement uid en canvas
		$.formatCanvas();
		// Gestion bouton Revoke All Token
		if (dataListeToken.data().count() > 0) {
			btnRevokeAllToken.removeAttr('disabled');
		} else {
			btnRevokeAllToken.attr('disabled', '');
		}
	}

	// Liste Token
	function getListeToken() {
		$.log("> listeToken ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertListeToken);
		// Gestion Mock
		var url = '../endpoint/manager/1/tokenStore/liste';
		if (MOCK) {
			url = '../endpoint/mock/1/tokenStore/liste';
		}
		// Recuperation liste Token
		dataListeToken = $( "#listeToken" ).DataTable({
			"paging": true,
			"info": true,
			"searching": true,
			"ajax": {
				"url": url,
				"async": false,
				"dataSrc": "data",
				"error": function( dataResult, status, response ) {
					// Erreur Recuperation liste Token
					$.errorMessage(panelAlertListeToken, dataResult.responseText);
					// Ecriture Message
					$( "#listeToken .dataTables_empty" ).html(dataResult.responseText);
				}
			},
			"columns": [
				{ "data": "uid" },
				{ "data": "userId" },
				{ "data": "scope" },
				{ "data": "issueTime" },
				{ "data": "expirationTime" },
				{ "data": null },
				// Additionals Hidden Columns
				{ "data": "value" },
				{ "data": "issuer" },
				{ "data": "clientId" },
				{ "data": "scopeRequest" }
			],
			"columnDefs": [
				{
					"targets": [0],
					"orderable" : false,
					"searchable": false,
					"render": function ( data ) {
						return "<canvas class=\"uid-canvas\" id=\"canvas_" + data + "\" width=\"58\" height=\"10\" \">" + data + "</canvas>";
					}
				}, {
					"targets": [3, 4],
					"render": function ( data ) {
						return $.formatDate(data);
					}
				// Action
				}, {
					"targets": [5],
					"orderable" : false,
					"searchable": false,
					"class" : "align-center",
					"defaultContent": 
						"<button class='btn btn-info btn-circle btn-detail-token' type='button'><i class='fa fa-search' aria-hidden='true'></i></button> "
						+ "<button class='btn btn-danger btn-circle btn-remove-token' type='button'><i class='fa fa-trash-o' aria-hidden='true'></i></button>"
				// Additionals Hidden Columns
				}, {
					"targets": [6, 7, 8, 9],
					"visible": false,
					"orderable" : false,
					"searchable": false
				}
			],
			"fnCreatedRow": function(nRow, aData, iDataIndex) {
				$(nRow).attr('id', aData.uid);
			},
			"order": [[4, "asc"]],
			"language": $.configDatatable()
		});
		// Event : draw
		dataListeToken.on('draw.dt', $.formatCanvas);
		// Event : btn-detail-token
		dataListeToken.on('click', '.btn-detail-token', function (e) {
			e.preventDefault();
			this.blur();
			// Clean message
			$.cleanMessage(panelAlertListeToken);
			// Recuperation data
			var data = dataListeToken.row($(this).parents('tr')).data();
			// Mise a jour panel detail token
			panelDetailToken.find("#detail-token-access-value").html(data.value);
			panelDetailToken.find("#detail-token-issuer").html(data.issuer);
			panelDetailToken.find("#detail-token-clientId").html(data.clientId);
			panelDetailToken.find("#detail-token-scope-request").html(data.scopeRequest);
			// Affichage bootbox avec panel detail token
			bootbox.dialog({
				title: "Détail du Jeton",
				message: panelDetailToken.html(),
				buttons: {
					main: {
						label: "Fermer",
						className: "btn-primary"
					}
				}
			}).find("div.modal-dialog").addClass("modal-resized");
		});
		// Event : btn-remove-token
		dataListeToken.on('click', '.btn-remove-token', function (e) {
			e.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeToken);
			// Recuperation dataToken
			var dataToken = dataListeToken.row($(this).parents('tr')).data();
			// Gestion Mock
			var url = '../endpoint/revoke/1/revokeToken';
			if (MOCK) {
				url = '../endpoint/mock/1/revokeToken';
			}
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la suppression du jeton ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								contentType: 'application/json',
								data: JSON.stringify({
									"uid": dataToken.uid
								}),
								success: function( dataResult, status, response ) {
									$.log("> revokeToken - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertListeToken, "La révocation du jeton d'accès s'est correctement déroulée.");
										// Actualisation liste
										dataListeToken.ajax.reload(callbackListeToken);
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur revoke Token
										$.errorMessage(panelAlertListeToken, "Erreur lors de la révocation du jeton d'accès.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertListeToken, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertListeToken, "Erreur lors de la révocation du jeton d'accès.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			});
		});
	}
	// Stats
	function getTokenStoreStats() {
		$.log("> stats TokenStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsTokenStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/tokenStore/stats';
		if (MOCK) {
			url = '../endpoint/mock/1/tokenStore/stats';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Appel methode mutualise writeStats
				$.writeStatsStore(panelTokenStore, panelAlertStatsTokenStore, data["cache-token"]);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsTokenStore, "Erreur récuperation Token Store Status.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}
	// Start
	function startTokenStore() {
		$.log("> start TokenStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsTokenStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/tokenStore/start';
		if (MOCK) {
			url = '../endpoint/mock/1/tokenStore/start';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Actualisation statistiques
				getTokenStoreStats();
				// Affichage Message Succes
				$.successMessage(panelAlertStatsTokenStore, "Le démarrage du store s'est correctement déroulé.");
				// Go To infos
				$.goTo(panelAlertStatsTokenStore);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsTokenStore, "Erreur action sur Token Store.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}
	// Stop
	function stopTokenStore() {
		$.log("> stop TokenStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsTokenStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/tokenStore/stop';
		if (MOCK) {
			url = '../endpoint/mock/1/tokenStore/stop';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Actualisation statistiques
				getTokenStoreStats();
				// Affichage Message Succes
				$.successMessage(panelAlertStatsTokenStore, "L'arrêt du store s'est correctement déroulé.");
				// Go To infos
				$.goTo(panelAlertStatsTokenStore);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsTokenStore, "Erreur action sur Token Store.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build tokenStoreModule");
			// Recuperation liste Token
			getListeToken();
			// Event apres affichage
			callbackListeToken();
			// Masquage Loading
			$.stopLoading();
			// Recuperation Stats TokenStore
			getTokenStoreStats();
			// Mise en place Listener sur Event
			setEventListener();
		}
	};
})();