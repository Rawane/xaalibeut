
// 
// Decryptor
// 
var decryptorModule = (function() {
	// Data
	var panelAlertDecryptor = $( "#panel-alert-decryptor" );
	var formDecryptor = $( "#form-decryptor" );
	var panelAlertEncryptor = $( "#panel-alert-encryptor" );
	var formEncryptor = $( "#form-encryptor" );

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Decryptor Submit
		formDecryptor.delegate(".btn-decryptor-submit", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Submit Form Decryptor
			submitFormDecryptor();
		});
		// Decryptor Reset
		formDecryptor.delegate(".btn-decryptor-reset", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Reset Form Decryptor
			resetFormDecryptor();
		});
		// Encryptor Submit
		formEncryptor.delegate(".btn-encryptor-submit", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Submit Form Encryptor
			submitFormEncryptor();
		});
		// Encryptor Reset
		formEncryptor.delegate(".btn-encryptor-reset", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Reset Form Encryptor
			resetFormEncryptor();
		});
	}
	// Reset Form Decryptor
	function resetFormDecryptor() {
		$.log("> resetFormDecryptor ");
		// Clean message
		$.cleanMessage(panelAlertDecryptor);
		// Clean champs In Error
		formDecryptor.find(".form-check-value").removeClass("has-error");
		// Reset Form
		formDecryptor[0].reset();
	}
	// Control Form Decryptor
	function controlFormDecryptor() {
		$.log("> controlFormDecryptor ");
		var champsInError = false;
		// Clean champs In Error
		formDecryptor.find(".form-check-value").removeClass("has-error");
		// Access Token
		if (formDecryptor.find("#decryptor-access-token").val() == "") {
			formDecryptor.find("#div-decryptor-access-token").addClass("has-error");
			champsInError = true;
		}
		// Retour
		return champsInError;
	}
	// Submit FormDecryptor
	function submitFormDecryptor() {
		$.log("> submitFormDecryptor");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertDecryptor);
		// Reset Form Encryptor
		resetFormEncryptor();
		// Control Form Decryptor
		if (!controlFormDecryptor()) {
			// Appel ajax
			$.ajax({
				type: 'POST',
				url: '../endpoint/manager/1/decryptor',
				dataType: 'json',
				contentType: 'application/json',
				data: JSON.stringify({
					"accessTokenValue": formDecryptor.find("#decryptor-access-token").val()
				}),
				success: function( dataResult, status, response ) {
					$.log("> decryptor ");
					// Remplir champs FormEncryptor
					formEncryptor.find("#encryptor-jwtid").val(dataResult.jwtid);
					formEncryptor.find("#encryptor-idStore").val(dataResult.idStore);
					formEncryptor.find("#encryptor-idStoreDecoded").val(dataResult.idStoreDecoded);
					formEncryptor.find("#encryptor-issuer").val(dataResult.issuer);
					formEncryptor.find("#encryptor-subject").val(dataResult.subject);
					formEncryptor.find("#encryptor-scope").val(dataResult.scope);
					formEncryptor.find("#encryptor-scopeDecoded").val(dataResult.scopeDecoded);
					formEncryptor.find("#encryptor-issueTime").val($.formatDate(dataResult.issueTime));
					formEncryptor.find("#encryptor-expirationTime").val($.formatDate(dataResult.expirationTime));
					// Success Decrypt
					$.successMessage(panelAlertEncryptor, "Le decrypt du jeton d'accès s'est correctement déroulé.");
					// Go to Form Encryptor
					$.goTo("#panel-encryptor");
				},
				error: function( dataResult, status, response ){
					// Error Decrypt
					$.errorMessage(panelAlertDecryptor, "Erreur lors du decrypt du jeton d'accès.");
					// Go to Form Decryptor
					$.goTo("#panel-decryptor");
				},
				complete: function() {
					$.stopLoading();
				}
			});
		} else {
			// Error champs obligatoires
			$.errorMessage(panelAlertDecryptor, "Certains champs obligatoires ne sont pas renseignés.");
			// Go to Form Decryptor
			$.goTo("#panel-decryptor");
			// Masquage Loading
			$.stopLoading();
		}
	}
	// Reset Form Encryptor
	function resetFormEncryptor() {
		$.log("> resetFormEncryptor ");
		// Clean message
		$.cleanMessage(panelAlertEncryptor);
		// Clean champs In Error
		formEncryptor.find(".form-check-value").removeClass("has-error");
		// Reset Form
		formEncryptor[0].reset();
	}
	// Control Form Encryptor
	function controlFormEncryptor() {
		$.log("> controlFormEncryptor ");
		var champsInError = false;
		// Clean champs In Error
		formEncryptor.find(".form-check-value").removeClass("has-error");
		// JWTID
		if (formEncryptor.find("#encryptor-jwtid").val() == "") {
			formEncryptor.find("#div-encryptor-jwtid").addClass("has-error");
			champsInError = true;
		}
		// idStore decoded
		if (formEncryptor.find("#encryptor-idStoreDecoded").val() == "") {
			formEncryptor.find("#div-encryptor-idStoreDecoded").addClass("has-error");
			champsInError = true;
		}
		// issuer
		if (formEncryptor.find("#encryptor-issuer").val() == "") {
			formEncryptor.find("#div-encryptor-issuer").addClass("has-error");
			champsInError = true;
		}
		// subject
		if (formEncryptor.find("#encryptor-subject").val() == "") {
			formEncryptor.find("#div-encryptor-subject").addClass("has-error");
			champsInError = true;
		}
		// scope decoded
		if (formEncryptor.find("#encryptor-scopeDecoded").val() == "") {
			formEncryptor.find("#div-encryptor-scopeDecoded").addClass("has-error");
			champsInError = true;
		}
		// issueTime
		if (formEncryptor.find("#encryptor-issueTime").val() == "") {
			formEncryptor.find("#div-encryptor-issueTime").addClass("has-error");
			champsInError = true;
		}
		// expirationTime
		if (formEncryptor.find("#encryptor-expirationTime").val() == "") {
			formEncryptor.find("#div-encryptor-expirationTime").addClass("has-error");
			champsInError = true;
		}
		// Retour
		return champsInError;
	}
	// Submit FormEncryptor
	function submitFormEncryptor() {
		$.log("> submitFormEncryptor");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertEncryptor);
		// Reset Form Decryptor
		resetFormDecryptor();
		// Control Form Encryptor
		if (!controlFormEncryptor()) {
			// Appel ajax
			$.ajax({
				type: 'POST',
				url: '../endpoint/manager/1/encryptor',
				dataType: 'json',
				contentType: 'application/json',
				data: JSON.stringify({
					"jwtid": formEncryptor.find("#encryptor-jwtid").val(),
					"idStore": formEncryptor.find("#encryptor-idStoreDecoded").val(),
					"issuer": formEncryptor.find("#encryptor-issuer").val(),
					"subject": formEncryptor.find("#encryptor-subject").val(),
					"scope": formEncryptor.find("#encryptor-scopeDecoded").val(),
					"issueTime": formEncryptor.find("#encryptor-issueTime").val(),
					"expirationTime": formEncryptor.find("#encryptor-expirationTime").val()
				}),
				success: function( dataResult, status, response ) {
					$.log("> encryptor ");
					// Reset Encrypt
					resetFormEncryptor();
					// Remplir champs FormDecryptor
					formDecryptor.find("#decryptor-access-token").val(dataResult.accessTokenValue);
					// Success Encrypt
					$.successMessage(panelAlertDecryptor, "L'encrypt du jeton d'accès s'est correctement déroulé.");
					// Go to Form Decryptor
					$.goTo("#panel-decryptor");
				},
				error: function( dataResult, status, response ){
					// Error Encrypt
					$.errorMessage(panelAlertEncryptor, "Erreur lors de l'encrypt du jeton d'accès.");
					// Go to Form Decryptor
					$.goTo("#panel-encryptor");
				},
				complete: function() {
					$.stopLoading();
				}
			});
		} else {
			// Error champs obligatoires
			$.errorMessage(panelAlertEncryptor, "Certains champs obligatoires ne sont pas renseignés.");
			// Go to Form Encryptor
			$.goTo("#panel-encryptor");
			// Masquage Loading
			$.stopLoading();
		}
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build decryptorModule");
			// Affichage Loading
			$.startLoading();
			// Mise en place Listener sur Event
			setEventListener();
			// Masquage Loading
			$.stopLoading();
		}
	};
})();