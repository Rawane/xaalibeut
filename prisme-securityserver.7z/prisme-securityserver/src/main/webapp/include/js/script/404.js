
// 
// Page 404 (not Found)
// 
var notFoundModule = (function() {
	// Data
	var alertPanel = $( "#alert-panel" );
	var btnRetour = $( "#btn-retour" );

	// Fonction privee
	// Init 404
	function init404() {
		// Ajout message 404
		$.errorMessage(alertPanel, "404 Page non trouvée");
	}

	// Fonction publique
	// Build
	return {
		"build" : function(indexUrl) {
			$.log("> build notFoundModule");
			// Affichage Loading
			$.startLoading();
			// Ajout message 404
			init404();
			// Ajout event sur btnRetour
			btnRetour.click(function( event ) {
				// Redirection vers indexUrl
				window.location.href = indexUrl;
			});
			// Masquage Loading
			$.stopLoading();
		}
	};
})();