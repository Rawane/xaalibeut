
// 
// Tools
// 
var toolsModule = (function() {
	// Data
	var panelAlertTools = $( "#panel-alert-tools" );
	var formTools = $( "#form-tools" );
	var panelAlertLoadMetiersNatRef = $( "#panel-alert-loadMetiersNatRef" );
	var formLoadMetiersNatRef = $( "#form-loadMetiersNatRef" );

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Tools Submit
		formTools.delegate(".btn-tools-submit", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Submit Form Tools
			submitFormTools();
		});
		// Tools Reset
		formTools.delegate(".btn-tools-reset", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Reset Form Tools
			resetFormTools();
		});
		// ------------------------
		// LoadMetiersNatRef Submit
		formLoadMetiersNatRef.delegate(".btn-loadMetiersNatRef-submit", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Submit Form LoadMetiersNatRef
			submitFormLoadMetiersNatRef();
		});
		// LoadMetiersNatRef Reset
		formLoadMetiersNatRef.delegate(".btn-loadMetiersNatRef-reset", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Reset Form LoadMetiersNatRef
			resetFormLoadMetiersNatRef();
		});
	}
	// ------------------------
	// Form Tools
	// Reset Form Tools
	function resetFormTools() {
		$.log("> resetFormTools ");
		// Clean message
		$.cleanMessage(panelAlertTools);
		// Clean champs In Error
		formTools.find(".form-check-value").removeClass("has-error");
		// Reset Form
		formTools[0].reset();
	}
	// Control Form Tools
	function controlFormTools() {
		$.log("> controlFormTools ");
		var champsInError = false;
		// Clean champs In Error
		formTools.find(".form-check-value").removeClass("has-error");
		// subject
		if (formTools.find("#subject").val() == "") {
			formTools.find("#div-subject").addClass("has-error");
			champsInError = true;
		}
		// Retour
		return champsInError;
	}
	// Submit Form Tools
	function submitFormTools() {
		$.log("> submitFormTools");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertTools);
		// Reset Resultat
		formTools.find("#resultat").val("");
		// Control Form Tools
		if (!controlFormTools()) {
			// Appel ajax
			$.ajax({
				type: 'POST',
				url: '../endpoint/manager/1/calculListeDroits',
				dataType: 'json',
				contentType: 'application/json',
				data: JSON.stringify({
					"subject": formTools.find("#subject").val(),
					"scope": formTools.find("#scope").val()
				}),
				success: function( dataResult, status, response ) {
					$.log("> calculListeDroits ");
					// Remplir champ Resultat
					formTools.find("#resultat").val(dataResult.resultat);
					// Success Decrypt
					$.successMessage(panelAlertTools, "Le calcul des droits s'est correctement déroulé.");
					// Go to Form Tools
					$.goTo("#panel-calculDroitsAnais");
				},
				error: function( dataResult, status, response ) {
					// Error Tools
					$.errorMessage(panelAlertTools, dataResult.responseText);
					// Go to Form Tools
					$.goTo("#panel-calculDroitsAnais");
				},
				complete: function() {
					$.stopLoading();
				}
			});
		} else {
			// Error champs obligatoires
			$.errorMessage(panelAlertTools, "Certains champs obligatoires ne sont pas renseignés.");
			// Go to Form Tools
			$.goTo("#panel-calculDroitsAnais");
			// Masquage Loading
			$.stopLoading();
		}
	}
	// -----------------------
	// Form LoadMetiersNatRef
	// Reset Form LoadMetiersNatRef
	function resetFormLoadMetiersNatRef() {
		$.log("> resetFormLoadMetiersNatRef ");
		// Clean message
		$.cleanMessage(panelAlertLoadMetiersNatRef);
		// Clean champs In Error
		formLoadMetiersNatRef.find(".form-check-value").removeClass("has-error");
		// Reset Form
		formLoadMetiersNatRef[0].reset();
	}
	// Control Form LoadMetiersNatRef
	function controlFormLoadMetiersNatRef() {
		$.log("> controlFormLoadMetiersNatRef ");
		var champsInError = false;
		// Clean champs In Error
		formLoadMetiersNatRef.find(".form-check-value").removeClass("has-error");
		// codeApp
		if (formLoadMetiersNatRef.find("#codeApp").val() == "") {
			formLoadMetiersNatRef.find("#div-codeApp").addClass("has-error");
			champsInError = true;
		}
		// metiersNatRef
		if (formLoadMetiersNatRef.find("#metiersNatRef").val() == "") {
			formLoadMetiersNatRef.find("#div-metiersNatRef").addClass("has-error");
			champsInError = true;
		}
		// Retour
		return champsInError;
	}
	// Submit Form LoadMetiersNatRef
	function submitFormLoadMetiersNatRef() {
		$.log("> submitFormLoadMetiersNatRef");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertLoadMetiersNatRef);
		// Control Form LoadMetiersNatRef
		if (!controlFormLoadMetiersNatRef()) {
			// Construction Params avec callback
			var createParamsBeforeAjax = function(callbackAjax) {
				// Params
				var dataParams = {
					codeApp:formLoadMetiersNatRef.find("#codeApp").val(),
					codeOrg:formLoadMetiersNatRef.find("#codeOrg").val()
				};
				// Chargement fichier
				if (!$.isFileReaderAvailable()) {
					// Recuperation contenu textarea
					dataParams["metiersNatRef"] = formLoadMetiersNatRef.find("#metiersNatRef").val();
					callbackAjax.call(this, dataParams);
				} else {
					// Recuperation par FileReader
					$.readContentFileUpload("metiersNatRef", function(e) {
						if (e != undefined && e.target != undefined) {
							dataParams["metiersNatRef"] = e.target.result;
						}
						callbackAjax.call(this, dataParams);
					});
				}
			};
			// Appel avec callback
			createParamsBeforeAjax.call(this, function(dataParams) {
				// Appel ajax
				$.ajax({
					type: 'POST',
					url: '../endpoint/manager/1/loadMetiersNatRef',
					dataType: 'json',
					contentType: 'application/json',
					data: JSON.stringify(dataParams),
					success: function( dataResult, status, response ) {
						$.log("> loadMetiersNatRef ");
						// Success loadMetiersNatRef
						$.successMessage(panelAlertLoadMetiersNatRef, "Le chargement du fichier MetiersNatRef s'est correctement déroulé.");
						// Go to Form LoadMetiersNatRef
						$.goTo("#panel-loadMetiersNatRef");
					},
					error: function( dataResult, status, response ) {
						// Error Tools
						$.errorMessage(panelAlertLoadMetiersNatRef, dataResult.responseText);
						// Go to Form LoadMetiersNatRef
						$.goTo("#panel-loadMetiersNatRef");
					},
					complete: function() {
						$.stopLoading();
					}
				});
			});
		} else {
			// Error champs obligatoires
			$.errorMessage(panelAlertLoadMetiersNatRef, "Certains champs obligatoires ne sont pas renseignés.");
			// Go to Form LoadMetiersNatRef
			$.goTo("#panel-loadMetiersNatRef");
			// Masquage Loading
			$.stopLoading();
		}
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build toolsModule");
			// Affichage Loading
			$.startLoading();
			// Mise en place Listener sur Event
			setEventListener();
			// Masquage Loading
			$.stopLoading();
		}
	};
})();