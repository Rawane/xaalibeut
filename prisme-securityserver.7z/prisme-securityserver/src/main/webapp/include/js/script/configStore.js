
// 
// ConfigStore
// 
var configStoreModule = (function() {
	// Data
	var panelConfigStore = $( "#panel-config-store" );
	var panelAlertStatsConfigStore = $( "#panel-alert-stats-config-store" );
	var panelAlertListeConfig = $( "#panel-alert-liste-config" );
	var panelDetailConfig = $( "#panel-detail-config" );
	var dataListeConfig = null;
	var btnRevokeAllConfig = $( ".btn-revoke-all-config" );

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Event bouton btn-refresh-config-store
		panelConfigStore.delegate(".btn-refresh-config-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeConfig);
			// Actualisation liste
			dataListeConfig.ajax.reload(callbackListeConfig);
			// Masquage Loading
			$.stopLoading();
			// Recuperation Stats ConfigStore
			getConfigStoreStats();
		});
		// Event bouton Revoke All
		panelConfigStore.delegate(".btn-revoke-all-config", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeConfig);
			// Gestion Mock
			var url = '../endpoint/revoke/1/revokeAllConfig';
			if (MOCK) {
				url = '../endpoint/mock/1/revokeAllConfig';
			}
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la suppression de toutes les configurations ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel Ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								success: function( dataResult, status, response ) {
									$.log("> revokeAllConfig - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertListeConfig, "La révocation de toutes les configurations s'est correctement déroulée.");
										// Actualisation liste
										dataListeConfig.ajax.reload(callbackListeConfig);
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur revoke Token
										$.errorMessage(panelAlertListeConfig, "Erreur lors de la révocation de toutes les configurations.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertListeConfig, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertListeConfig, "Erreur lors de la révocation de toutes les configurations.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			});
		});
		// Event bouton btn-refresh-stats-config-store
		panelConfigStore.delegate(".btn-refresh-stats-config-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Recuperation Stats ConfigStore
			getConfigStoreStats();
		});
		// Event bouton btn-start-token-store
		panelConfigStore.delegate(".btn-start-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Start Config Store
			startConfigStore();
		});
		// Event bouton btn-stop-token-store
		panelConfigStore.delegate(".btn-stop-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Stop Config Store
			stopConfigStore();
		});
	}

	// Callback Liste Config
	function callbackListeConfig() {
		$.log("> callbackListeConfig ");
		// Traitement nodeId en canvas
		$.formatCanvas();
		// Gestion bouton Revoke All
		if (dataListeConfig.data().count() > 0) {
			btnRevokeAllConfig.removeAttr('disabled');
		} else {
			btnRevokeAllConfig.attr('disabled', '');
		}
	}

	// Liste Config
	function getListeConfig() {
		$.log("> listeConfig ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertListeConfig);
		// Gestion Mock
		var url = '../endpoint/manager/1/configStore/liste';
		if (MOCK) {
			url = '../endpoint/mock/1/configStore/liste';
		}
		// Recuperation liste Config
		dataListeConfig =  $( "#listeConfig" ).DataTable({
			"paging": true,
			"info": true,
			"searching": true,
			"ajax": {
				"url": url,
				"async": false,
				"dataSrc": "data",
				"error": function( dataResult, status, response ) {
					// Erreur Recuperation liste Config
					$.errorMessage(panelAlertListeConfig, dataResult.responseText);
					// Ecriture Message
					$( "#listeConfig .dataTables_empty" ).html(dataResult.responseText);
				}
			},
			"columns": [
				{ "data": "nodeId" },
				{ "data": "version" },
				{ "data": "clientId" },
				{ "data": "authenticator" },
				{ "data": "authorizer" },
				{ "data": "providerPermissionsLoader" },
				{ "data": "registryDate" },
				{ "data": null },
				// Additionals Hidden Columns
				{ "data": "clientIdFull" },
				{ "data": "endpoint" },
				{ "data": "pssNodeId" },
				{ "data": "httpClient" },
				{ "data": "tokenStore" },
				{ "data": "identityStore" },
				{ "data": "permissionsStore" },
				{ "data": "jmxActivated" },
				{ "data": "securityOptions" },
				{ "data": "providerPermissionsFile" },
				{ "data": "permissionsCacheMaxEntries" },
				{ "data": "permissionsValidityInS" },
				{ "data": "identityCacheMaxEntries" },
				{ "data": "identityValidityInS" },
				{ "data": "tokenCacheMaxEntries" },
				{ "data": "tokenValidityInS" }
			],
			"columnDefs": [
				{
					"targets": [0],
					"orderable" : false,
					"searchable": false,
					"render": function ( data ) {
						return "<canvas class=\"uid-canvas\" id=\"canvas_" + data + "\" width=\"58\" height=\"10\" \">" + data + "</canvas>";
					}
				}, {
					"targets": [1],
					"type" : 'numeric-version'
				}, {
					"targets": [6],
					"render": function ( data ) {
						return $.formatDate(data);
					}
				// Action
				}, {
					"targets": [7],
					"orderable" : false,
					"searchable": false,
					"class" : "align-center",
					"defaultContent": 
						"<button class='btn btn-info btn-circle btn-detail-config' type='button'><i class='fa fa-search' aria-hidden='true'></i></button> "
						+ "<button class='btn btn-danger btn-circle btn-remove-config' type='button'><i class='fa fa-trash-o' aria-hidden='true'></i></button>"
				// Additionals Hidden Columns
				}, {
					"targets": [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
					"visible": false,
					"orderable" : false,
					"searchable": false
				}
			],
			"fnCreatedRow": function(nRow, aData, iDataIndex) {
				$(nRow).attr('id', aData.nodeId);
			},
			"order": [[6, "desc"]],
			"language": $.configDatatable()
		});
		// Event : draw
		dataListeConfig.on('draw.dt', $.formatCanvas);
		// Event : btn-detail-config
		dataListeConfig.on('click', '.btn-detail-config', function (e) {
			e.preventDefault();
			this.blur();
			// Clean message
			$.cleanMessage(panelAlertListeConfig);
			// Recuperation data
			var data = dataListeConfig.row($(this).parents('tr')).data();
			// Mise a jour panel detail config
			panelDetailConfig.find("#detail-config-clientId").html(data.clientIdFull);
			panelDetailConfig.find("#detail-config-urlPSS").html(data.endpoint);
			panelDetailConfig.find("#detail-config-pssNodeId").html(data.pssNodeId);
			panelDetailConfig.find("#detail-config-httpClient").html(data.httpClient);
			panelDetailConfig.find("#detail-config-providerPermissionsFile").html(data.providerPermissionsFile);
			panelDetailConfig.find("#detail-config-tokenStore").html(data.tokenStore);
			panelDetailConfig.find("#detail-config-tokenCacheMaxEntries").html(data.tokenCacheMaxEntries);
			panelDetailConfig.find("#detail-config-tokenValidityInS").html(data.tokenValidityInS);
			panelDetailConfig.find("#detail-config-identityStore").html(data.identityStore);
			panelDetailConfig.find("#detail-config-identityCacheMaxEntries").html(data.identityCacheMaxEntries);
			panelDetailConfig.find("#detail-config-identityValidityInS").html(data.identityValidityInS);
			panelDetailConfig.find("#detail-config-permissionsStore").html(data.permissionsStore);
			panelDetailConfig.find("#detail-config-permissionsCacheMaxEntries").html(data.permissionsCacheMaxEntries);
			panelDetailConfig.find("#detail-config-permissionsValidityInS").html(data.permissionsValidityInS);
			panelDetailConfig.find("#detail-config-jmxActivated").html(data.jmxActivated);
			panelDetailConfig.find("#detail-config-securityOptions").html(data.securityOptions);
			// Affichage bootbox avec panel detail token
			bootbox.dialog({
				title: "Détail de la Configuration",
				message: panelDetailConfig.html(),
				buttons: {
					main: {
						label: "Fermer",
						className: "btn-primary"
					}
				}
			}).find("div.modal-dialog").addClass("modal-resized");
		});
		// Event : btn-remove-config
		dataListeConfig.on('click', '.btn-remove-config', function (e) {
			e.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeConfig);
			// Recuperation dataConfig
			var dataConfig = dataListeConfig.row($(this).parents('tr')).data();
			// Gestion Mock
			var url = '../endpoint/revoke/1/revokeConfig';
			if (MOCK) {
				url = '../endpoint/mock/1/revokeConfig';
			}
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la suppression de la configuration ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								contentType: 'application/json',
								data: JSON.stringify({
									"nodeId": dataConfig.nodeId
								}),
								success: function( dataResult, status, response ) {
									$.log("> revokeConfig - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertListeConfig, "La révocation de la configuration s'est correctement déroulée.");
										// Actualisation liste
										dataListeConfig.ajax.reload(callbackListeConfig);
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur revoke Config
										$.errorMessage(panelAlertListeConfig, "Erreur lors de la révocation de la configuration.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertListeConfig, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertListeConfig, "Erreur lors de la révocation de la configuration.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			});
		});
	}

	// Stats
	function getConfigStoreStats() {
		$.log("> stats ConfigStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsConfigStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/configStore/stats';
		if (MOCK) {
			url = '../endpoint/mock/1/configStore/stats';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Appel methode mutualise writeStats
				$.writeStatsStore(panelConfigStore, panelAlertStatsConfigStore, data["cache-registry"]);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsConfigStore, "Erreur récuperation Config Store Status.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}
	// Start
	function startConfigStore() {
		$.log("> start ConfigStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsConfigStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/configStore/start';
		if (MOCK) {
			url = '../endpoint/mock/1/configStore/start';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Actualisation statistiques
				getConfigStoreStats();
				// Affichage Message Succes
				$.successMessage(panelAlertStatsConfigStore, "Le démarrage du store s'est correctement déroulé.");
				// Go To infos
				$.goTo(panelAlertStatsConfigStore);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsConfigStore, "Erreur action sur Config Store.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}
	// Stop
	function stopConfigStore() {
		$.log("> stop ConfigStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsConfigStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/configStore/stop';
		if (MOCK) {
			url = '../endpoint/mock/1/configStore/stop';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Actualisation statistiques
				getConfigStoreStats();
				// Affichage Message Succes
				$.successMessage(panelAlertStatsConfigStore, "L'arrêt du store s'est correctement déroulé.");
				// Go To infos
				$.goTo(panelAlertStatsConfigStore);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsConfigStore, "Erreur action sur Config Store.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build configStoreModule");
			// Recuperation liste Config
			getListeConfig();
			// Event apres affichage
			callbackListeConfig();
			// Masquage Loading
			$.stopLoading();
			// Recuperation Stats ConfigStore
			getConfigStoreStats();
			// Mise en place Listener sur Event
			setEventListener();
		}
	};
})();