
// 
// idTokenStore
// 
var idTokenStoreModule = (function() {
	// Data
	var panelIDTokenStore = $( "#panel-idToken-store" );
	var panelAlertStatsIDTokenStore = $( "#panel-alert-stats-idToken-store" );
	var panelAlertListeIDToken = $( "#panel-alert-liste-idToken" );
//	var panelDetailIDToken = $( "#panel-detail-idToken" );
	var dataListeIDToken = null;
	var btnRevokeAllIDToken = $( ".btn-revoke-all-idToken" );

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Event bouton btn-refresh-idToken-store
		panelIDTokenStore.delegate(".btn-refresh-idToken-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeIDToken);
			// Actualisation liste
			dataListeIDToken.ajax.reload(callbackListeIDToken);
			// Masquage Loading
			$.stopLoading();
			// Recuperation Stats IDToken
			getIDTokenStoreStats();
		});
		// Event bouton Revoke All
		panelIDTokenStore.delegate(".btn-revoke-all-idToken", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeIDToken);
			// Gestion Mock
			var url = '../endpoint/revoke/1/revokeAllIDToken';
			if (MOCK) {
				url = '../endpoint/mock/1/revokeAllIDToken';
			}
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la suppression de tous les ID Token ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel Ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								success: function( dataResult, status, response ) {
									$.log("> revokeAllIDToken - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertListeIDToken, "La révocation de tous les ID Token s'est correctement déroulée.");
										// Actualisation liste
										dataListeIDToken.ajax.reload(callbackListeIDToken);
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur revoke Token
										$.errorMessage(panelAlertListeIDToken, "Erreur lors de la révocation de tous les ID Token.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertListeIDToken, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertListeIDToken, "Erreur lors de la révocation de tous les ID Token.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			});
		});
		// Event bouton btn-refresh-stats-idToken-store
		panelIDTokenStore.delegate(".btn-refresh-stats-idToken-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Recuperation Stats IDTokenStore
			getIDTokenStoreStats();
		});
		// Event bouton btn-start-idToken-store
		panelIDTokenStore.delegate(".btn-start-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Start IDToken Store
			startIDTokenStore();
		});
		// Event bouton btn-stop-idToken-store
		panelIDTokenStore.delegate(".btn-stop-store", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Stop IDToken Store
			stopIDTokenStore();
		});
	}

	// Callback Liste IDToken
	function callbackListeIDToken() {
		$.log("> callbackListeIDToken ");
		// Gestion bouton Revoke All
		if (dataListeIDToken.data().count() > 0) {
			btnRevokeAllIDToken.removeAttr('disabled');
		} else {
			btnRevokeAllIDToken.attr('disabled', '');
		}
	}

	// Liste IDToken
	function getListeIDToken() {
		$.log("> listeIDToken ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertListeIDToken);
		// Gestion Mock
		var url = '../endpoint/manager/1/idTokenStore/liste';
		if (MOCK) {
			url = '../endpoint/mock/1/idTokenStore/liste';
		}
		// Recuperation liste IDToken
		dataListeIDToken =  $( "#listeIDToken" ).DataTable({
			"paging": true,
			"info": true,
			"searching": true,
			"ajax": {
				"url": url,
				"async": false,
				"dataSrc": "data",
				"error": function( dataResult, status, response ) {
					// Erreur Recuperation liste IDToken
					$.errorMessage(panelAlertListeIDToken, dataResult.responseText);
					// Ecriture Message
					$( "#listeIDToken .dataTables_empty" ).html(dataResult.responseText);
				}
			},
			"columns": [
				{ "data": "state" },
				{ "data": "audience" },
				{ "data": "subject" },
				{ "data": "name" },
				{ "data": "email" },
				{ "data": "issueTime" },
				{ "data": "expirationTime" },
				{ "data": null }
				// TODO
			],
			"columnDefs": [
				{
					"targets": [5, 6],
					"render": function ( data ) {
						return $.formatDate(data);
					}
				// Action
				}, {
					"targets": [7],
					"orderable" : false,
					"searchable": false,
					"class" : "align-center",
					"defaultContent": 
						"<button class='btn btn-danger btn-circle btn-remove-idToken' type='button'><i class='fa fa-trash-o' aria-hidden='true'></i></button>"
				}
			],
			"fnCreatedRow": function(nRow, aData, iDataIndex) {
				$(nRow).attr('id', aData.state);
			},
			"order": [[5, "desc"]],
			"language": $.configDatatable()
		});
		// Event : btn-remove-idToken
		dataListeIDToken.on('click', '.btn-remove-idToken', function (e) {
			e.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeIDToken);
			// Recuperation dataIDToken
			var dataIDToken = dataListeIDToken.row($(this).parents('tr')).data();
			// Gestion Mock
			var url = '../endpoint/revoke/1/revokeIDToken';
			if (MOCK) {
				url = '../endpoint/mock/1/revokeIDToken';
			}
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la suppression du ID Token ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								contentType: 'application/json',
								data: JSON.stringify({
									"state": dataIDToken.state
								}),
								success: function( dataResult, status, response ) {
									$.log("> revokeIDToken - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertListeIDToken, "La révocation du ID Token s'est correctement déroulée.");
										// Actualisation liste
										dataListeIDToken.ajax.reload(callbackListeIDToken);
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur revoke ID Token
										$.errorMessage(panelAlertListeIDToken, "Erreur lors de la révocation du ID Token.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertListeIDToken, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertListeIDToken, "Erreur lors de la révocation du ID Token.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			});
		});
	}

	// Stats
	function getIDTokenStoreStats() {
		$.log("> stats IDTokenStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsIDTokenStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/idTokenStore/stats';
		if (MOCK) {
			url = '../endpoint/mock/1/idTokenStore/stats';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Appel methode mutualise writeStats
				$.writeStatsStore(panelIDTokenStore, panelAlertStatsIDTokenStore, data["cache-idtoken"]);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsIDTokenStore, "Erreur récuperation IDToken Store Status.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}
	// Start
	function startIDTokenStore() {
		$.log("> start IDTokenStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsIDTokenStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/idTokenStore/start';
		if (MOCK) {
			url = '../endpoint/mock/1/idTokenStore/start';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Actualisation statistiques
				getIDTokenStoreStats();
				// Affichage Message Succes
				$.successMessage(panelAlertStatsIDTokenStore, "Le démarrage du store s'est correctement déroulé.");
				// Go To infos
				$.goTo(panelAlertStatsIDTokenStore);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsIDTokenStore, "Erreur action sur IDToken Store.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}
	// Stop
	function stopIDTokenStore() {
		$.log("> stop IDTokenStore ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertStatsIDTokenStore);
		// Gestion Mock
		var url = '../endpoint/manager/1/idTokenStore/stop';
		if (MOCK) {
			url = '../endpoint/mock/1/idTokenStore/stop';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Actualisation statistiques
				getIDTokenStoreStats();
				// Affichage Message Succes
				$.successMessage(panelAlertStatsIDTokenStore, "L'arrêt du store s'est correctement déroulé.");
				// Go To infos
				$.goTo(panelAlertStatsIDTokenStore);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertStatsIDTokenStore, "Erreur action sur IDToken Store.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build idTokenStoreModule");
			// Recuperation liste IDToken
			getListeIDToken();
			// Event apres affichage
			callbackListeIDToken();
			// Masquage Loading
			$.stopLoading();
			// Recuperation Stats IDTokenStore
			getIDTokenStoreStats();
			// Mise en place Listener sur Event
			setEventListener();
		}
	};
})();