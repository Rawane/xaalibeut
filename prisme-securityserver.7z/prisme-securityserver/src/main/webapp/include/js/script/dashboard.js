
// 
// Dashboard
// 
var dashboardModule = (function() {
	// Data
	var divIndicator = $( "#div-indicator" );
	var divValidator = $( "#div-validator" );
	var panelAlertIndicator = $( "#panel-alert-indicator" );
	var panelAlertValidator = $( "#panel-alert-validator" );
	var panelDetailValidator = $( "#panel-detail-validator" );
	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Ajout event sur refreshIndicator
		divIndicator.delegate(".refresh-indicator", "click", function( event ) {
			event.preventDefault();
			// Refresh Indicator
			refreshIndicator((this).id.replace("link-indicator-", ""));
		});
		// Ajout event sur detailValidator
		divValidator.delegate(".detail-validator", "click", function( event ) {
			event.preventDefault();
			// Detail Validator
			detailValidator((this).id.replace("detail-validator-", ""));
		});
		// Ajout event sur refreshValidator
		divValidator.delegate(".refresh-validator", "click", function( event ) {
			event.preventDefault();
			// Refresh Validator
			refreshValidator((this).id.replace("link-validator-", ""));
		});
	}

	//
	// Indicator
	//

	// WriteIndicator
	function writeIndicator(id, value) {
		$("#spin-indicator-" + id).toggleClass("hide");
		$("#icon-indicator-" + id).toggleClass("hide");
		$("#nb-indicator-" + id).html(value);
		$("#link-indicator-" + id).toggleClass("disabled");
	}
	// Get All Indicator
	function getAllIndicator() {
		$.log("> getAllIndicator ");
		// Clean message
		$.cleanMessage(panelAlertIndicator);
		// Gestion Mock
		var url = '../endpoint/manager/1/dashboard/indicateur/all';
		if (MOCK) {
			url = '../endpoint/mock/1/dashboard/indicateur/all';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// NbApplications
				writeIndicator("application", data.nbApplications);
				// NbTokens
				writeIndicator("token", data.nbTokens);
				// NbConfigs
				writeIndicator("config", data.nbConfigs);
				// NbCaches
				writeIndicator("cache", data.nbCaches);
			},
			error: function( data, status, response ) {
				$.errorMessage(panelAlertIndicator, "Erreur lors de la récuperation du dashboard.");
				// Reset Indicator
				writeIndicator("application", "0");
				writeIndicator("token", "0");
				writeIndicator("config", "0");
				writeIndicator("cache", "0");
			}
		});
	}
	// Refresh indicator
	function refreshIndicator(nom) {
		$.log("> refreshIndicator, nom:" + nom);
		// Clean message
		$.cleanMessage(panelAlertIndicator);
		// Gestion Mock
		var url = '../endpoint/manager/1/dashboard/indicateur/refresh/' + nom;
		if (MOCK) {
			url = '../endpoint/mock/1/dashboard/indicateur/refresh/' + nom;
		}
		// Masquage champs
		writeIndicator(nom, "...");
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Refresh Panel
				writeIndicator(nom, data["nb" + nom.substring(0,1).toUpperCase() + nom.substring(1) + "s"]);
			},
			error: function( data, status, response ) {
				$.errorMessage(panelAlertIndicator, "Erreur lors de la récuperation du dashboard.");
				// Reset Indicator
				writeIndicator(nom, "0");
			}
		});
	}

	//
	// Validator
	//

	// WriteValidator
	function writeValidator(id, value, host, result) {
		// Masquage loader
		$("#spin-validator-" + id).toggleClass("hide");
		// Icon + Status
		$("#icon-validator-" + id).toggleClass("hide");
		if (value == "true") {
			$("#icon-validator-" + id).html("<button type=\"button\" class=\"btn btn-success btn-circle-5x btn-no-pointer\"><i class=\"fa fa-check fa-4x\"> </i></button>");
			$("#status-validator-" + id).html("OK");
		} else if (value == "false") {
			$("#icon-validator-" + id).html("<button type=\"button\" class=\"btn btn-danger btn-circle-5x btn-no-pointer\"><i class=\"fa fa-times fa-4x\"> </i></button>");
			$("#status-validator-" + id).html("KO");
		} else {
			$("#status-validator-" + id).html(value);
		}
		// Detail
		$("#detail-validator-" + id).toggleClass("disabled");
		// Host
		$("#host-validator-" + id).html("");
		if (host) {
			$("#host-validator-" + id).html(host);
		}
		// Result
		$("#result-validator-" + id).html("");
		if (result) {
			$("#result-validator-" + id).html(result);
		}
		// Refresh
		$("#link-validator-" + id).toggleClass("disabled");
	}
	// Get All Validator
	function getAllValidator() {
		$.log("> getAllValidator ");
		// Gestion Mock
		var url = '../endpoint/manager/1/dashboard/validateur/all';
		if (MOCK) {
			url = '../endpoint/mock/1/dashboard/validateur/all';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Anais
				writeValidator("anais", data.anaisStatus, data.anaisHost, data.anaisResult);
				// InterOps
				writeValidator("interOps", data.interOpsStatus, data.interOpsHost, data.interOpsResult);
				// Ocean
				writeValidator("ocean", data.oceanStatus, data.oceanHost, data.oceanResult);
			},
			error: function( data, status, response ) {
				$.errorMessage(panelAlertValidator, "Erreur lors de la récuperation du dashboard.");
				// Reset Validator
				writeValidator("anais", "false");
				writeValidator("interOps", "false");
				writeValidator("ocean", "false");
			}
		});
	}
	// Refresh Validator
	function refreshValidator(nom) {
		$.log("> refreshValidator, nom:" + nom);
		// Clean message
		$.cleanMessage(panelAlertValidator);
		// Gestion Mock
		var url = '../endpoint/manager/1/dashboard/validateur/refresh/' + nom;
		if (MOCK) {
			url = '../endpoint/mock/1/dashboard/validateur/refresh/' + nom;
		}
		// Masquage champs
		writeValidator(nom, "...");
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Refresh Panel
				writeValidator(nom, data[nom + "Status"], data[nom + "Host"], data[nom + "Result"]);
			},
			error: function( data, status, response ) {
				$.errorMessage(panelAlertValidator, "Erreur lors de la récuperation du dashboard.");
				// Reset Validator
				writeValidator(nom, "false");
			}
		});
	}
	// Detail Validator
	function detailValidator(nom) {
		$.log("> detailValidator, nom:" + nom);
		// Detail Validator
		panelDetailValidator.find("#detail-validator-host").html($("#host-validator-" + nom).html());
		panelDetailValidator.find("#detail-validator-result").html($("#result-validator-" + nom).html());
		// Affichage bootbox avec panel detail token
		bootbox.dialog({
			title: "Détail",
			message: panelDetailValidator.html(),
			buttons: {
				main: {
					label: "Fermer",
					className: "btn-primary"
				}
			}
		}).find("div.modal-dialog").addClass("modal-resized");
	}
	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build dashboardModule");
			// Affichage Loading
			$.startLoading();
			// Masquage Loading
			$.stopLoading();
			// Chargement all indicator
			getAllIndicator();
			// Chargement all validator
			getAllValidator();
			// Mise en place Listener sur Event
			setEventListener();
		}
	};
})();