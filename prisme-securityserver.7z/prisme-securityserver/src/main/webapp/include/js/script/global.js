
// 
// Global
// 
var globalModule = (function() {
	// Data
	var nom = $( "#nom" );
	var identifiant = $( "#identifiant" );
	var role = $( "#role" );
	var sideMenu = $( "#side-menu" );
	var buildVersion = $( "#buildVersion" );

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener (context) ");
		// Ajout event sur menu
		sideMenu.delegate("a", "click", function( event ) {
			// Affichage Loading
			$.startLoading();
		});
	}
	// Event Listener Loader
	function setEventListenerLoader() {
		$.log("> setEventListenerLoader ");
		// Ajout event sur close-loading
		$( "#div-close-loading" ).delegate("a", "click", function( event ) {
			event.preventDefault();
			// Close Loading
			$.closeLoading();
		});
	}
	// CreateContextPage
	function createContextPage(title) {
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: '../endpoint/session/1/context',
			dataType: 'json',
			async: false,
			success: function( data, status, response ) {
				$.log("> context ");
				// Recuperation informations
				nom.html(data.nom);
				identifiant.html(data.identifiant);
				role.html(data.role);
				// Versions
				if (data.versionPrisme != 'indéfini' && data.versionPSS != 'indéfini' && buildVersion != null) {
					buildVersion.html("- build " + data.versionPSS + " (PRISME " + data.versionPrisme + ")");
				}
				// Creation menu
				createMenu(title, data);
			},
			error: function( data, status, response ){
				$.alert("Erreur récuperation context");
			}
		});
	}
	// CreateMenu
	function createMenu(title, data) {
		// Parcours data.listeMenu
		for (var i in data.listeMenu) {
			// Recuperation element courant
			var itemMenu = data.listeMenu[i];
			// Gestion classActive
			var classActive = "";
			if (title == itemMenu.menuTitle) {
				classActive = " class=\"active\"";
			}
			// Ajout dans sideMenu
			sideMenu.append(
				"<li" + classActive + ">"
					+ "<a" + classActive + " href=\"" + itemMenu.menuHref + "\">"
						+ "<i class=\"" + itemMenu.menuClass + "\"></i> " + itemMenu.menuTitle
					+ "</a>"
				+ "</li>"
			);
		}
	}

	// Fonction publique
	// Build
	return {
		// Traitement minimal
		"min" : function() {
			// Affichage Loading
			$.startLoading();
			// Event Loader
			setEventListenerLoader();
			// Masquage Loading
			$.stopLoading();
		},
		"build" : function(title) {
			// Affichage Loading
			$.startLoading();
			// Recuperation parametres
			if (title == undefined) {
				title = INDEFINI;
			}
			$.log("> build globalModule [ title:" + title + " ]");
			// Update title
			if (title != INDEFINI) {
				document.title = 'PSS - ' + title;
			}
			// Recuperation Context
			createContextPage(title);
			// Event menu
			setEventListener();
			// Event Loader
			setEventListenerLoader();
			// Tooltip
			$.tooltip();
			// Popover
			$.popover();
			// Masquage Loading
			$.stopLoading();
		}
	};
})();