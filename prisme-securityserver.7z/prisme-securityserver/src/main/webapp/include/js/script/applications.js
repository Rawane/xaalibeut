
// 
// Applications
// 
var applicationModule = (function() {
	// Data
	var pListeApplications = $( "#p-liste-applications" );
	var panelAlertApplication = $( "#panel-alert-application" );
	var panelDetailApplication = $( "#panel-detail-application" );
	var panelAlertDetailApplication = $( "#panel-alert-detail-application" );
	var btnGetPublicKey = $( ".btn-get-public-key" );
	var currentId = "";
	// GeneratorConfig
	var formGeneratorConfig = $( "#form-generator-config" );
	var panelAlertGeneratorConfig = $( "#panel-alert-generator-config" );
	// CreateAccessToken
	var formCreateAccessToken = $( "#form-create-access-token" );
	var panelAlertCreateAccessToken = $( "#panel-alert-create-access-token" );

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Ajout event sur btnApplication
		pListeApplications.delegate(".btn-application", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Ajout classe outline sur tous boutons
			$('.btn-application').addClass("btn-outline");
			// Suppression classe outline sur bouton courant
			$(this).removeClass("btn-outline");
			// Sauvegarde currentId
			currentId = event.target.id;
			// Appel Detail Application
			getDetailApplication();
		});
		// Ajout event sur btnGenerateKey
		panelDetailApplication.delegate(".btn-generate-key", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Affichage bootbox confirm
			bootbox.dialog({
				title: "Demande de confirmation",
				message: "Confirmez-vous la génération des clés pour l'application ?",
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
						callback: function() {
							// Masquage Loading
							$.stopLoading();
						}
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Appel Generate Key
							generateKey();
							// Masquage Loading
							$.stopLoading();
						}
					}
				}
			});
		});
		// Ajout event sur btnGetPublicKey
		panelDetailApplication.delegate(".btn-get-public-key", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Get Public Key
			getPublicKey();
		});
		// Change Cinematique
		formCreateAccessToken.delegate("#cinematique", "change", function( event ) {
			event.preventDefault();
			// Appel Change Cinematique
			changeCinematique(this.value);
		});
		// Soumettre Form (AccessToken ou Requete Demande)
		formCreateAccessToken.delegate(".btn-submit-form-access-token", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Submit Form CreateAccessToken
			submitFormCreateAccessToken(this.value);
		});
		// Change Mode
		formGeneratorConfig.delegate("#config-mode", "change", function( event ) {
			event.preventDefault();
			// Appel Change Mode
			changeMode(this.value);
		});
		// Soumette Form Generator Config
		formGeneratorConfig.delegate(".btn-submit-form-generator-config", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Appel Submit Form GeneratorConfig
			submitFormGeneratorConfig();
		});
	}
	// Liste Applications
	function getListeApplications() {
		$.log("> listeApplication ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertApplication);
		$.cleanMessage(panelAlertDetailApplication);
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: '../endpoint/manager/1/application/liste',
			dataType: 'json',
			success: function( data, status, response ) {
				pListeApplications.html("");
				if (data.length == 0) {
					// Si aucun element, msg d'info
					pListeApplications.append("Vous ne disposez d'aucun droit d'habilitation sur les applications.");
				} else {
					// Parcours data
					for (var i in data) {
						// Recuperation element courant
						var itemApplication = data[i];
						// Ajout Applications
						pListeApplications.append(
								"<button type=\"button\" class=\"btn btn-outline btn-primary btn-application\" type=\"button\" id=\"" + itemApplication.hwiCN + "\">" + itemApplication.hwiCN + "</button>\n");
					}
				}
			},
			error: function( data, status, response ){
				$.alert("Erreur récuperation liste Applications");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}
	// Detail Application
	function getDetailApplication() {
		$.log("> detailApplication ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertApplication);
		$.cleanMessage(panelAlertDetailApplication);
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: '../endpoint/manager/1/application/detail/' + currentId,
			dataType: 'json',
			success: function( data, status, response ) {
				// Si clientId indefini
				if (data.clientId == '') {
					// Affichage message erreur
					$.errorMessage(panelAlertApplication, "Erreur récuperation détail application.");
					// Masquage panelDetailApplication
					panelDetailApplication.addClass("hide");
				} else {
					// Ajout informations
					panelDetailApplication.find("#detail-application-titre").html(data.nom);
					panelDetailApplication.find("#detail-application-clientId").html(data.clientId);
					panelDetailApplication.find("#detail-application-keyOcean").html(data.keyOcean);
					formCreateAccessToken.find("#client-id").html(data.clientId);
					formGeneratorConfig.find("#config-client-id").val(data.clientId);
					// Activation btn si KeyPrismePublic
					if (data.keyPrismePublic == "") {
						panelDetailApplication.find("#detail-application-keyPrismePublic").val("");
						btnGetPublicKey.attr('disabled', '');
					} else {
						panelDetailApplication.find("#detail-application-keyPrismePublic").val(data.keyPrismePublicFormated);
						btnGetPublicKey.removeAttr('disabled');
					}
					// Affichage panelDetailApplication
					panelDetailApplication.removeClass("hide");
				}
			},
			error: function( data, status, response ){
				// Affichage message erreur
				$.errorMessage(panelAlertApplication, "Erreur récuperation détail application.");
				// Masquage panelDetailApplication
				panelDetailApplication.addClass("hide");
			},
			complete: function() {
				$.stopLoading();
			}
		});
		// Reset Form
		formCreateAccessToken[0].reset();
		changeCinematique("CC");
		changeMode("client");
		// Go To Application
		$('.nav-tabs li:nth-child(1) a').click();
	}
	// Generer Cle + Recuperer PrivateKey
	function generateKey() {
		$.log("> generateKey : " + currentId);
		// Creation tabParam
		var tabParam = {
			"cn": currentId
		};
		// Callback Success
		var callbackSuccess = function() {
			// Actualisation Cle Publique
			getDetailApplication();
			// Affichage Message final
			$.successMessage(panelAlertDetailApplication, "La génération des clés pour l'application s'est correctement déroulée.");
		};
		// Callback Error
		var callbackError = function() {
			// Affichage Message Error
			$.errorMessage(panelAlertDetailApplication, "Erreur dans la génération des clés de l'application.");
		};
		// Download File depuis XHR (new)
		$.downloadFileXHR("../endpoint/manager/1/application/generateKey", tabParam, 
				callbackSuccess, callbackError
		);
	}
	// Recuperer PublicKey
	function getPublicKey() {
		$.log("> getPublicKey");
		// Creation tabParam
		var tabParam = {
			"cn": currentId
		};
		// Callback Error
		var callbackError = function() {
			// Affichage Message Error
			$.errorMessage(panelAlertDetailApplication, "Erreur dans la récupération de la clé publique de l'application.");
		};
		// Download File depuis XHR (new)
		$.downloadFileXHR("../endpoint/manager/1/application/publicKey", tabParam,
				null, callbackError
		);
	}
	// Change Cinematique
	function changeCinematique(value) {
		$.log("> changeCinematique : " + value);
		// Clean message
		$.cleanMessage(panelAlertCreateAccessToken);
		// Clean champs In Error
		formCreateAccessToken.find(".form-check-value").removeClass("has-error");
		// Vidage champs dependant de la cinematique
		formCreateAccessToken.find(".depends-cinematique").val("");
		// Vidage champs resultat
		formCreateAccessToken.find(".form-resultat").addClass("hide");
		formCreateAccessToken.find("#jeton-acces").val("");
		formCreateAccessToken.find("#requete-demande").val("");
		// Masquage Cinematique Group
		formCreateAccessToken.find(".cinematique-group").addClass("hide");
		// Affichage Cinematique
		formCreateAccessToken.find("#cinematique-" + value).removeClass("hide");
	}
	// Control Form CreateAccessToken
	function controlFormCreateAccessToken() {
		$.log("> controlFormCreateAccessToken ");
		var champsInError = false;
		// Clean champs In Error
		formCreateAccessToken.find(".form-check-value").removeClass("has-error");
		// Client Secret (all)
		if (formCreateAccessToken.find("#client-secret").val() == "") {
			formCreateAccessToken.find("#div-client-secret").addClass("has-error");
			champsInError = true;
		}
		// Scope (all)
		if (formCreateAccessToken.find("#scope").val() == "") {
			formCreateAccessToken.find("#div-scope").addClass("has-error");
			champsInError = true;
		}
		// Si CC
		if (formCreateAccessToken.find("#cinematique").val() == "CC") {
			// Username
			if (formCreateAccessToken.find("#username").val() == "") {
				formCreateAccessToken.find("#div-username").addClass("has-error");
				champsInError = true;
			}
			// Password
			if (formCreateAccessToken.find("#password").val() == "") {
				formCreateAccessToken.find("#div-password").addClass("has-error");
				champsInError = true;
			}
		}
		// Si jwt
		if (formCreateAccessToken.find("#cinematique").val() == "JWT") {
			// Subject (jwt)
			if (formCreateAccessToken.find("#subject").val() == "") {
				formCreateAccessToken.find("#div-subject").addClass("has-error");
				champsInError = true;
			}
			// Cle privee (jwt)
			if (formCreateAccessToken.find("#private-key").val() == "") {
				formCreateAccessToken.find("#div-private-key").addClass("has-error");
				champsInError = true;
			}
		}
		// Si InterOps
		if (formCreateAccessToken.find("#cinematique").val() == "InterOps") {
			// jeton InterOps (interOps)
			if (formCreateAccessToken.find("#jeton-InterOps").val() == "") {
				formCreateAccessToken.find("#div-jeton-InterOps").addClass("has-error");
				champsInError = true;
			}
		}
		// Si Ocean
		if (formCreateAccessToken.find("#cinematique").val() == "Ocean") {
			// jeton Ocean (ocean)
			if (formCreateAccessToken.find("#jeton-Ocean").val() == "") {
				formCreateAccessToken.find("#div-jeton-Ocean").addClass("has-error");
				champsInError = true;
			}
		}
		return champsInError;
	}
	// Submit Form CreateAccessToken
	function submitFormCreateAccessToken(action) {
		$.log("> submitFormCreateAccessToken : " + action);
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertCreateAccessToken);
		// Clean data
		formCreateAccessToken.find(".form-resultat").addClass("hide");
		formCreateAccessToken.find("#jeton-acces").val("");
		formCreateAccessToken.find("#requete-demande").val("");
		// Control Form CreateAccessToken
		if (!controlFormCreateAccessToken()) {
			// Construction Params avec callback
			var createParamsBeforeAjax = function(callbackAjax) {
				// Params
				var cinematique = formCreateAccessToken.find("#cinematique").val();
				var dataParams = {
					cinematique:cinematique,
					clientId:formCreateAccessToken.find("#client-id").html(),
					clientSecret:formCreateAccessToken.find("#client-secret").val(),
					scope:formCreateAccessToken.find("#scope").val()
				};
				if (cinematique == "CC") {
					dataParams["username"] = formCreateAccessToken.find("#username").val();
					dataParams["password"] = formCreateAccessToken.find("#password").val();
					callbackAjax.call(this, dataParams);
				} else if (cinematique == "JWT") {
					dataParams["subject"] = formCreateAccessToken.find("#subject").val();
					if (!$.isFileReaderAvailable()) {
						// Recuperation contenu textarea
						dataParams["filePrivateKey"] = formCreateAccessToken.find("#private-key").val();
						callbackAjax.call(this, dataParams);
					} else {
						// Verification extension fichier
						if (!formCreateAccessToken.find("#private-key").val().toLowerCase().endsWith(".pem")) {
							formCreateAccessToken.find("#div-private-key").addClass("has-error");
							$.errorMessage(panelAlertCreateAccessToken, "Fichier supporté : Extension .pem");
						} else {
							// Recuperation par FileReader
							$.readContentFileUpload("private-key", function(e) {
								if (e != undefined && e.target != undefined) {
									dataParams["filePrivateKey"] = e.target.result;
								}
								callbackAjax.call(this, dataParams);
							});
						}
					}
				} else if (cinematique == "InterOps") {
					dataParams["jetonInterOps"] = formCreateAccessToken.find("#jeton-InterOps").val();
					callbackAjax.call(this, dataParams);
				} else if (cinematique == "Ocean") {
					dataParams["jetonOcean"] = formCreateAccessToken.find("#jeton-Ocean").val();
					callbackAjax.call(this, dataParams);
				}
			};
			// Appel avec callback
			createParamsBeforeAjax.call(this, function(dataParams) {
				// Affichage Message Attente
				$.warningMessage(panelAlertCreateAccessToken, "Traitement en cours... ");
				// Appel ajax
				$.ajax({
					type: 'POST',
					url: '../endpoint/manager/1/application/' + action,
					contentType: 'application/json',
					data: JSON.stringify(dataParams),
					dataType: 'json',
					success: function( dataResult, status, response ) {
						// Clean message
						$.cleanMessage(panelAlertCreateAccessToken);
						if (action == "accessToken") {
							// Affichage Message Succes
							$.successMessage(panelAlertCreateAccessToken, "La demande de jeton d'accès s'est correctement déroulée.");
							// Affichage Data
							formCreateAccessToken.find("#div-resultat-jeton-acces").removeClass("hide");
							formCreateAccessToken.find("#jeton-acces").val(dataResult.access_token);
						} else if (action == "requeteDemande") {
							// Affichage Message Succes
							$.successMessage(panelAlertCreateAccessToken, "La génération de la requête de demande s'est correctement déroulée.");
							// Affichage Data
							formCreateAccessToken.find("#div-resultat-requete-demande").removeClass("hide");
							formCreateAccessToken.find("#requete-demande").val(dataResult.requete_demande);
						} else {
							// Affichage Message Error
							$.errorMessage(panelAlertCreateAccessToken, "Retour Action non pris en compte.");
						}
					},
					error: function( dataResult, status, response ) {
						// Clean message
						$.cleanMessage(panelAlertCreateAccessToken);
						// Verification status
						if (dataResult.status == 400) {
							// En cas d'erreur, affiche message sur panelAlert
							$.errorMessage(panelAlertCreateAccessToken, dataResult.responseText);
						} else {
							// On construit un msg avec codeRetour
							$.errorMessage(panelAlertCreateAccessToken,
									"Impossible d'afficher le résultat (Code Retour " + dataResult.status + " - " + dataResult.statusText + ")");
						} 
					},
					complete: function() {
						$.stopLoading();
					}
				});
			});
		} else {
			// Error champs obligatoires
			$.errorMessage(panelAlertCreateAccessToken, "Certains champs obligatoires ne sont pas renseignés.");
			// Masquage Loading
			$.stopLoading();
		}
		// Go to Form
		$.goTo("#form-create-access-token");
	}

	// Generator Config
	// Change Mode
	function changeMode(value) {
		$.log("> changeMode : " + value);
		// Force Mode
		formGeneratorConfig.find( "[name=mode]" ).val(value);
		// Clean message
		$.cleanMessage(panelAlertGeneratorConfig);
		// Clean champs In Error
		formGeneratorConfig.find(".form-check-value").removeClass("has-error");
		// Ajout valeurs EndPoint
		var urlPSS = window.location.href.substring(0, window.location.href.indexOf('/ihm'));
		formGeneratorConfig.find("#config-token-endpoint").val(urlPSS + "/endpoint/token/1/");
		formGeneratorConfig.find("#config-authz-endpoint").val(urlPSS + "/endpoint/authz/1/");
		formGeneratorConfig.find("#config-registry-endpoint").val(urlPSS + "/endpoint/registry/1/");
		formGeneratorConfig.find("#config-populate-endpoint").val(urlPSS + "/endpoint/populate/1/");
		// Masquage Champs resource et complet par defaut
		formGeneratorConfig.find(".resource").addClass("hide");
		formGeneratorConfig.find(".complet").addClass("hide");
		// Affichage Champ mode
		formGeneratorConfig.find("." + value).removeClass("hide");
	}
	// Control Form GeneratorConfig
	function controlFormGeneratorConfig() {
		$.log("> controlFormGeneratorConfig ");
		var champsInError = false;
		// Clean champs In Error
		formGeneratorConfig.find(".form-check-value").removeClass("has-error");
		// Token Endpoint (all)
		if (formGeneratorConfig.find("#config-token-endpoint").val() == "") {
			formGeneratorConfig.find("#div-config-token-endpoint").addClass("has-error");
			champsInError = true;
		}
		// Authz Endpoint (all)
		if (formGeneratorConfig.find("#config-authz-endpoint").val() == "") {
			formGeneratorConfig.find("#div-config-authz-endpoint").addClass("has-error");
			champsInError = true;
		}
		// Registry Endpoint (all)
		if (formGeneratorConfig.find("#config-registry-endpoint").val() == "") {
			formGeneratorConfig.find("#div-config-registry-endpoint").addClass("has-error");
			champsInError = true;
		}
		// Populate Endpoint (all)
		if (formGeneratorConfig.find("#config-populate-endpoint").val() == "") {
			formGeneratorConfig.find("#div-config-populate-endpoint").addClass("has-error");
			champsInError = true;
		}
		// Security Options (all)
		if (formGeneratorConfig.find("#config-security-options").val() == "") {
			formGeneratorConfig.find("#div-config-security-options").addClass("has-error");
			champsInError = true;
		}
		// Client ID (all)
		if (formGeneratorConfig.find("#config-client-id").val() == "") {
			formGeneratorConfig.find("#div-config-client-id").addClass("has-error");
			champsInError = true;
		}
		// Client Secret (all)
		if (formGeneratorConfig.find("#config-client-secret").val() == "") {
			formGeneratorConfig.find("#div-config-client-secret").addClass("has-error");
			champsInError = true;
		}
		return champsInError;
	}
	// Submit Form GeneratorConfig
	function submitFormGeneratorConfig() {
		$.log("> submitFormGeneratorConfig ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertGeneratorConfig);
		// Control Form GeneratorConfig
		if (!controlFormGeneratorConfig()) {
			// Creation parametres
			var url = "../endpoint/manager/1/application/generatorConfig";
			var tabParam = {
				"mode": formGeneratorConfig.find( "[name=mode]" ).val(),
				"authenticator": formGeneratorConfig.find( "[name=authenticator]" ).val(),
				"authorizer": formGeneratorConfig.find( "[name=authorizer]" ).val(),
				"providerPermissionsLoader": formGeneratorConfig.find( "[name=providerPermissionsLoader]" ).val(),
				"providerPermissionsFile": formGeneratorConfig.find( "[name=providerPermissionsFile]" ).val(),
				"httpClient": formGeneratorConfig.find( "[name=httpClient]" ).val(),
				"tokenEndpoint": formGeneratorConfig.find( "[name=tokenEndpoint]" ).val(),
				"authzEndpoint": formGeneratorConfig.find( "[name=authzEndpoint]" ).val(),
				"registryEndpoint": formGeneratorConfig.find( "[name=registryEndpoint]" ).val(),
				"populateEndpoint": formGeneratorConfig.find( "[name=populateEndpoint]" ).val(),
				"identityStore": formGeneratorConfig.find( "[name=identityStore]" ).val(),
				"identityCacheMaxEntries": formGeneratorConfig.find( "[name=identityCacheMaxEntries]" ).val(),
				"identityValidity": formGeneratorConfig.find( "[name=identityValidity]" ).val(),
				"tokenStore": formGeneratorConfig.find( "[name=tokenStore]" ).val(),
				"tokenCacheMaxEntries": formGeneratorConfig.find( "[name=tokenCacheMaxEntries]" ).val(),
				"tokenValidity": formGeneratorConfig.find( "[name=tokenValidity]" ).val(),
				"permissionsStore": formGeneratorConfig.find( "[name=permissionsStore]" ).val(),
				"permissionsCacheMaxEntries": formGeneratorConfig.find( "[name=permissionsCacheMaxEntries]" ).val(),
				"permissionsValidity": formGeneratorConfig.find( "[name=permissionsValidity]" ).val(),
				"jmxActivated": formGeneratorConfig.find( "[name=jmxActivated]" ).is(':checked'),
				"securityOptions": formGeneratorConfig.find( "[name=securityOptions]" ).val(),
				"clientId": formGeneratorConfig.find( "[name=clientId]" ).val(),
				"clientSecret": formGeneratorConfig.find( "[name=clientSecret]" ).val(),
				"urlClientCallback": formGeneratorConfig.find( "[name=urlClientCallback]" ).val(),
				"urlBackendRedirectAfterAuth": formGeneratorConfig.find( "[name=urlBackendRedirectAfterAuth]" ).val(),
				"urlBackendLogout": formGeneratorConfig.find( "[name=urlBackendLogout]" ).val()
			};
			// XHttpRequest
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (xhttp.readyState === 4) {
					if (xhttp.status === 200) {
						// Recuperation filename
						var disposition = xhttp.getResponseHeader("Content-Disposition");
						var filename = "";
						var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
						var matches = filenameRegex.exec(disposition);
						if (matches != null && matches[1]) { 
							filename = matches[1].replace(/['"]/g, '');
						}
						// Generation lien
						var a = document.createElement('a');
						a.href = window.URL.createObjectURL(xhttp.response);
						a.download = filename;
						a.style.display = 'none';
						document.body.appendChild(a);
						a.click();
						// Success
						$.successMessage(panelAlertGeneratorConfig, "La génération du fichier de configuration pour l'application s'est correctement déroulée.");
						// Go to Form
						$.goTo("#form-generator-config");
						// Masquage Loading
						$.stopLoading();
					} else {
						// Error
						$.errorMessage(panelAlertGeneratorConfig, "Erreur lors de la génération du fichier de configuration pour l'application.");
						// Go to Form
						$.goTo("#form-generator-config");
						// Masquage Loading
						$.stopLoading();
					}
				}
			};
			xhttp.open("POST", url, true);
			xhttp.setRequestHeader("Content-Type", "application/json");
			xhttp.responseType = 'blob';
			xhttp.send(JSON.stringify(tabParam));
		} else {
			// Error champs obligatoires
			$.errorMessage(panelAlertGeneratorConfig, "Certains champs obligatoires ne sont pas renseignés.");
			// Go to Form
			$.goTo("#form-generator-config");
			// Masquage Loading
			$.stopLoading();
		}
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build applicationModule");
			// Recuperation Liste Applications
			getListeApplications();
			// Mise en place Listener sur Event
			setEventListener();
		},
		"buildFileUpload" : function(divFile, nameFile) {
			$.log("> build fileUpload");
			if (!$.isFileReaderAvailable()) {
				// Si navigateur non compatible, remplacement par textarea
				$.log(" Navigateur non compatible : remplacement " + nameFile + " par textarea ");
				divFile.html("<textarea class=\"form-control\" rows=\"9\" id=\"" + nameFile + "\"></textarea>");
			}
		}
	};
})();