
// 
// Page Login
// 
var loginModule = (function() {
	// Data
	var loginForm = $( "#login-form" );
	var btnValider = $( "#btn-valider" );
	var username = $( "#username" );
	var password = $( "#password" );
	var alertPanel = $( "#alert-panel" );

	// Fonction privee
	// Init Action
	function initAction() {
		$.log("> initAction ");
		// Affichage Loading
		$.startLoading();
		// Recuperation parametre action
		var action = $.urlParam('action');
		if (action != null) {
			// RequiredAuth
			if (action == "required_auth") {
				// Affichage Msg
				$.errorMessage(alertPanel, "Authentification nécessaire");
			// Logout
			} else if (action == "logout") {
				// Affichage Loading
				$.startLoading();
				// Appel ajax
				$.ajax({
					type: 'POST',
					url: '../endpoint/session/1/logout',
					dataType: 'json',
					success: function( data, status, response ) {
						$.log("> logout - result : " + data.result);
						if (data.result == "TRUE") {
							// Affichage Msg
							$.successMessage(alertPanel, "Déconnexion réussie");
						} else if (data.result == "FALSE") {
							// Erreur Logout
							$.errorMessage(alertPanel, "Erreur Logout");
						} else {
							// Erreur inconnue
							$.errorMessage(alertPanel, "Code retour non pris en compte : " + data.result);
						}
					},
					error: function( data, status, response ){
						$.errorMessage(alertPanel, "Erreur Logout");
					},
					complete: function() {
						$.stopLoading();
					}
				});
			}
		}
		// Masquage Loading
		$.stopLoading();
	}
	// KeyUp Enter
	function keyUpEnter() {
		loginForm.keyup(function( event ) {
			if (event.which == 13) {
				submit(event);
			}
		});
	}
	// Submit btnValider
	function submit(event) {
		event.preventDefault();
		btnValider.blur();
		// Affichage Loading
		$.startLoading();
		// Appel ajax
		$.ajax({
			type: 'POST',
			url: '../endpoint/session/1/login',
			dataType: 'json',
			contentType: 'application/json',
			data: JSON.stringify({
				"username": username.val(),
				"password": password.val()
			}),
			success: function( data, status, response ) {
				$.log("> login - result : " + data.result);
				if (data.result == "TRUE") {
					// Recuperation parametre doRedirect
					var doRedirect = $.urlParam('doRedirect');
					if (doRedirect != null) {
						// Redirection vers doRedirect
						window.location.href = doRedirect;
					} else {
						// Redirection vers dashboard.jsp
						window.location.href = "dashboard.jsp";
					}
				} else if (data.result == "FALSE") {
					// Erreur authentification
					$.errorMessage(alertPanel, "Erreur Authentification");
					// Masquage Loading
					$.stopLoading();
				} else {
					// Erreur inconnue
					$.errorMessage(alertPanel, "Code retour non pris en compte : " + data.result);
					// Masquage Loading
					$.stopLoading();
				}
			},
			error: function( data, status, response ){
				$.errorMessage(alertPanel, "Erreur Authentification");
				// Masquage Loading
				$.stopLoading();
			}
		});
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build loginModule");
			// Gestion parametre action
			initAction();
			// Ajout keyUp
			keyUpEnter();
			// Ajout event sur btnValider
			btnValider.click(function( event ) {
				submit(event);
			});
		}
	};
})();