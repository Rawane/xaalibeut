
// 
// Parametres
// 
var parametresModule = (function() {
	// Data
	var panelParametres = $( "#panel-parametres" );
	var panelAlertParametres = $( "#panel-alert-parametres" );
	var panelAlertListeLogger = $( "#panel-alert-liste-logger" );
	var panelEditLogger = $( "#panel-edit-logger" );
	var dataListeEntryLogger = null;

	// Fonction privee
	// Event Listener
	function setEventListener() {
		$.log("> setEventListener ");
		// Event bouton btn-refresh-liste-logger
		panelParametres.delegate(".btn-refresh-liste-logger", "click", function( event ) {
			event.preventDefault();
			this.blur();
			// Affichage Loading
			$.startLoading();
			// Clean message
			$.cleanMessage(panelAlertListeLogger);
			// Actualisation liste
			dataListeEntryLogger.ajax.reload();
			// Masquage Loading
			$.stopLoading();
		});
	}
	// Liste Parametres
	function getListeParametres() {
		$.log("> listeParametres ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertParametres);
		// Gestion url
		var url = '../endpoint/manager/1/parametres/liste';
		if (MOCK) {
			url = '../endpoint/mock/1/parametres/liste';
		}
		// Appel ajax
		$.ajax({
			type: 'GET',
			url: url,
			dataType: 'json',
			success: function( data, status, response ) {
				// Ajout informations
				panelParametres.find("#cluster-name").html(data.clusterName);
				panelParametres.find("#node-name").html(data.nodeName);
				panelParametres.find("#bind-addr").html(data.bindAddr);
				panelParametres.find("#bind-port").html(data.bindPort);
				panelParametres.find("#initial-host").html(data.initialHost);
			},
			error: function( data, status, response ){
				$.errorMessage(panelAlertParametres, "Erreur récuperation liste Parametres.");
			},
			complete: function() {
				$.stopLoading();
			}
		});
	}
	// Liste Logger
	function getListeLogger() {
		$.log("> listeLogger ");
		// Affichage Loading
		$.startLoading();
		// Clean message
		$.cleanMessage(panelAlertListeLogger);
		// Gestion url
		var url = '../endpoint/manager/1/parametres/logger/liste';
		if (MOCK) {
			url = '../endpoint/mock/1/parametres/logger/liste';
		}
		// Recuperation liste Logger
		dataListeEntryLogger =  $( "#listeEntryLogger" ).DataTable({
			"paging": true,
			"info": true,
			"searching": true,
			"ajax": {
				"url": url,
				"async": false,
				"dataSrc": "data",
				"error": function( dataResult, status, response ) {
					// Erreur Recuperation Liste Logger
					$.errorMessage(panelAlertListeLogger, dataResult.responseText);
					// Ecriture Message
					$( "#listeEntryLogger .dataTables_empty" ).html(dataResult.responseText);
				}
			},
			"columns": [
				{ "data": "order" },
				{ "data": "name" },
				{ "data": "level" },
				{ "data": null }
				// Additionals Hidden Columns
			],
			"columnDefs": [
				// Order
				{
					"targets": [0],
					"visible": false,
					"orderable" : false,
					"searchable": false
				// Action
				}, {
					"targets": [3],
					"orderable" : false,
					"searchable": false,
					"class" : "align-center valign-middle",
					"defaultContent": 
						"<button class='btn btn-success btn-circle btn-edit-logger' type='button'><i class='fa fa-pencil' aria-hidden='true'></i></button>"
				// Additionals Hidden Columns
				}
			],
			"order": [[0, "asc"]],
			"language": $.configDatatable()
		});
		// Event : btn-edit-logger
		dataListeEntryLogger.on('click', '.btn-edit-logger', function (e) {
			e.preventDefault();
			this.blur();
			// Clean message
			$.cleanMessage(panelAlertListeLogger);
			// Recuperation data
			var data = dataListeEntryLogger.row($(this).parents('tr')).data();
			// Mise a jour panel edit logger
			panelEditLogger.find("#detail-logger-name").html(data.name);
			// Mise a jour options level
			panelEditLogger.find(".option-level").removeAttr('selected');
			panelEditLogger.find("#detail-level-" + data.level).attr('selected', 'selected');
			// Affichage bootbox avec panel edit token
			var dialog = bootbox.dialog({
				title: "Détail du Logger",
				message: panelEditLogger.html(),
				buttons: {
					danger: {
						label: "Annuler",
						className: "btn-danger",
					},
					success: {
						label: "Confirmer",
						className: "btn-primary",
						callback: function() {
							// Gestion Mock
							var url = '../endpoint/manager/1/parametres/logger/edit';
							if (MOCK) {
								url = '../endpoint/mock/1/parametres/logger/edit';
							}
							// Affichage Loading
							$.startLoading();
							// Appel ajax
							$.ajax({
								type: 'POST',
								url: url,
								dataType: 'json',
								contentType: 'application/json',
								data: JSON.stringify({
									"name": $(".bootbox").find("#detail-logger-name").html(),
									"level": $(".bootbox").find("#detail-select-level").val()
								}),
								success: function( dataResult, status, response ) {
									$.log("> editLogger - result : " + dataResult.result);
									if (dataResult.result == "TRUE") {
										// Affichage Loading
										$.startLoading();
										// Affichage Message Succes
										$.successMessage(panelAlertListeLogger, "La modification du logger s'est correctement déroulée.");
										// Actualisation liste
										dataListeEntryLogger.ajax.reload();
										// Masquage Loading
										$.stopLoading();
									} else if (dataResult.result == "FALSE") {
										// Erreur edit Logger
										$.errorMessage(panelAlertListeLogger, "Erreur lors de la modification du logger.");
									} else {
										// Erreur inconnue
										$.errorMessage(panelAlertListeLogger, "Code retour non pris en compte : " + dataResult.result);
									}
								},
								error: function( dataResult, status, response ){
									$.errorMessage(panelAlertListeLogger, "Erreur lors de la modification du logger.");
								},
								complete: function() {
									// Masquage Loading
									$.stopLoading();
								}
							});
						}
					}
				}
			}).find("div.modal-dialog").addClass("modal-resized");
		});
		// Masquage Loading
		$.stopLoading();
	}

	// Fonction publique
	// Build
	return {
		"build" : function() {
			$.log("> build parametresModule");
			// Recuperation Liste Parametres
			getListeParametres();
			// Recuperation Liste Logger
			getListeLogger();
			// Mise en place Listener sur Event
			setEventListener();
		}
	};
})();