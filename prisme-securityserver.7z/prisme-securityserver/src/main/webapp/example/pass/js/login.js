/**
* jQuery Cookie plugin
*
* Copyright (c) 2010 Klaus Hartl (stilbuero.de)
* Dual licensed under the MIT and GPL licenses:
* http://www.opensource.org/licenses/mit-license.php
* http://www.gnu.org/licenses/gpl.html
*
*/
jQuery.cookie=function(e,b,a){if(arguments.length>1&&(b===null||typeof b!=="object")){a=jQuery.extend({},a);if(b===null)a.a=-1;if(typeof a.a==="number"){var d=a.a,c=a.a=new Date;c.setDate(c.getDate()+d)}return document.cookie=[encodeURIComponent(e),"=",a.b?String(b):encodeURIComponent(String(b)),a.a?"; expires="+a.a.toUTCString():"",a.path?"; path="+a.path:"",a.domain?"; domain="+a.domain:"",a.c?"; secure":""].join("")}a=b||{};c=a.b?function(f){return f}:decodeURIComponent;return(d=(new RegExp("(?:^|; )"+
encodeURIComponent(e)+"=([^;]*)")).exec(document.cookie))?c(d[1]):null};


(function(a){a.fn.tipsy=function(e){e=a.extend({},a.fn.tipsy.defaults,e);return this.each(function(){var d=a.fn.tipsy.elementOptions(this,e);a(this).hover(function(){a.data(this,"cancel.tipsy",true);var c=a.data(this,"active.tipsy");if(!c){c=a('<div class="tipsy"><div class="tipsy-inner"/></div>');c.css({position:"absolute",zIndex:1E5});a.data(this,"active.tipsy",c)}if(a(this).attr("title")||typeof a(this).attr("original-title")!="string")a(this).attr("original-title",a(this).attr("title")||"").removeAttr("title");
var b;if(typeof d.title=="string")b=a(this).attr(d.title=="title"?"original-title":d.title);else if(typeof d.title=="function")b=d.title.call(this);c.find(".tipsy-inner")[d.html?"html":"text"](b||d.fallback);b=a.extend({},a(this).offset(),{width:this.offsetWidth,height:this.offsetHeight});c.get(0).className="tipsy";c.remove().css({top:0,left:0,visibility:"hidden",display:"block"}).appendTo(document.body);var f=c[0].offsetWidth,g=c[0].offsetHeight;switch((typeof d.gravity=="function"?d.gravity.call(this):
d.gravity).charAt(0)){case "n":c.css({top:b.top+b.height,left:b.left+b.width/2-f/2}).addClass("tipsy-north");break;case "s":c.css({top:b.top-g,left:b.left+b.width/2-f/2}).addClass("tipsy-south");break;case "e":c.css({top:b.top+b.height/2-g/2,left:b.left-f}).addClass("tipsy-east");break;case "w":c.css({top:b.top+b.height/2-g/2,left:b.left+b.width}).addClass("tipsy-west");break}d.fade?c.css({opacity:0,display:"block",visibility:"visible"}).animate({opacity:0.8}):c.css({visibility:"visible"})},function(){a.data(this,
"cancel.tipsy",false);var c=this;setTimeout(function(){if(!a.data(this,"cancel.tipsy")){var b=a.data(c,"active.tipsy");d.fade?b.stop().fadeOut(function(){a(this).remove()}):b.remove()}},100)})})};a.fn.tipsy.elementOptions=function(e,d){return a.metadata?a.extend({},d,a(e).metadata()):d};a.fn.tipsy.defaults={fade:false,fallback:"",gravity:"n",html:false,title:"title"};a.fn.tipsy.autoNS=function(){return a(this).offset().top>a(document).scrollTop()+a(window).height()/2?"s":"n"};a.fn.tipsy.autoWE=function(){return a(this).offset().left>
a(document).scrollLeft()+a(window).width()/2?"e":"w"}})(jQuery);

var mins = 45;
var secs = mins * 60;

$(document).ready(function () {
  var usernameField = $("#username");
  var pwdField = $("#password");
  var loginForm = $("#login-form");
  if (usernameField) {
    usernameField.focus()
    usernameField.attr("autocomplete", "off");
  };

  if (pwdField) {
    pwdField.attr("autocomplete", "off");
  };

  if ($("#content-logged-out")) {
    var options = { path: '/', expires: 10 };
    $.cookie('SignOnDefault', null, options);
    $.cookie('PS_TOKEN', null, options);
    $.cookie('PS_TOKENEXPIRE', null, options);
  };


  $("#username-info, .top-bubble").hide();
  $("a#username-tooltip").tipsy({gravity: $.fn.tipsy.autoNS, title: function(){return $("#username-info").html()}, html: true});
  $("input#username.error").tipsy({gravity:$.fn.tipsy.autoNS, title: function(){return $("#error-username").text()}});
  $("input#password.error").tipsy({gravity:$.fn.tipsy.autoNS, title: function(){return $("#error-passwordAccessKey").text()}});
  $("a[rel=tooltip]").tipsy({gravity: $.fn.tipsy.autoNS});

});


function getminutes() {
  // minutes is seconds divided by 60, rounded down
  mins = Math.floor(secs / 60);
  return mins;
}

function getseconds() {
  // take mins remaining (as seconds) away from total seconds remaining
  return secs - Math.round(mins * 60);
}