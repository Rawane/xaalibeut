package fr.recouv.securite.prisme.authzserver.store;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.google.common.base.Splitter;

import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisApplicationCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisUID;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisProperties;
import fr.recouv.securite.prisme.commun.claims.scope.AbstractScope;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.logger.PrismeLogger;

public class ScopeStorePortailTest {

	private static final PrismeLogger logger = new PrismeLogger().in(
			ScopeStorePortailTest.class).build();

	// Variables
	String ANAIS_CONTEXT_READER = "reader";

	@Test
	public void getScopePortail() throws Exception {
		logger.debug(" > getScopePortail");
		// Variables
		String user;
		String decodedScopes;
		String resultBefore;
		String resultAfter;

		user = "CER4495240";
		decodedScopes = "*:SNV2-PROD";
		// Trace
		logger.debug("");
		logger.debug("user: " + user + ", scope: " + decodedScopes);
		// Before
		resultBefore = doIt(user, decodedScopes, false);
		logger.debug("resultBefore: " + resultBefore);
		// After
		resultAfter = doIt(user, decodedScopes, true);
		logger.debug("resultAfter: " + resultAfter);
		// Verification
		logger.debug("-> equals ? " + resultBefore.equals(resultAfter));

		user = "CER4495240";
		decodedScopes = "*:DSN";
		// Trace
		logger.debug("");
		logger.debug("user: " + user + ", scope: " + decodedScopes);
		// Before
		resultBefore = doIt(user, decodedScopes, false);
		logger.debug("resultBefore: " + resultBefore);
		// After
		resultAfter = doIt(user, decodedScopes, true);
		logger.debug("resultAfter: " + resultAfter);
		// Verification
		logger.debug("-> equals ? " + resultBefore.equals(resultAfter));

		user = "CER4495240";
		decodedScopes = "*:SIDERAL";
		// Trace
		logger.debug("");
		logger.debug("user: " + user + ", scope: " + decodedScopes);
		// Before
		resultBefore = doIt(user, decodedScopes, false);
		logger.debug("resultBefore: " + resultBefore);
		// After
		resultAfter = doIt(user, decodedScopes, true);
		logger.debug("resultAfter: " + resultAfter);
		// Verification
		logger.debug("-> equals ? " + resultBefore.equals(resultAfter));

		user = "CER4400468";
		decodedScopes = "UR527:SNV2-PROD";
		// Trace
		logger.debug("");
		logger.debug("user: " + user + ", scope: " + decodedScopes);
		// Before
		resultBefore = doIt(user, decodedScopes, false);
		logger.debug("resultBefore: " + resultBefore);
		// After
		resultAfter = doIt(user, decodedScopes, true);
		logger.debug("resultAfter: " + resultAfter);
		// Verification
		logger.debug("-> equals ? " + resultBefore.equals(resultAfter));

		user = "CER4400468";
		decodedScopes = "*:SNV2-PROD";
		// Trace
		logger.debug("");
		logger.debug("user: " + user + ", scope: " + decodedScopes);
		// Before
		resultBefore = doIt(user, decodedScopes, false);
		logger.debug("resultBefore: " + resultBefore);
		// After
		resultAfter = doIt(user, decodedScopes, true);
		logger.debug("resultAfter: " + resultAfter);
		// Verification
		logger.debug("-> equals ? " + resultBefore.equals(resultAfter));

		user = "CER4495240";
		decodedScopes = "*:HARMONIE";
		// Trace
		logger.debug("");
		logger.debug("user: " + user + ", scope: " + decodedScopes);
		// Before
		resultBefore = doIt(user, decodedScopes, false);
		logger.debug("resultBefore: " + resultBefore);
		// After
		resultAfter = doIt(user, decodedScopes, true);
		logger.debug("resultAfter: " + resultAfter);
		// Verification
		logger.debug("-> equals ? " + resultBefore.equals(resultAfter));
	}

	private List<AnaisAccessRightInstance> beforePatch(
			Map<String, List<String>> mapScope, String codeAppli, AnaisApplication anaisApplication, AnaisUser anaisUser
		) throws Exception {
		// Variables
		List<AnaisAccessRightInstance> list;
		// Code
		if (mapScope.get(codeAppli).contains(PrismeRequestScope.ALL)) {
			// RequeteAnais (sans CodeOrg)
			list = AnaisAccessRightInstance.build
					.getList(ANAIS_CONTEXT_READER)
					.by(AnaisApplicationCode.set(anaisApplication.getCn().value()))
					.and(PrismeAnaisProperties.getEnvCode()).and(anaisUser)
					.execute();
		} else {
			List<AnaisOrgCode> listOfOrgCode = new ArrayList<AnaisOrgCode>();
			for (String codeOrg : mapScope.get(codeAppli)) {
				listOfOrgCode.add(AnaisOrgCode.build(codeOrg));
			}
			// RequeteAnais (avec CodeOrg)
			list = AnaisAccessRightInstance.build
					.getList(ANAIS_CONTEXT_READER)
					.by(AnaisApplicationCode.set(anaisApplication.getCn().value()))
					.and(PrismeAnaisProperties.getEnvCode()).and(anaisUser)
					.and(listOfOrgCode).execute();
		}
		return list;
	}

	private List<AnaisAccessRightInstance> afterPatch(
			Map<String, List<String>> mapScope, String codeAppli, AnaisApplication anaisApplication, AnaisUser anaisUser
		) throws Exception {
		// Variables
		List<AnaisAccessRightInstance> list;
		// Code
		if (mapScope.get(codeAppli).contains(PrismeRequestScope.ALL)) {
			// RequeteAnais (sans CodeOrg)
			if (anaisApplication.isPortalTypeApplication()) {
				list = AnaisAccessRightInstance.build
						.getList(ANAIS_CONTEXT_READER).by(anaisApplication)
						.and(PrismeAnaisProperties.getEnvCode()).and(anaisUser)
						.execute();
			} else {
				list = AnaisAccessRightInstance.build
						.getList(ANAIS_CONTEXT_READER)
						.by(AnaisApplicationCode.set(anaisApplication
								.getApplicationCode().value()))
						.and(PrismeAnaisProperties.getEnvCode()).and(anaisUser)
						.execute();
			}
		} else {
			List<AnaisOrgCode> listOfOrgCode = new ArrayList<AnaisOrgCode>();
			for (String codeOrg : mapScope.get(codeAppli)) {
				listOfOrgCode.add(AnaisOrgCode.build(codeOrg));
			}
			if (anaisApplication.isPortalTypeApplication()) {
				list = AnaisAccessRightInstance.build
						.getList(ANAIS_CONTEXT_READER).by(anaisApplication)
						.and(PrismeAnaisProperties.getEnvCode()).and(anaisUser)
						.and(listOfOrgCode).execute();
			} else {
				list = AnaisAccessRightInstance.build
						.getList(ANAIS_CONTEXT_READER)
						.by(AnaisApplicationCode.set(anaisApplication
								.getApplicationCode().value()))
						.and(PrismeAnaisProperties.getEnvCode()).and(anaisUser)
						.and(listOfOrgCode).execute();
			}
		}
		return list;
	}

	// Parametres
	private String doIt(String user, String decodedScopes, boolean appliAfter) throws Exception {

		// Etape 1 :
		// Construire une map codeAppli-list<CodeOrg> depuis scopeRequest
		Map<String, List<String>> mapScope = new HashMap<String, List<String>>();
		List<String> listScope = Splitter.on(AbstractScope.SCOPE_SEPARATOR)
				.splitToList(decodedScopes);
		for (String scope : listScope) {
			List<String> element = Splitter.on(AbstractScope.SEPARATOR)
					.splitToList(scope);
			if (element != null && element.size() == 2) {
				String codeOrg = element.get(0);
				String codeAppli = element.get(1);
				if (mapScope.containsKey(codeAppli)) {
					List<String> listCodeOrg = mapScope.get(codeAppli);
					if (!listCodeOrg.contains(codeOrg)) {
						listCodeOrg.add(codeOrg);
					}
				} else {
					List<String> listCodeOrg = new ArrayList<String>();
					listCodeOrg.add(codeOrg);
					mapScope.put(codeAppli, listCodeOrg);
				}
			}
		}

		// Etape 2 :
		// Recuperation AnaisUser
		AnaisUser anaisUser = AnaisUser.build.get(ANAIS_CONTEXT_READER)
				.by(AnaisUID.set(user)).execute();

		// Etape 3 :
		// Pour chaque application
		Map<String, AnaisAccessRightInstance> mapAccessRight = new HashMap<String, AnaisAccessRightInstance>();
		for (String codeAppli : mapScope.keySet()) {
			List<AnaisAccessRightInstance> list = null;

			// AnaisApplication
			AnaisApplication anaisApplication = AnaisApplication.build
					.get(ANAIS_CONTEXT_READER).by(AnaisCN.set(codeAppli)).execute();

			// Modification ici !!!
			if (!appliAfter) {
				// before
				list = beforePatch(mapScope, codeAppli, anaisApplication, anaisUser);
			} else {
				// after
				list = afterPatch(mapScope, codeAppli, anaisApplication, anaisUser);
			}

			// Ajout dans Map Finale si non present
			for (AnaisAccessRightInstance ari : list) {
				String keyAri = patchDSN(ari.getOrgCode().value(), ari
						.getApplicationCode().value())
						+ ","
						+ ari.getApplicationCode().value()
						+ ","
						+ ari.getCn().value();
				if (!mapAccessRight.containsKey(keyAri)) {
					mapAccessRight.put(keyAri, ari);
				}
			}
		}

		// Etape 4 :
		// Calcul Scope Response
		PrismeResponseScope responseScope = PrismeResponseScope.set();
		for (String keyAri : mapAccessRight.keySet()) {
			AnaisAccessRightInstance ari = mapAccessRight.get(keyAri);
			responseScope = responseScope.add(
					patchDSN(ari.getOrgCode().value(), ari.getApplicationCode()
							.value()), ari.getApplicationCode().value(), ari
							.getCn().value());
		}
		responseScope = responseScope.build();
		return responseScope.serialize();
	}

	private String patchDSN(String codeOrg, String codeAppli) {
		if ("DSN".equals(codeAppli)) {
			return "DEFAULT";
		}
		return codeOrg;
	}
}
