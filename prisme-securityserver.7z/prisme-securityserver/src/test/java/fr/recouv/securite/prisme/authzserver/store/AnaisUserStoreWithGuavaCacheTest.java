package fr.recouv.securite.prisme.authzserver.store;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.authzserver.store.AnaisUserStoreWithGuavaCache;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

public class AnaisUserStoreWithGuavaCacheTest {

	private static final PrismeLogger logger = new PrismeLogger().in(
			AnaisUserStoreWithGuavaCacheTest.class).build();

	@Test
	public void getAnaisUserOK() {
		try {

			AnaisUserStoreWithGuavaCache cache = new AnaisUserStoreWithGuavaCache();

			AnaisUser user = cache.get("CER4400468");

			// Verification
			Assert.assertEquals("CER4400468", user.getUid().value());
			Assert.assertEquals("ERIC DE SOUSA", user.getCn().value());

			AnaisUser user2 = cache
					.get("CER4400468");

			// Verification
			Assert.assertEquals("CER4400468", user2.getUid().value());
			Assert.assertEquals("ERIC DE SOUSA", user2.getCn().value());
			Assert.assertEquals(user2, user);
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

}
