package fr.recouv.securite.prisme.authzserver.store;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * AnaisClientStoreWithGuavaCacheTest.
 */
public class AnaisClientStoreWithGuavaCacheTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			AnaisClientStoreWithGuavaCacheTest.class).build();

	@Test
	public void testAnaisClientStoreWithGuavaCacheOK() {
		LOGGER.debug("> testAnaisClientStoreWithGuavaCacheOK");

		// Data
		AnaisClientStoreWithGuavaCache cache = new AnaisClientStoreWithGuavaCache(
				PrismeContexteDescriptor.getAnaisClientStoreExpirationTime());
		AnaisApplication client;
		String clientId = "cn=USR_READ_NAT_APP_RS-MOCK,ou=RS-MOCK,ou=Applications,ou=Technique,dc=recouv";
		String clientSecret = "RS-Mock44";

		LOGGER.debug("--- Demande d'un client OK pour la premiere fois -> mise en cache ---");
		// Demande d'un client OK pour la premiere fois -> mise en cache
		client = null;
		try {
			client = cache.get(clientId, clientSecret);
			Assert.assertNotNull(client);
		} catch (PrismeSystemException e) {
			Assert.fail(e.getMessage());
		}

		LOGGER.debug("--- Demande du meme client OK -> recuperation cache ---");
		// Demande du meme client OK -> recuperation cache
		client = null;
		try {
			client = cache.get(clientId, clientSecret);
			Assert.assertNotNull(client);
		} catch (PrismeSystemException e) {
			Assert.fail(e.getMessage());
		}

		LOGGER.debug("--- Attente ---");
		try {
			LOGGER.debug("expTime a : "
					+ PrismeContexteDescriptor
							.getAnaisClientStoreExpirationTime()
					+ " secondes / sleep a 5 secondes");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			LOGGER.error(e.getMessage());
		}

		LOGGER.debug("--- Demande avec cache expire -> mise en cache ---");
		// Demande avec cache expire -> mise en cache
		client = null;
		try {
			client = cache.get(clientId, clientSecret);
			Assert.assertNotNull(client);
		} catch (PrismeSystemException e) {
			Assert.fail(e.getMessage());
		}

		LOGGER.debug("--- Demande du meme client OK -> recuperation cache ---");
		// Demande du meme client OK -> recuperation cache
		client = null;
		try {
			client = cache.get(clientId, clientSecret);
			Assert.assertNotNull(client);
		} catch (PrismeSystemException e) {
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void testAnaisClientStoreWithGuavaCacheKO() {
		LOGGER.debug("> testAnaisClientStoreWithGuavaCacheKO");

		// Data
		AnaisClientStoreWithGuavaCache cache = new AnaisClientStoreWithGuavaCache(
				PrismeContexteDescriptor.getAnaisClientStoreExpirationTime());
		AnaisApplication client;
		String clientId = "cn=USR_READ_NAT_APP_BAD-CLIENT-ID,ou=BAD-CLIENT-ID,ou=Technique,dc=recouv";
		String clientSecret = "BAD-CLIENT-SECRET";

		LOGGER.debug("--- Demande d'un client mal declare -> retour null ---");
		// Demande d'un client mal declare -> retour null
		client = null;
		try {
			client = cache.get("BAD-CLIENT-ID", clientSecret);
			Assert.fail("Exception attendue");
		} catch (PrismeSystemException e) {
			// Exception attendue
			Assert.assertNull(client);
		}

		LOGGER.debug("--- Demande d'un client KO -> retour null ---");
		// Demande d'un client KO -> retour null
		client = null;
		try {
			client = cache.get(clientId, clientSecret);
			Assert.fail("Exception attendue");
		} catch (PrismeSystemException e) {
			// Exception attendue
			Assert.assertNull(client);
		}
	}

	@Test
	public void testBuildAnaisClientStoreWithGuavaCache() {
		LOGGER.debug("> testBuildAnaisClientStoreWithGuavaCache");
		AnaisClientStoreWithGuavaCache cache;

		// Cache sans expTime definie : utilisation valeur par defaut
		LOGGER.debug("--- Cache sans expTime definie : utilisation valeur par defaut ---");
		cache = new AnaisClientStoreWithGuavaCache();
		Assert.assertNotNull(cache);

		// Cache a expTime a 0 : pas de cache
		LOGGER.debug("--- Cache a expTime a 0 : pas de cache ---");
		cache = new AnaisClientStoreWithGuavaCache(0);
		Assert.assertNotNull(cache);

		// Cache a expTime a -1 : cache illimite
		LOGGER.debug("--- Cache a expTime a -1 : cache illimite ---");
		cache = new AnaisClientStoreWithGuavaCache(-1);
		Assert.assertNotNull(cache);
	}
}
