package fr.recouv.securite.prisme.authzserver.anais;

import java.util.List;

import javax.naming.NamingException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisEnvCode;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;

/**
 * AnaisAuthenticateTest. <br>
 * Test Authenticate Client / Resource / User
 */
public class AnaisAuthenticateTest {

	private String contextName = "reader";
	private String cn = "PRISME-PSS";
	private String envCode = "PROD";

	/**
	 * Client :
	 * cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv
	 * => CLIENT-Mock44
	 */
	public static final String clientId = "cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv";
	public static final String clientSecret = "CLIENT-Mock44";

	/**
	 * Resource :
	 * cn=USR_READ_NAT_APP_RS-MOCK,ou=RS-MOCK,ou=Applications,ou=Technique,dc=recouv
	 * => RS-Mock44
	 */
	private String resourceId = "cn=USR_READ_NAT_APP_RS-MOCK,ou=RS-MOCK,ou=Applications,ou=Technique,dc=recouv";
	private String resourceSecret = "RS-Mock44";

	/**
	 * User :
	 * CER4400466 / Etienne COTASSON
	 * => Pass:466
	 * CER4400468 / Eric De SOUSA
	 * => Pass:468
	 */
	public static final String userId = "CER4495240";
	public static final String userSecret = "P@ssword240";
	private String userIdKO = "CER4400466";
	private String userSecretKO = "Pass:466";

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAuthenticateClient() {
		AnaisApplication anaisApplication = null;

		try {
			anaisApplication = AnaisApplication.build.set(contextName)
					.withAccount(clientId, clientSecret).authenticate();
		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisApplication);
	}

	@Test
	public void testAuthenticateResource() {
		AnaisApplication anaisApplication = null;

		try {
			anaisApplication = AnaisApplication.build.set(contextName)
					.withAccount(resourceId, resourceSecret).authenticate();
		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisApplication);
	}

	@Test
	public void testAuthenticateUser() {
		AnaisUser anaisUser = null;
		AnaisApplication application = null;
		List<AnaisAccessRightInstance> listAnaisHabilitation = null;

		try {
			anaisUser = AnaisUser.build.set(contextName)
					.withAccount(userId, userSecret).authenticate();
			application = AnaisApplication.build
					.get(contextName).by(AnaisCN.set(cn)).execute();
			listAnaisHabilitation = AnaisAccessRightInstance.build
					.getList(contextName).by(anaisUser).and(application)
					.and(AnaisEnvCode.set(envCode))
					.execute();
		} catch (AnaisExceptionFailure e1) {
			e1.printStackTrace();
			Assert.fail("ne doit pas avoir d'exception : " + e1);
		} catch (AnaisExceptionServerCommunication e1) {
			e1.printStackTrace();
			Assert.fail("ne doit pas avoir d'exception : " + e1);
		} catch (NamingException e1) {
			e1.printStackTrace();
			Assert.fail("ne doit pas avoir d'exception : " + e1);
		}
		Assert.assertNotNull(anaisUser);
		Assert.assertNotNull(listAnaisHabilitation);
		Assert.assertFalse(listAnaisHabilitation.isEmpty());
	}

	@Test
	public void testAuthenticateUserKO() {
		AnaisUser anaisUser = null;
		AnaisApplication application = null;
		List<AnaisAccessRightInstance> listAnaisHabilitation = null;

		try {
			anaisUser = AnaisUser.build.set(contextName)
					.withAccount(userIdKO, userSecretKO).authenticate();
			application = AnaisApplication.build
					.get(contextName).by(AnaisCN.set(cn)).execute();
			listAnaisHabilitation = AnaisAccessRightInstance.build
					.getList(contextName).by(anaisUser).and(application)
					.and(AnaisEnvCode.set(envCode))
					.execute();
		} catch (AnaisExceptionFailure e1) {
			e1.printStackTrace();
			Assert.fail("ne doit pas avoir d'exception : " + e1);
		} catch (AnaisExceptionServerCommunication e1) {
			e1.printStackTrace();
			Assert.fail("ne doit pas avoir d'exception : " + e1);
		} catch (NamingException e1) {
			e1.printStackTrace();
			Assert.fail("ne doit pas avoir d'exception : " + e1);
		}
		Assert.assertNotNull(anaisUser);
		Assert.assertNotNull(listAnaisHabilitation);
		Assert.assertTrue(listAnaisHabilitation.isEmpty());
	}

}
