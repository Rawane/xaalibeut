package fr.recouv.securite.prisme.authzserver.endpoint;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * ManagerEndpointTest.
 */
public class ManagerEndpointTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			ManagerEndpointTest.class).build();

	private static final ManagerEndpoint endPoint = new ManagerEndpoint();

	@Test
	public void testPing() {
		LOGGER.debug(" > testPing");
		Assert.assertNotNull(endPoint.ping());
	}

	// TODO

}
