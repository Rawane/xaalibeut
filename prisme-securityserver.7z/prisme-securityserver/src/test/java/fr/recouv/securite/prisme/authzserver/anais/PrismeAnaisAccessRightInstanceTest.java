package fr.recouv.securite.prisme.authzserver.anais;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisUID;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisAccessRightInstanceTest.
 */
public class PrismeAnaisAccessRightInstanceTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisAccessRightInstanceTest.class).build();

	private static String CONTEXT_NAME = "reader";

	@Test
	public void listeAccessRightByUserTest() throws Exception {
		LOGGER.debug("> listeAccessRightByUserTest");
		List<AnaisAccessRightInstance> listAccessRight = null;
		String user;

		user = "CER4495240";

		// Liste AccessRight utilisateur by User
		listAccessRight = PrismeAnaisAccessRightInstance.listeAccessRightByUser(user);
		// Verification
		for (AnaisAccessRightInstance ari : listAccessRight) {
			String codeOrg = ari.getOrgCode().value();
			String codeApp = ari.getApplicationCode().value();
			String libDroit = ari.getCn().value();
			LOGGER.debug(codeOrg+":"+codeApp+":"+libDroit);
		}
		LOGGER.debug("< listeAccessRightByUserTest");
	}

	@Test
	public void listeAccessRightByAnaisUserTest() throws Exception {
		LOGGER.debug("> listeAccessRightByUserTest");
		List<AnaisAccessRightInstance> listAccessRight = null;
		String user;
		AnaisUser anaisUser;

		user = "CER4495240";
		anaisUser = getAnaisUser(user);

		// Liste AccessRight utilisateur by AnaisUser
		listAccessRight = PrismeAnaisAccessRightInstance.listeAccessRightByAnaisUser(anaisUser);
		// Verification
		for (AnaisAccessRightInstance ari : listAccessRight) {
			String codeOrg = ari.getOrgCode().value();
			String codeApp = ari.getApplicationCode().value();
			String libDroit = ari.getCn().value();
			LOGGER.debug(codeOrg+":"+codeApp+":"+libDroit);
		}
		LOGGER.debug("< listeAccessRightByUserTest");
	}

	@Test
	public void listeAccessRightByUserAppTest() throws Exception {
		LOGGER.debug("> listeAccessRightByUserAppTest");
		List<AnaisAccessRightInstance> listAccessRight = null;
		String user;
		AnaisUser anaisUser;
		String codeAppli;
		AnaisApplication anaisApplication;

		user = "CER4495240";
		anaisUser = getAnaisUser(user);

		codeAppli = "SIDERAL";
		anaisApplication = getAnaisApplication(codeAppli);

		// Liste AccessRight utilisateur by User App
		listAccessRight = PrismeAnaisAccessRightInstance.listeAccessRightByUserApp(anaisUser, anaisApplication);
		// Verification
		for (AnaisAccessRightInstance ari : listAccessRight) {
			String codeOrg = ari.getOrgCode().value();
			String codeApp = ari.getApplicationCode().value();
			String libDroit = ari.getCn().value();
			LOGGER.debug(codeOrg+":"+codeApp+":"+libDroit);
		}
		LOGGER.debug("< listeAccessRightByUserAppTest");
	}

	@Test
	public void listeAccessRightForPSSTest() throws Exception {
		LOGGER.debug("> listeAccessRightForPSSTest");
		List<AnaisAccessRightInstance> listAccessRight = null;
		String user;
		AnaisUser anaisUser;
		String codeAppli;
		AnaisApplication anaisApplication;
		List<AnaisOrgCode> listOfOrgCode;

		user = "CER4495240";
		anaisUser = getAnaisUser(user);

		codeAppli = "PRISME-PSS";
		anaisApplication = getAnaisApplication(codeAppli);

		listOfOrgCode = new ArrayList<AnaisOrgCode>();
		listOfOrgCode.add(AnaisOrgCode.build(anaisUser.getOu().value()));

		// Liste AccessRight utilisateur by User App CodeOrg
		listAccessRight = PrismeAnaisAccessRightInstance.listeAccessRightByUserAppCodeOrg(anaisUser, anaisApplication, listOfOrgCode);
		// Verification
		for (AnaisAccessRightInstance ari : listAccessRight) {
			String codeOrg = ari.getOrgCode().value();
			String codeApp = ari.getApplicationCode().value();
			String libDroit = ari.getCn().value();
			LOGGER.debug(codeOrg+":"+codeApp+":"+libDroit);
		}
		LOGGER.debug("< listeAccessRightByUserAppCodeOrgTest");
	}

	@Test
	public void listeAccessRightByUserAppCodeOrgTest() throws Exception {
		LOGGER.debug("> listeAccessRightByUserAppCodeOrgTest");
		List<AnaisAccessRightInstance> listAccessRight = null;
		String user;
		AnaisUser anaisUser;
		String codeAppli;
		AnaisApplication anaisApplication;
		List<AnaisOrgCode> listOfOrgCode;

		user = "CER4495240";
		anaisUser = getAnaisUser(user);

		codeAppli = "SNV2-PROD";
		anaisApplication = getAnaisApplication(codeAppli);

		listOfOrgCode = new ArrayList<AnaisOrgCode>();
		listOfOrgCode.add(AnaisOrgCode.build("UR527"));
		listOfOrgCode.add(AnaisOrgCode.build("UR547"));

		// Liste AccessRight utilisateur by User App CodeOrg
		listAccessRight = PrismeAnaisAccessRightInstance.listeAccessRightByUserAppCodeOrg(anaisUser, anaisApplication, listOfOrgCode);
		// Verification
		for (AnaisAccessRightInstance ari : listAccessRight) {
			String codeOrg = ari.getOrgCode().value();
			String codeApp = ari.getApplicationCode().value();
			String libDroit = ari.getCn().value();
			LOGGER.debug(codeOrg+":"+codeApp+":"+libDroit);
		}
		LOGGER.debug("< listeAccessRightByUserAppCodeOrgTest");
	}

	private AnaisUser getAnaisUser(String user) throws Exception {
		return AnaisUser.build
				.get(CONTEXT_NAME)
				.by(AnaisUID.set(user))
				.execute();
	}

	private AnaisApplication getAnaisApplication(String codeAppli) throws Exception {
		return AnaisApplication.build
				.get(CONTEXT_NAME)
				.by(AnaisCN.set(codeAppli))
				.execute();
	}
}
