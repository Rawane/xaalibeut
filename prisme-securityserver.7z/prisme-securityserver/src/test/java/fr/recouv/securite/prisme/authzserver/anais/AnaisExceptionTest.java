package fr.recouv.securite.prisme.authzserver.anais;

import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisDN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisUID;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * Classe de test decrivant les cas d'Exception non gérée par Anais. <br>
 * 
 * Rechercher le libellé suivant :
 * "TODO Anais : Erreur cote Anais, a corriger dans lib Anais" <br>
 * dans Prisme pour trouver les cas d'utilisations.<br>
 * 
 */
public class AnaisExceptionTest {

	private static final PrismeLogger logger = new PrismeLogger().in(
			AnaisExceptionTest.class).build();

	private String contextName = "reader";

	@Test
	public void testUserInconnu() {
		try {
			// Creation UID
			AnaisUID uid = AnaisUID.set("utilisateur_inconnu");
			// Si uid correct
			if (uid.isAnValidateUID()) {
				// Recuperation utilisateur avec uid inconnu
				AnaisUser.build.get(contextName).by(uid).execute();
			}
			// Fin
			logger.debug("[testUserInconnu] OK");
		} catch (AnaisExceptionFailure e) {
			// Exception traitée par Anais, OK
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			// Exception traitée par Anais, OK
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (NamingException e) {
			// Exception traitée par Anais, OK
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (Exception e) {
			// Exception non traitée par Anais
			logger.error("Exception non traitée par Anais : [Class="
					+ e.getClass() + ",Message=" + e.getMessage() + "]");
		}
	}

	@Test
	public void testTechnicalAccountInconnu() {
		try {
			// Creation dn
			AnaisDN dn = AnaisDN.set("client_id_inconnu");
			// Si dn correct
			if (dn.isAnValidateDN()) {
				// Recuperation techninalAccount avec client id inconnu
				AnaisTechnicalAccount.build.get(contextName).by(dn).execute();
			}
			// Fin
			logger.debug("[testTechnicalAccountInconnu] OK");
		} catch (AnaisExceptionFailure e) {
			// Exception traitée par Anais, OK
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			// Exception traitée par Anais, OK
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (NamingException e) {
			// Exception traitée par Anais, OK
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (Exception e) {
			// Exception non traitée par Anais
			logger.error("Exception non traitée par Anais : [Class="
					+ e.getClass() + ",Message=" + e.getMessage() + "]");
		}
	}
}
