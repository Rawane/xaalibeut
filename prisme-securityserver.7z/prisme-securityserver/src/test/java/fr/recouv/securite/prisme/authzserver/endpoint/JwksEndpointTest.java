package fr.recouv.securite.prisme.authzserver.endpoint;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.logger.PrismeLogger;

public class JwksEndpointTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			JwksEndpointTest.class).build();
	private JwksEndpoint jwksEndpoint = new JwksEndpointMock();
	
	@Test
	public void testPing() {
		LOGGER.debug(" > testPing");
		Assert.assertNotNull(jwksEndpoint.ping());
	}
	@Test
	public void testDistributionKo() {
		//autorisation vide
		LOGGER.debug(" > testDistributionKo");
		Mockery contextMock = new Mockery();
		final HttpHeaders headerHttp = contextMock.mock(HttpHeaders.class);	
		// distribution clés Client avec authorisation non renseigné status :400
		
		contextMock.checking(new Expectations() {
			{
				allowing(headerHttp).getRequestHeader("Authorization");
				will(returnValue(null));
			}
		});
		 Response response = jwksEndpoint.distribution(headerHttp, "client");
		Assert.assertEquals(response.getStatus(), 400);
	}
		
	
	@Test
	public void testDistribution() {
		LOGGER.debug(" > testDistribution");
		Mockery contextMock = new Mockery();
		final HttpHeaders headerHttp = contextMock.mock(HttpHeaders.class);
		// distribution clés PSS status:200
		Response response = jwksEndpoint.distribution(headerHttp, "pss");
		Assert.assertEquals(response.getStatus(), 200);
		// distribution clés Client avec authorisation non renseigné status :400
		final List<String> listHeader = new ArrayList<String>();
		contextMock.checking(new Expectations() {
			{
				allowing(headerHttp).getRequestHeader("Authorization");
				will(returnValue(listHeader));
			}
		});
		response = jwksEndpoint.distribution(headerHttp, "client");
		Assert.assertEquals(response.getStatus(), 400);
		// distribution clés Client avec erreur de connection ANAiS status: 401

		listHeader.add("Basic dXNlcjpwYXNzd29yZA==");
		contextMock.checking(new Expectations() {
			{
				allowing(headerHttp).getRequestHeader("Authorization");
				will(returnValue(listHeader));
			}
		});
		response = jwksEndpoint.distribution(headerHttp, "client");
		Assert.assertEquals(response.getStatus(), 401);
		// distribution clés Client OK status: 200
		listHeader.clear();
		listHeader
				.add("Basic Y249VVNSX1JFQURfTkFUX0FQUF9DTElFTlQtTU9DSyxvdT1DTElFTlQtTU9DSyxvdT1BcHBsaWNhdGlvbnMsT1U9VGVjaG5pcXVlLGRjPXJlY291djpDTElFTlQtTW9jazQ0");
		contextMock.checking(new Expectations() {
			{
				allowing(headerHttp).getRequestHeader("Authorization");
				will(returnValue(listHeader));
			}
		});
		response = jwksEndpoint.distribution(headerHttp, "client");
		Assert.assertEquals(response.getStatus(), 200);

	}
}
