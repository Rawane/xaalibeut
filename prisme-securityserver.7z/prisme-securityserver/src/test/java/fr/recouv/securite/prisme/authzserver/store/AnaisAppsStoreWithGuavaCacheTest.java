package fr.recouv.securite.prisme.authzserver.store;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * AnaisAppsStoreWithGuavaCacheTest.
 */
public class AnaisAppsStoreWithGuavaCacheTest {

	private static final PrismeLogger logger = new PrismeLogger().in(
			AnaisAppsStoreWithGuavaCacheTest.class).build();

	@Test
	public void getAnaisApplicationOK() {
		try {
			AnaisAppsStoreWithGuavaCache cache = new AnaisAppsStoreWithGuavaCache();
			AnaisApplication app = cache.get("SNV2-PROD");
			// Verification
			Assert.assertEquals("SNV2-PROD", app.getCn().value());

			AnaisApplication app2 = cache.get("SNV2-PROD");
			// Verification
			Assert.assertEquals("SNV2-PROD", app2.getCn().value());
			Assert.assertEquals(app, app2);
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void getAnaisApplicationKO() {
		AnaisApplication app = null;
		try {
			AnaisAppsStoreWithGuavaCache cache = new AnaisAppsStoreWithGuavaCache();
			app = cache.get("BAD-APP-ID");
			// Exception attendue
			Assert.fail("Exception attendue");
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.assertNull(app);
		}
	}
}
