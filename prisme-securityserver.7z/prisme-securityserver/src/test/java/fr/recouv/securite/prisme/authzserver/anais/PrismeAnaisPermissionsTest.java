package fr.recouv.securite.prisme.authzserver.anais;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.providers.bean.PermissionsData;
import fr.recouv.securite.prisme.commun.utils.StringUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisPermissionsTest
 */
public class PrismeAnaisPermissionsTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisPermissionsTest.class).build();

	@Test
	public void getDescriptionTest() {
		LOGGER.debug(" > getDescriptionTest ");

		String codeApplication;
		String codeOrg;
		String libDroit;
		String description;

		try {
			// Application null
			codeOrg = "CER44";
			libDroit = "ESB_TECH";
			description = PrismeAnaisPermissions.getDescription(null, codeOrg, libDroit);
			Assert.fail("Exception attendue.");
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception attendue : " + e.getMessage());
		}

		try {
			// Application inconnue
			codeApplication = "FAKE_APPLICATION";
			codeOrg = "CER44";
			libDroit = "ESB_TECH";
			description = PrismeAnaisPermissions.getDescription(codeApplication, codeOrg, libDroit);
			Assert.fail("Exception attendue.");
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception attendue : " + e.getMessage());
		}

		try {
			// CodeOrg null
			codeApplication = "PRISME-PSS";
			libDroit = "ESB_TECH";
			description = PrismeAnaisPermissions.getDescription(codeApplication, null, libDroit);
			Assert.fail("Exception attendue.");
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception attendue : " + e.getMessage());
		}

		try {
			// CodeOrg inconnu
			codeApplication = "PRISME-PSS";
			codeOrg = "FAKE_CODE_ORG";
			libDroit = "MOE";
			description = PrismeAnaisPermissions.getDescription(codeApplication, codeOrg, libDroit);
			Assert.fail("Exception attendue.");
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception attendue : " + e.getMessage());
		}

		try {
			// Libelle droit null
			codeApplication = "PRISME-PSS";
			codeOrg = "CER44";
			description = PrismeAnaisPermissions.getDescription(codeApplication, codeOrg, null);
			Assert.fail("Exception attendue.");
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception attendue : " + e.getMessage());
		}

		try {
			// Application avec description vide
			codeApplication = "PRISME-PSS";
			codeOrg = "CER44";
			libDroit = "MOE";
			description = PrismeAnaisPermissions.getDescription(codeApplication, codeOrg, libDroit);
			LOGGER.debug("codeApplication: " + codeApplication);
			LOGGER.debug("description vide? " + StringUtility.isNullOrEmpty(description));
			Assert.assertEquals("", description);
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception non attendue : " + e.getMessage());
			Assert.fail(e.getMessage());
		}

		try {
			// SNV2-PROD
			codeApplication = "SNV2-PROD";
			codeOrg = "CER44";
			libDroit = "ESB_TECH";
			description = PrismeAnaisPermissions.getDescription(codeApplication, codeOrg, libDroit);
			LOGGER.debug("codeApplication: " + codeApplication);
			LOGGER.debug("description vide? " + StringUtility.isNullOrEmpty(description));
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception non attendue : " + e.getMessage());
			Assert.fail(e.getMessage());
		}

		try {
			// DSN
			codeApplication = "DSN";
			codeOrg = "DEFAULT";
			libDroit = "NAT_CONSULT";
			description = PrismeAnaisPermissions.getDescription(codeApplication, codeOrg, libDroit);
			LOGGER.debug("codeApplication: " + codeApplication);
			LOGGER.debug("description vide? " + StringUtility.isNullOrEmpty(description));
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception non attendue : " + e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void getPermissionsDataTest() {
		LOGGER.debug(" > getPermissionsDataTest ");

		String codeApplication;
		String codeOrg;
		String libDroit;
		PermissionsData pData;

		try {
			// SNV2-PROD
			codeApplication = "SNV2-PROD";
			codeOrg = "CER44";
			libDroit = "ESB_TECH";
			pData = PrismeAnaisPermissions.getPermissionsData(codeApplication, codeOrg, libDroit);
			LOGGER.debug("listeActionsUnitaire: " + pData.getListeActionsUnitaire());

			// DSN
			codeApplication = "DSN";
			codeOrg = "DEFAULT";
			libDroit = "NAT_CONSULT";
			pData = PrismeAnaisPermissions.getPermissionsData(codeApplication, codeOrg, libDroit);
			LOGGER.debug("listeActionsUnitaire: " + pData.getListeActionsUnitaire());
		} catch (PrismeSystemException e) {
			LOGGER.debug("Exception non attendue : " + e.getMessage());
			Assert.fail(e.getMessage());
		}
	}
}
