package fr.recouv.securite.prisme.authzserver.endpoint;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import net.minidev.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.authzserver.anais.AnaisAuthenticateTest;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.PrismeProtocoleError;
import fr.recouv.securite.prisme.commun.message.types.PrismeGrantType;
import fr.recouv.securite.prisme.commun.message.types.PrismePopulateType;
import fr.recouv.securite.prisme.commun.utils.json.JSONUtils;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * TokenEndpointTest.
 */
public class TokenEndpointTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			TokenEndpointTest.class).build();

	private static final TokenEndpoint endPoint = new TokenEndpoint();

	/**
	 * Mock ServletInputStream from String
	 */
	class MockServletInputStream extends ServletInputStream {
		InputStream inputStream;
		MockServletInputStream(String inputStream) {
			this.inputStream = IOUtils.toInputStream(inputStream);
		}
		@Override
		public int read() throws IOException {
			return inputStream.read();
		}
	}

	/**
	 * Methode commune de traitement.<br>
	 * (Difference par rapport aux autres endpoint)
	 * 
	 * @param iStream
	 *            resultat du traitement
	 * @return object Response
	 * @throws IOException
	 *             exception si erreur
	 * @throws PrismeSystemException
	 *             exception si erreur
	 */
	private Response castInResponse(
			final ServletInputStream iStream) throws IOException,
			PrismeSystemException {
		Mockery context = new Mockery();
		final HttpServletRequest servletRequest = context.mock(HttpServletRequest.class);
		context.checking(new Expectations() {
			{
				atLeast(1).of(servletRequest).getInputStream();
				will(returnValue(iStream));
			}
		});
		// TODO : Prendre en compte autres methodes du endpoint
//		return endPoint.request(servletRequest);
		return endPoint.authorize(servletRequest);
	}

	@Test
	public void testPing() {
		LOGGER.debug(" > testPing");
		Assert.assertNotNull(endPoint.ping());
	}

	@Test
	public void testRequestConsumerCredKOScope() throws Exception {
		LOGGER.debug(" > testRequestConsumerCredKOScope");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.GRANT_TYPE, PrismeGrantType.CONSUMER_CREDENTIALS.toString());
		jsonResponse.put(PrismeParams.CLIENT_ID, AnaisAuthenticateTest.clientId);
		jsonResponse.put(PrismeParams.CLIENT_SECRET, AnaisAuthenticateTest.clientSecret);
		jsonResponse.put(PrismeParams.SCOPE, "scope_invalid");
		jsonResponse.put(PrismeParams.USERNAME, AnaisAuthenticateTest.userId);
		jsonResponse.put(PrismeParams.PWD, AnaisAuthenticateTest.userSecret);

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification Erreur attendue
		Assert.assertEquals(
				ExceptionCode.FUNCTION_FAILURE.toString(),
				mapResponse.get(PrismeProtocoleError.ERROR_CODE));
		Assert.assertEquals(
				"Probleme lors du decodage de la chaine de scope",
				mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
	}

	@Test
	public void testClientKO() throws Exception {
		LOGGER.debug(" > testClientKO");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.CLIENT_ID, "client_id");
		jsonResponse.put(PrismeParams.CLIENT_SECRET, "client_secret");

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification Erreur attendue
		Assert.assertEquals(
				ExceptionCode.SECURITY.toString(),
				mapResponse.get(PrismeProtocoleError.ERROR_CODE));
		Assert.assertEquals(
				"Erreur lors de l'authentification Client sur Anais.",
				mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
	}

	@Test
	public void testProviderNull() throws Exception {
		LOGGER.debug(" > testProviderNull");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.CLIENT_ID, AnaisAuthenticateTest.clientId);
		jsonResponse.put(PrismeParams.CLIENT_SECRET, AnaisAuthenticateTest.clientSecret);

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification Erreur attendue
		Assert.assertEquals(
				PrismeProtocoleError.TOKEN_PROTOCOLE.INVALID_CODE,
				mapResponse.get(PrismeProtocoleError.ERROR_CODE));
		Assert.assertEquals(
				PrismeProtocoleError.TOKEN_PROTOCOLE.INVALID_MESSAGE,
				mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
	}

	@Test
	public void testProviderKO() throws Exception {
		LOGGER.debug(" > testProviderKO");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.GRANT_TYPE, PrismePopulateType.IDENTITY.toString());
		jsonResponse.put(PrismeParams.CLIENT_ID, AnaisAuthenticateTest.clientId);
		jsonResponse.put(PrismeParams.CLIENT_SECRET, AnaisAuthenticateTest.clientSecret);

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification Erreur attendue
		Assert.assertEquals(
				PrismeProtocoleError.TOKEN_PROTOCOLE.INVALID_CODE,
				mapResponse.get(PrismeProtocoleError.ERROR_CODE));
		Assert.assertEquals(
				PrismeProtocoleError.TOKEN_PROTOCOLE.INVALID_MESSAGE,
				mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
	}

}
