package fr.recouv.securite.prisme.authzserver.endpoint;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * AuthzEndpointTest.
 */
public class AuthzEndpointTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			AuthzEndpointTest.class).build();

	private static final AuthzEndpoint endPoint = new AuthzEndpoint();

	@Test
	public void testPing() {
		LOGGER.debug(" > testPing");
		Assert.assertNotNull(endPoint.ping());
	}
}
