package fr.recouv.securite.prisme.authzserver.store;

import java.util.Date;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

public class ScopeStoreWithGuavaCacheTest {

	private static final PrismeLogger logger = new PrismeLogger().in(
			ScopeStoreWithGuavaCache.class).build();

	@Test
	public void getScopeOK() {
		try {

			ScopeStoreWithGuavaCache cache = new ScopeStoreWithGuavaCache();

			String user1 = "CER4400468";
			String user2 = "CER4400466";
			
			String encodedRequestScope1 = PrismeRequestScope.set()
					.add("UR527", "SNV2-PROD").encode();

			String encodedRequestScope2 = PrismeRequestScope.set()
					.add("*", "SNV2-PROD").encode();
			
			Date dateDebut = new Date();
			PrismeResponseScope scopeResponse1 = cache.get(user1, encodedRequestScope1);
			// Verification
			System.out.println(scopeResponse1.encode());
			//H4sIAAAAAAAAAAsNMjUytwr2CzPSDQjyd7Fydw0O8fT3i3d08fX08wwOCXIM8QxzjXdxDY539vcNCAHSfoYA7RZ6xjUAAAA=
			long interval = new Date().getTime() - dateDebut.getTime();
			System.out.println("Duree traitement (ms):" + interval);
			
			//out cache
			Date dateDebut2 = new Date();
			PrismeResponseScope scopeResponse2 = cache.get(user1, encodedRequestScope1);
			long interval2 = new Date().getTime() - dateDebut2.getTime();
			System.out.println(scopeResponse2.encode());
			System.out.println("Duree traitement (ms):" + interval2);
			
			Date dateDebut3 = new Date();
			PrismeResponseScope scopeResponse3 = cache.get(user1, encodedRequestScope2);
			long interval3 = new Date().getTime() - dateDebut3.getTime();
			System.out.println(scopeResponse3.encode());
			System.out.println("Duree traitement (ms):" + interval3);
			
			Date dateDebut4 = new Date();
			PrismeResponseScope scopeResponse4 = cache.get(user2, encodedRequestScope2);
			long interval4 = new Date().getTime() - dateDebut4.getTime();
			System.out.println(scopeResponse4.encode());
			System.out.println("Duree traitement (ms):" + interval4);
			
			Date dateDebut5 = new Date();
			PrismeResponseScope scopeResponse5 = cache.get(user2, encodedRequestScope2);
			long interval5 = new Date().getTime() - dateDebut5.getTime();
			System.out.println(scopeResponse5.encode());
			System.out.println("Duree traitement (ms):" + interval5);
			
			Date dateDebut6 = new Date();
			PrismeResponseScope scopeResponse6 = cache.get(user2, encodedRequestScope1);
			long interval6 = new Date().getTime() - dateDebut6.getTime();
			System.out.println(scopeResponse6.encode());
			System.out.println("Duree traitement (ms):" + interval6);
			
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void getScopeKO() {
		try {
			ScopeStoreWithGuavaCache cache = new ScopeStoreWithGuavaCache();

			String user = "CER4400468";
			// Scope incomplet (SNV2-PROD)
			String encodedRequestScope = "H4sIAAAAAAAAAAv2CzPSDQjydwEAYwtCAwkAAAA=";
			logger.debug("encodedRequestScope:" + encodedRequestScope);

			Date dateDebut = new Date();
			PrismeResponseScope scopeResponse = cache.get(user, encodedRequestScope);
			long interval = new Date().getTime() - dateDebut.getTime();
			System.out.println(scopeResponse.encode());
			System.out.println("Duree traitement (ms):" + interval);
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

}
