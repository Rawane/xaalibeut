package fr.recouv.securite.prisme.authzserver.anais;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;

/**
 * PrismeAnaisAuthenticatorTest.
 */
public class PrismeAnaisAuthenticatorTest {

	@Test
	public void testAuthenticateClient() {

		AnaisApplication anaisApplication = null;
		// Authenticate OK
		String clientId = "cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv";
		String clientSecret = "CLIENT-Mock44";
		try {
			anaisApplication = PrismeAnaisAuthenticator.authenticateClient(
					clientId, clientSecret);
		} catch (PrismeSystemException e) {
			Assert.fail(e.getMessage());
		}
		Assert.assertNotNull(anaisApplication);

		// Authenticate Failure (ClientId)
		anaisApplication = null;
		clientId = "cn=badClientId,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv";
		clientSecret = "CLIENT-Mock44";
		try {
			anaisApplication = PrismeAnaisAuthenticator.authenticateClient(
					clientId, clientSecret);
		} catch (PrismeSystemException e) {
			// Exception Attendue
		}
		Assert.assertNull(anaisApplication);

		// Authenticate Failure (ClientSecret)
		anaisApplication = null;
		clientId = "cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv";
		clientSecret = "badPassword";
		try {
			anaisApplication = PrismeAnaisAuthenticator.authenticateClient(
					clientId, clientSecret);
		} catch (PrismeSystemException e) {
			// Exception Attendue
		}
		Assert.assertNull(anaisApplication);
	}

	@Test
	public void testAuthenticateUser() {

		AnaisUser anaisUser = null;
		// Authenticate OK
		String userId = "CER4495240";
		String userSecret = "P@ssword240";
		try {
			anaisUser = PrismeAnaisAuthenticator.authenticateUser(userId,
					userSecret);
		} catch (PrismeSystemException e) {
			Assert.fail(e.getMessage());
		}
		Assert.assertNotNull(anaisUser);

		// Authenticate Failure (userId)
		anaisUser = null;
		userId = "ZZZ4400466";
		userSecret = "Pass:466";
		try {
			anaisUser = PrismeAnaisAuthenticator.authenticateUser(userId,
					userSecret);
		} catch (PrismeSystemException e) {
			// Exception Attendue
		}
		Assert.assertNull(anaisUser);

		// Authenticate Failure (userSecret)
		anaisUser = null;
		userId = "CER4400466";
		userSecret = "badPassword";
		try {
			anaisUser = PrismeAnaisAuthenticator.authenticateUser(userId,
					userSecret);
		} catch (PrismeSystemException e) {
			// Exception Attendue
		}
		Assert.assertNull(anaisUser);
	}
}
