package fr.recouv.securite.prisme.authzserver.anais;

import javax.naming.NamingException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisAppKeyPrisme;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisDN;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;

/**
 * AnaisApplicationPKTest.
 */
public class AnaisApplicationPKTest {

	private String contextName = "reader";

	/**
	 * Client :
	 * cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv
	 * => CLIENT-Mock44
	 */
	private String clientId = "cn=USR_READ_NAT_APP_CLIENT-MOCK,ou=CLIENT-MOCK,ou=Applications,OU=Technique,dc=recouv";

	private String saveValuePK;
	private String newValuePK = "PK_Update_JUNIT";

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAnaisTechnicalAccountReadPK() {

		AnaisTechnicalAccount technicalAccount = null;
		try {
			technicalAccount = AnaisTechnicalAccount.build.get(contextName)
					.by(AnaisDN.set(clientId)).execute();
			Assert.assertNotNull(technicalAccount);
		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		}
	}

	@Test
	public void testAnaisTechnicalAccountUpdatePK() {

		AnaisTechnicalAccount technicalAccount = null;
		try {
			technicalAccount = AnaisTechnicalAccount.build.get(contextName)
					.by(AnaisDN.set(clientId)).execute();
			saveValuePK = technicalAccount.getKeyPrisme().value();
		} catch (AnaisExceptionFailure e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		} catch (AnaisExceptionServerCommunication e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		} catch (NamingException e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		}
		Assert.assertNotNull(technicalAccount);

		technicalAccount.setKeyPrisme(AnaisAppKeyPrisme.set(newValuePK));
		try {
			AnaisTechnicalAccount.build.set("writer").with(technicalAccount)
					.save();
			technicalAccount = AnaisTechnicalAccount.build.get(contextName)
					.by(AnaisDN.set(clientId)).execute();
			Assert.assertEquals(newValuePK, technicalAccount.getKeyPrisme()
					.value());
		} catch (AnaisExceptionFailure e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		} catch (AnaisExceptionServerCommunication e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		} catch (NamingException e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		}

		technicalAccount.setKeyPrisme(AnaisAppKeyPrisme.set(saveValuePK));
		try {
			AnaisTechnicalAccount.build.set("writer").with(technicalAccount)
					.save();
		} catch (AnaisExceptionFailure e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		} catch (AnaisExceptionServerCommunication e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		} catch (NamingException e2) {
			Assert.fail("ne doit pas avoir d'exception : " + e2);
			e2.printStackTrace();
		}
	}

}
