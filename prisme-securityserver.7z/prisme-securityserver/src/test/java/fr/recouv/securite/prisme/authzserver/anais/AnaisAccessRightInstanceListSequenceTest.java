package fr.recouv.securite.prisme.authzserver.anais;

import java.util.List;

import javax.naming.NamingException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionFailure;
import fr.recouv.securite.api.anais.api.source.exception.AnaisExceptionServerCommunication;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisApplicationCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisEnvCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisInstancesCibles;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisIrCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisOrgCode;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisSecurityGroupModelObject;
import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisUID;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisAccessRightInstance;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisUser;

public class AnaisAccessRightInstanceListSequenceTest {

	private String contextName = "reader";

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testListByAnaisApplication() {

		AnaisApplication anaisApplication = null;
		try {
			anaisApplication = AnaisApplication.build.get(contextName)
					.by(AnaisCN.set("GHAP")).execute();

		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisApplication);

		List<AnaisAccessRightInstance> list = null;
		try {
			list = AnaisAccessRightInstance.build.getList(contextName)
					.by(anaisApplication).execute();
		} catch (AnaisExceptionFailure e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (NamingException e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		}
		Assert.assertNotNull(list);
	}

	@Test
	public void testListByAnaisApplicationAndCodeOrg() {

		AnaisApplication anaisApplication = null;
		try {
			anaisApplication = AnaisApplication.build.get(contextName)
					.by(AnaisCN.set("GHAP")).execute();

		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisApplication);

		List<AnaisAccessRightInstance> list = null;
		try {
			list = AnaisAccessRightInstance.build.getList(contextName)
					.by(anaisApplication).and(AnaisOrgCode.set("CER44"))
					.execute();
		} catch (AnaisExceptionFailure e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (NamingException e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		}
		Assert.assertNotNull(list);
	}

	@Test
	public void testListByAnaisApplicationAndCodeOrgAndEnv() {

		AnaisApplication anaisApplication = null;
		try {
			anaisApplication = AnaisApplication.build.get(contextName)
					.by(AnaisCN.set("GHAP")).execute();

		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisApplication);

		List<AnaisAccessRightInstance> list = null;
		try {
			list = AnaisAccessRightInstance.build.getList(contextName)
					.by(anaisApplication).and(AnaisOrgCode.set("CER44"))
					.and(AnaisEnvCode.set("PROD")).execute();
		} catch (AnaisExceptionFailure e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (NamingException e) {
			Assert.fail("ne doit pas avoir d'exception" + e.getMessage());
			e.printStackTrace();
		}
		Assert.assertNotNull(list);
	}

	@Test
	public void testListByAnaisApplicationAndUser() {

		AnaisApplication anaisApplication = null;
		try {
			anaisApplication = AnaisApplication.build.get(contextName)
					.by(AnaisCN.set("SNV2-PROD")).execute();

		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisApplication);

		AnaisUser anaisUser = null;
		try {
			anaisUser = AnaisUser.build.get(contextName)
					.by(AnaisUID.set("CER4400468")).execute();

		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisUser);

		List<AnaisAccessRightInstance> list = null;
		try {
			list = AnaisAccessRightInstance.build.getList(contextName)
					.by(anaisUser).and(anaisApplication)
					.and(AnaisEnvCode.set("PROD")).execute();
		} catch (AnaisExceptionFailure e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (NamingException e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		}
		Assert.assertNotNull(list);
	}

	@Test
	public void testSequenceAuthRecupAccessRight() {

		AnaisUser anaisUser = null;
		try {
			anaisUser = AnaisUser.build.get(contextName)
					.by(AnaisUID.set("CER4400468")).execute();

		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisUser);

		AnaisApplication application = null;
		try {
			application = AnaisApplication.build.get(contextName)
					.by(AnaisCN.set("WHAM")).execute();
		} catch (AnaisExceptionFailure e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		List<AnaisAccessRightInstance> listAnaisHabilitation = null;
		try {
			listAnaisHabilitation = AnaisAccessRightInstance.build
					.getList(contextName).by(anaisUser).and(application)
					.and(AnaisEnvCode.set("PROD")).execute();
		} catch (AnaisExceptionFailure e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotNull(listAnaisHabilitation);
	}

	@Test
	public void testListByAnaisSecurityGroupModelObjectSecurityGroupModele() {

		List<AnaisAccessRightInstance> list = null;
		try {
			list = AnaisAccessRightInstance.build
					.getList(contextName)
					.by(AnaisApplicationCode.set("WHAM"))
					.and(AnaisIrCode.set("IR44"))
					.and(AnaisOrgCode.set("CER44"))
					.and(AnaisEnvCode.set("PROD"))
					.and(AnaisSecurityGroupModelObject
							.set("cn=CER44-CER44-ADMIN INFRASTRUCTURES,ou=Modeles,ou=CER44,ou=Groupes de securite,ou=IR44,ou=Recouvrement,dc=recouv"))
					.execute();
		} catch (AnaisExceptionFailure e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (NamingException e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		}
		Assert.assertNotNull(list);
	}

	@Test
	public void testListByAnaisInstancesCibles() {
		AnaisApplication anaisApplication = null;
		try {
			anaisApplication = AnaisApplication.build.get(contextName)
					.by(AnaisCN.set("SIDERAL")).execute();

		} catch (AnaisExceptionFailure e1) {
			Assert.fail("ne doit pas avoir d'exception : " + e1);
			e1.printStackTrace();
		} catch (AnaisExceptionServerCommunication e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		} catch (NamingException e1) {
			Assert.fail("ne doit pas avoir d'exception");
			e1.printStackTrace();
		}
		Assert.assertNotNull(anaisApplication);

		List<AnaisAccessRightInstance> list = null;
		try {
			list = AnaisAccessRightInstance.build
					.getList(contextName)
					.by(anaisApplication)
					.and(AnaisEnvCode.set("PROD"))
					.and(AnaisInstancesCibles.buildOneWith(
							AnaisOrgCode.set("AC750"),
							AnaisApplicationCode.set("SIDERAL-QUERY"),
							AnaisEnvCode.set("PROD"), AnaisCN.set("QUERY")))
					.execute();
		} catch (AnaisExceptionFailure e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (AnaisExceptionServerCommunication e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		} catch (NamingException e) {
			Assert.fail("ne doit pas avoir d'exception");
			e.printStackTrace();
		}
		Assert.assertNotNull(list);
	}
}
