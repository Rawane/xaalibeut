package fr.recouv.securite.prisme.authzserver.store;

import java.security.interfaces.RSAPublicKey;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * KeyStoreWithGuavaCache.
 */
public class KeyStoreWithGuavaCacheTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			KeyStoreWithGuavaCacheTest.class).build();

	@Test
	public void getKeyClientOK() {
		try {
			LOGGER.debug(" > getKeyClientOK ");
			// Data
			KeyStoreWithGuavaCache cache = new KeyStoreWithGuavaCache();
			String clientId = null;
			RSAPublicKey pk;

			pk = null;
			// Recuperation cle avec client OK
			clientId = "cn=USR_READ_NAT_APP_RS-MOCK,ou=RS-MOCK,ou=Applications,ou=Technique,dc=recouv";
			pk = cache.get(clientId);
			Assert.assertNotNull(pk);

			LOGGER.debug(" < getKeyTest ");
		} catch (PrismeSystemException e) {
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void getKeyClientKO() {
		LOGGER.debug(" > getKeyClientKO ");

		// Data
		KeyStoreWithGuavaCache cache = new KeyStoreWithGuavaCache();
		String clientId = null;
		RSAPublicKey pk;

		LOGGER.debug(" -- Recuperation cle avec client mal declare ");
		pk = null;
		try {
			// Recuperation cle avec client mal declare
			clientId = "badClientId";
			pk = cache.get(clientId);
			// Exception attendue
			Assert.fail("Exception attendue");
		} catch (PrismeSystemException e) {
			LOGGER.debug(e.getMessage());
			Assert.assertNull(pk);
		}

		LOGGER.debug(" -- Recuperation cle avec client Id inconnu ");
		pk = null;
		try {
			// Recuperation cle avec client Id inconnu
			clientId = "cn=USR_READ_NAT_APP_BAD-CLIENT-ID,ou=BAD-CLIENT-ID,ou=Technique,dc=recouv";
			pk = cache.get(clientId);
			// Exception attendue
			Assert.fail("Exception attendue");
		} catch (PrismeSystemException e) {
			LOGGER.debug(e.getMessage());
			Assert.assertNull(pk);
		}
	}
}
