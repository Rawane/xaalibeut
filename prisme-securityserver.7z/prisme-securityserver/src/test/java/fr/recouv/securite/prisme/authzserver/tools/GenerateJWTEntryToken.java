package fr.recouv.securite.prisme.authzserver.tools;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.interfaces.RSAPrivateKey;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import com.google.common.io.Files;

import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.security.factory.JWTTokenFactory;
import fr.recouv.securite.prisme.commun.token.JWTToken;
import fr.recouv.securite.prisme.commun.token.reverse.JWTReverse;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * GenerateJWTEntryToken <br>
 * Permet de generer des jetons entree<br>
 * Configurer nbToken et listeUser.
 */
public class GenerateJWTEntryToken {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			GenerateJWTEntryToken.class).build();

	/**
	 * Main : fonction principale.
	 * 
	 * @param args
	 *            String[]
	 */
	public static void main(String[] args) {
		LOGGER.info(" >>> run");
		try {
			// Data
			// NbToken : nbre de token demandes.
			int nbToken = 100;
			// Utilisateur Random dans liste User ou sequentiel ?
			boolean orderRandom = false;
			// ListeUser : liste des utilisateurs Anais.
			List<String> listeUser = new ArrayList<String>();
			// ListeToken ; liste des jetons d'entree generes.
			List<JWTToken> listeToken = new ArrayList<JWTToken>();
			// Fichier de sortie.
			String fileName = "liste_entry_token.csv";
			// Init
			setUp(listeUser);
			if (!orderRandom && nbToken > listeUser.size()) {
				LOGGER.info("nbToken (" + nbToken + ") superieur a listeUser ("
						+ listeUser.size() + "), nbToken reduit.");
				nbToken = listeUser.size();
			}
			// Boucle GenerateToken sur nbToken
			for (int i = 0; i < nbToken; i++) {
				// Subject
				String subject;
				if (orderRandom) {
					subject = getRandomSubject(listeUser);
				} else {
					subject = getOrderSubject(listeUser, i);
				}
				// GenerateJwtEntry
				JWTToken jwtEntry = getJwtEntry(subject);
				LOGGER.info(subject);
				LOGGER.info(jwtEntry.value());
				// Ajout
				listeToken.add(jwtEntry);
			}
			// Ecriture token
			write(listeToken, fileName);
		} catch (PrismeSystemException e) {
			LOGGER.error("Exception in run : " + e.getMessage());
		} catch (PrismeInvalidTokenException e) {
			LOGGER.error("Exception in run : " + e.getMessage());
		}
		LOGGER.info(" <<< run");
	}

	/**
	 * setUp : Init variables.
	 * 
	 * @param listeUser
	 *            List String
	 */
	private static void setUp(List<String> listeUser) {
		LOGGER.debug("... setUp ...");
		// Demarrage
		PrismeContexteDescriptor.start();
		// Liste User
		listeUser.add("UR21700025");
		listeUser.add("UR21700031");
		listeUser.add("UR21700041");
		listeUser.add("UR21700049");
		listeUser.add("UR21700061");
		listeUser.add("UR21700075");
		listeUser.add("UR21700098");
		listeUser.add("UR21700105");
		listeUser.add("UR21700167");
		listeUser.add("UR21700181");
		listeUser.add("UR21700195");
		listeUser.add("UR21700236");
		listeUser.add("UR31700032");
		listeUser.add("UR31700088");
		listeUser.add("UR31700157");
		listeUser.add("UR31700207");
		listeUser.add("UR31700221");
		listeUser.add("UR31700226");
		listeUser.add("UR31700266");
		listeUser.add("UR31700337");
		listeUser.add("UR31700364");
		listeUser.add("UR31700558");
		listeUser.add("UR31700791");
		listeUser.add("UR31701029");
		listeUser.add("UR31702119");
		listeUser.add("UR31702140");
		listeUser.add("UR42700061");
		listeUser.add("UR42700236");
		listeUser.add("UR42700324");
		listeUser.add("UR42700360");
		listeUser.add("UR42700419");
		listeUser.add("UR42700427");
		listeUser.add("UR42700436");
		listeUser.add("UR42700485");
		listeUser.add("UR42700594");
		listeUser.add("UR42700707");
		listeUser.add("UR42720100");
		listeUser.add("UR42720115");
		listeUser.add("UR42720206");
		listeUser.add("UR42720219");
		listeUser.add("UR42720335");
		listeUser.add("UR53700001");
		listeUser.add("UR53700105");
		listeUser.add("UR53700180");
		listeUser.add("UR53700198");
		listeUser.add("UR53700203");
		listeUser.add("UR53700222");
		listeUser.add("UR53700223");
		listeUser.add("UR53700230");
		listeUser.add("UR53700278");
		listeUser.add("UR53700308");
		listeUser.add("UR53700353");
		listeUser.add("UR53700370");
		listeUser.add("UR53700381");
		listeUser.add("UR53700386");
		listeUser.add("UR53700405");
		listeUser.add("UR53700471");
		listeUser.add("UR53700493");
		listeUser.add("UR53700499");
		listeUser.add("UR53700608");
		listeUser.add("UR73700023");
		listeUser.add("UR73700270");
		listeUser.add("UR73701094");
		listeUser.add("UR73701114");
		listeUser.add("UR73701117");
		listeUser.add("UR73701127");
		listeUser.add("UR73701158");
		listeUser.add("UR73701614");
		listeUser.add("UR73701745");
		listeUser.add("UR73701938");
		listeUser.add("UR73702152");
		listeUser.add("UR73702250");
		listeUser.add("UR73702259");
		listeUser.add("UR73702260");
		listeUser.add("UR73702613");
		listeUser.add("UR73702739");
		listeUser.add("UR73705311");
		listeUser.add("UR74700021");
		listeUser.add("UR74700028");
		listeUser.add("UR74700045");
		listeUser.add("UR74700047");
		listeUser.add("UR74700063");
		listeUser.add("UR74700066");
		listeUser.add("UR74700078");
		listeUser.add("UR74700176");
		listeUser.add("UR74700148");
		listeUser.add("UR74700185");
		listeUser.add("UR74700226");
		listeUser.add("UR74705880");
		listeUser.add("UR74706350");
		listeUser.add("UR74706450");
		listeUser.add("UR74707380");
		listeUser.add("UR74707850");
		listeUser.add("UR74708024");
		listeUser.add("UR82700242");
		listeUser.add("UR82700344");
		listeUser.add("UR82703399");
		listeUser.add("UR91700068");
		listeUser.add("UR91700200");
		listeUser.add("UR91700427");
	}

	/**
	 * Retourne un utilisateur sequentiellement.
	 * 
	 * @param listeUser
	 *            List String
	 * @param i
	 *            int
	 * @return String
	 */
	private static String getOrderSubject(List<String> listeUser, int i) {
		return listeUser.get(i);
	}

	/**
	 * Recupere un utilisateur aleatoirement.
	 * 
	 * @param listeUser
	 *            List String
	 * @return String
	 */
	private static String getRandomSubject(List<String> listeUser) {
		Random rdn = new Random();
		int x = 0;
		int y = listeUser.size() - 1;
		if (y == 0) {
			return listeUser.get(0);
		} else {
			return listeUser.get((rdn.nextInt(y - x) + x));
		}
	}

	/**
	 * Genere un JWT Entry.
	 * 
	 * @param subject
	 *            String
	 * @return JWTAccessToken
	 * @throws PrismeSystemException
	 * @throws Exception
	 *             exception
	 */
	private static JWTToken getJwtEntry(String subject)
			throws PrismeSystemException, PrismeInvalidTokenException {
		// Issuer
		String issuer = "cn=USR_READ_NAT_APP_ESBTECH-PARTENAIRE,ou=ESBTECH-PARTENAIRE,ou=Applications,ou=Technique,dc=recouv";

		// Etape 1. Definir le scope
		String encodedScopes = PrismeRequestScope.set()
				.add(PrismeRequestScope.ALL, "SNV2-PROD").encode();

		// Etape 2. Initialiser le JWT d'entrée
		RSAPrivateKey privateKey = PrismeContexteDescriptor.getPrivateKeyFile();

		return JWTTokenFactory.init().setIssuer(issuer)
				.setSubject(subject).setIssueTime(new Date())
				.setScope(encodedScopes).setPrivateKey(privateKey)
				.build();
	}

	/**
	 * Ecrit liste dans fichier de sortie.
	 * 
	 * @param listeJWTAccessToken
	 *            List JWTAccessToken
	 * @param fileName
	 *            String
	 * @throws PrismeSystemException
	 *             exception
	 */
	private static void write(List<JWTToken> listeJWTToken, String fileName)
			throws PrismeSystemException {

		try {
			File file = new File(fileName);
			Charset CHARSET = Charset.forName("UTF-8");
			BufferedWriter writer = Files.newWriter(file, CHARSET);
			StringBuilder stBuilder;
			for (JWTToken jwtEntry : listeJWTToken) {
				stBuilder = new StringBuilder();
				stBuilder.append(JWTReverse.set(jwtEntry.value()).build()
						.getSubject());
				stBuilder.append(";");
				stBuilder.append(jwtEntry.value());
				stBuilder.append("\n");
				writer.write(stBuilder.toString());
			}
			writer.close();
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		} catch (ParseException e) {
			LOGGER.error(e.getMessage());
		}

		LOGGER.info("Ecriture dans fichier : " + fileName);
	}
}
