package fr.recouv.securite.prisme.authzserver.anais;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisUtilityTest.
 */
public class PrismeAnaisUtilityTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisUtilityTest.class).build();

	@Test
	public void extractCodeApplicationTest() {
		LOGGER.debug(" > extractCodeApplication");
		// Variables
		String entry;
		String result;
		String expected;
		// CN complet
		entry = "cn=USR_READ_NAT_APP_OIDC-MOCK,ou=OIDC-MOCK,ou=Applications,OU=Technique,dc=recouv";
		result = PrismeAnaisUtility.extractCodeApplication(entry);
		expected = "OIDC-MOCK";
		LOGGER.debug("- entry: " + entry);
		LOGGER.debug("- result: " + result);
		LOGGER.debug("- expected: " + expected);
		Assert.assertNotNull(result);
		Assert.assertEquals(expected, result);

		// CN incomplet
		entry = "USR_READ_NAT_APP_OIDC-MOCK";
		result = PrismeAnaisUtility.extractCodeApplication(entry);
		expected = "OIDC-MOCK";
		LOGGER.debug("- entry: " + entry);
		LOGGER.debug("- result: " + result);
		LOGGER.debug("- expected: " + expected);
		Assert.assertNotNull(result);
		Assert.assertEquals(expected, result);
	}

	@Test
	public void constructCNTest() {
		LOGGER.debug(" > constructCN");
		// Variables
		String entry;
		String result;
		String expected;
		// Code App
		entry = "OIDC-MOCK";
		result = PrismeAnaisUtility.constructCN(entry);
		expected = "cn=USR_READ_NAT_APP_OIDC-MOCK,ou=OIDC-MOCK,ou=Applications,ou=Technique,dc=recouv";
		LOGGER.debug("- entry: " + entry);
		LOGGER.debug("- result: " + result);
		LOGGER.debug("- expected: " + expected);
		Assert.assertNotNull(result);
		Assert.assertEquals(expected, result);
	}
}
