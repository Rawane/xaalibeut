package fr.recouv.securite.prisme.authzserver.anais;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import fr.recouv.securite.api.anais.api.source.model.fragment.AnaisCN;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.api.anais.api.source.model.primary.HawaiOldTechnicalSupportAccessRightInstance;
import fr.recouv.securite.prisme.authzserver.bo.Application;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PrismeAnaisHabilitationTest.
 */
public class PrismeAnaisHabilitationTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PrismeAnaisHabilitationTest.class).build();

	@Test
	public void getTechnicalAccountTest() throws Exception {
		LOGGER.debug(" > getTechnicalAccount ");

		// Mock listeHabilitationsSurApplication
		List<HawaiOldTechnicalSupportAccessRightInstance> liste = new ArrayList<HawaiOldTechnicalSupportAccessRightInstance>();
		HawaiOldTechnicalSupportAccessRightInstance ariMock;
		ariMock = new HawaiOldTechnicalSupportAccessRightInstance();
		ariMock.setCn(AnaisCN.build("hwi_esbpetals"));
		liste.add(ariMock);
		ariMock = new HawaiOldTechnicalSupportAccessRightInstance();
		ariMock.setCn(AnaisCN.build("hwi_mixte-mock"));
		liste.add(ariMock);
		List<Application> listeApplications = new ArrayList<Application>();
		for (final HawaiOldTechnicalSupportAccessRightInstance ari : liste) {
			listeApplications.add(new Application(ari));
		}
		// Affichage Liste Applications
		for (Application app : listeApplications) {
			LOGGER.debug(app.getHwiCN());
		}

		// Etape 2 : Detail Application
		LOGGER.debug("");
		LOGGER.debug("> /application/detail");
		for (Application app : listeApplications) {
			// Passage IHM
			String cn = app.getHwiCN();

			Application application = new Application();
			// Recuperation technicalAccount
			AnaisTechnicalAccount technicalAccount = PrismeAnaisHabilitation
					.getTechnicalAccount(cn);
			if (technicalAccount != null) {
				application.parseFrom(technicalAccount);
				LOGGER.debug(" > clientId : " + application.getClientId());
			} else {
				LOGGER.debug("!>! technicalAccount null");
			}
		}

		// Etape 3 : Public Key
		LOGGER.debug("");
		LOGGER.debug(" > /application/publicKey");
		for (Application app : listeApplications) {
			// Passage IHM
			String entryCN = app.getHwiCN();

			// Recuperation technicalAccount
			AnaisTechnicalAccount technicalAccount = PrismeAnaisHabilitation
					.getTechnicalAccount(entryCN);
			Application application = new Application();
			if (technicalAccount != null) {
				application.parseFrom(technicalAccount);
			}
			if (application.getKeyPrismePublic() != null) {
				LOGGER.debug(" > KeyPrisme OK");
			} else {
				LOGGER.debug("!>! KeyPrisme vide");
			}
		}
	}
}
