package fr.recouv.securite.prisme.authzserver.store;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * KeyStoreOceanWithGuavaCache.
 */
public class KeyStoreOceanWithGuavaCacheTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			KeyStoreOceanWithGuavaCacheTest.class).build();

	@Test
	public void getKeyOceanOK() {
		try {
			LOGGER.debug(" > getKeyOceanOK ");

			// Data
			KeyStoreOceanWithGuavaCache cache = new KeyStoreOceanWithGuavaCache();
			String clientId = "cn=USR_READ_NAT_APP_RS-MOCK,ou=RS-MOCK,ou=Applications,ou=Technique,dc=recouv";

			// Recuperation cle avec client OK
			String key = cache.get(clientId);
			// Verification
			Assert.assertFalse(key.isEmpty());
			Assert.assertEquals("2AEB3B81CE199D14EBEAABBAAEAC4CED", key);

			// Recuperation meme cle sur client OK
			Assert.assertEquals(key, cache.get(clientId));
		} catch (PrismeSystemException e) {
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void getKeyOceanKO() {
		LOGGER.debug(" > getKeyOceanKO ");

		// Data
		KeyStoreOceanWithGuavaCache cache = new KeyStoreOceanWithGuavaCache();
		String clientId = null;
		String key;

		LOGGER.debug(" -- Recuperation cle ocean avec client mal declare ");
		key = null;
		try {
			// Recuperation cle avec client mal declare
			clientId = "badClientId";
			key = cache.get(clientId);
			// Exception attendue
			Assert.fail("Exception attendue");
		} catch (PrismeSystemException e) {
			LOGGER.debug(e.getMessage());
			Assert.assertNull(key);
		}

		LOGGER.debug(" -- Recuperation cle avec client Id inconnu ");
		key = null;
		try {
			// Recuperation cle avec client Id inconnu
			clientId = "cn=USR_READ_NAT_APP_BAD-CLIENT-ID,ou=BAD-CLIENT-ID,ou=Technique,dc=recouv";
			key = cache.get(clientId);
			// Exception attendue
			Assert.fail("Exception attendue");
		} catch (PrismeSystemException e) {
			LOGGER.debug(e.getMessage());
			Assert.assertNull(key);
		}
	}

}
