package fr.recouv.securite.prisme.authzserver.endpoint;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import net.minidev.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.authzserver.anais.AnaisAuthenticateTest;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.PrismeAnaisUser;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.message.PrismeProtocoleError;
import fr.recouv.securite.prisme.commun.message.types.PrismePopulateType;
import fr.recouv.securite.prisme.commun.message.types.PrismeRegistryType;
import fr.recouv.securite.prisme.commun.utils.json.JSONUtils;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PopulateEndpointTest.
 */
public class PopulateEndpointTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PopulateEndpointTest.class).build();

	private static final PopulateEndpoint endPoint = new PopulateEndpoint();

	/**
	 * Mock ServletInputStream from String
	 */
	class MockServletInputStream extends ServletInputStream {
		InputStream inputStream;
		MockServletInputStream(String inputStream) {
			this.inputStream = IOUtils.toInputStream(inputStream);
		}
		@Override
		public int read() throws IOException {
			return inputStream.read();
		}
	}

	/**
	 * Methode commune de traitement.
	 * 
	 * @param iStream
	 *            resultat du traitement
	 * @return object Response
	 * @throws IOException
	 *             exception si erreur
	 * @throws PrismeSystemException
	 *             exception si erreur
	 */
	private Response castInResponse(
			final ServletInputStream iStream) throws IOException,
			PrismeSystemException {
		Mockery context = new Mockery();
		final HttpServletRequest servletRequest = context.mock(HttpServletRequest.class);
		context.checking(new Expectations() {
			{
				atLeast(1).of(servletRequest).getInputStream();
				will(returnValue(iStream));
			}
		});
		return endPoint.request(servletRequest);
	}

	@Test
	public void testPing() {
		LOGGER.debug(" > testPing");
		Assert.assertNotNull(endPoint.ping());
	}

	@Test
	public void testRequestIdentityOK() throws Exception {
		LOGGER.debug(" > testRequestIdentityOK");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.POPULATE.TYPE, PrismePopulateType.IDENTITY.toString());
		jsonResponse.put(PrismeParams.CLIENT_ID, AnaisAuthenticateTest.clientId);
		jsonResponse.put(PrismeParams.CLIENT_SECRET, AnaisAuthenticateTest.clientSecret);
		jsonResponse.put(PrismeParams.USERNAME, "CER4400468");

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification que user est ok
		Assert.assertEquals("ERIC DE SOUSA",
				mapResponse.get(PrismeAnaisUser.CN.toString()));
	}

	@Test
	public void testRequestIdentityKO() throws Exception {
		LOGGER.debug(" > testRequestIdentityKO");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.POPULATE.TYPE, PrismePopulateType.IDENTITY.toString());
		jsonResponse.put(PrismeParams.CLIENT_ID, AnaisAuthenticateTest.clientId);
		jsonResponse.put(PrismeParams.CLIENT_SECRET, AnaisAuthenticateTest.clientSecret);
		jsonResponse.put(PrismeParams.USERNAME, "user_invalid");

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification Erreur attendue
		Assert.assertEquals(
				PrismeProtocoleError.POPULATE_PROTOCOLE.ERRORONUSERLOAD_CODE,
				mapResponse.get(PrismeProtocoleError.ERROR_CODE));
		Assert.assertEquals(
				PrismeProtocoleError.POPULATE_PROTOCOLE.ERRORONUSERLOAD_MESSAGE,
				mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
	}

	@Test
	public void testRequestAccessRightToAU() throws Exception {
		LOGGER.debug(" > testRequestAccessRightToAU");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.POPULATE.TYPE, PrismePopulateType.ACCESSRIGHT_TO_AU.toString());
		jsonResponse.put(PrismeParams.POPULATE.APPLICATION, "SNV2-PROD");
		jsonResponse.put(PrismeParams.POPULATE.ACCESSRIGHT, "ASSISTANCE_FONCTIONNELLE_N2");
		jsonResponse.put(PrismeParams.POPULATE.PERIMETRE, "UR547");
		jsonResponse.put(PrismeParams.CLIENT_ID, AnaisAuthenticateTest.clientId);
		jsonResponse.put(PrismeParams.CLIENT_SECRET, AnaisAuthenticateTest.clientSecret);

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification que reponse correspond a attendu
		Assert.assertEquals(PrismePopulateType.ACCESSRIGHT_TO_AU.toString(),
				mapResponse.get(PrismeParams.POPULATE.TYPE));
	}

	@Test
	public void testClientIdKO() throws Exception {
		LOGGER.debug(" > testClientIdKO");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.POPULATE.TYPE, PrismePopulateType.IDENTITY.toString());
		jsonResponse.put(PrismeParams.CLIENT_ID, "client_id");
		jsonResponse.put(PrismeParams.CLIENT_SECRET, "client_secret");

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification Erreur attendue
		Assert.assertEquals(
				ExceptionCode.SECURITY.toString(),
				mapResponse.get(PrismeProtocoleError.ERROR_CODE));
		Assert.assertEquals(
				"Erreur lors de l'authentification Client sur Anais.",
				mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
	}

	@Test
	public void testProviderNull() throws Exception {
		LOGGER.debug(" > testProviderNull");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.CLIENT_ID, AnaisAuthenticateTest.clientId);
		jsonResponse.put(PrismeParams.CLIENT_SECRET, AnaisAuthenticateTest.clientSecret);

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification Erreur attendue
		Assert.assertEquals(
				PrismeProtocoleError.POPULATE_PROTOCOLE.INVALID_CODE,
				mapResponse.get(PrismeProtocoleError.ERROR_CODE));
		Assert.assertEquals(
				PrismeProtocoleError.POPULATE_PROTOCOLE.INVALID_MESSAGE,
				mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
	}

	@Test
	public void testProviderKO() throws Exception {
		LOGGER.debug(" > testProviderKO");

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put(PrismeParams.POPULATE.TYPE, PrismeRegistryType.CONFIG.toString());
		jsonResponse.put(PrismeParams.CLIENT_ID, AnaisAuthenticateTest.clientId);
		jsonResponse.put(PrismeParams.CLIENT_SECRET, AnaisAuthenticateTest.clientSecret);

		Response response = castInResponse(new MockServletInputStream(jsonResponse.toString()));
		Assert.assertNotNull(response);
		// Analyse Response
		Map<String, Object> mapResponse = JSONUtils.parse((String) response.getEntity());
		Assert.assertNotNull(mapResponse);
		// Verification Erreur attendue
		Assert.assertEquals(
				PrismeProtocoleError.POPULATE_PROTOCOLE.INVALID_CODE,
				mapResponse.get(PrismeProtocoleError.ERROR_CODE));
		Assert.assertEquals(
				PrismeProtocoleError.POPULATE_PROTOCOLE.INVALID_MESSAGE,
				mapResponse.get(PrismeProtocoleError.ERROR_MESSAGE));
	}
}
