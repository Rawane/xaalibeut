package fr.recouv.securite.prisme.authzserver.anais;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.authzserver.bo.EntryCache;
import fr.recouv.securite.prisme.authzserver.store.StoreManager;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

public class PrismeAnaisScopeTest {

	private static final PrismeLogger logger = new PrismeLogger().in(
			PrismeAnaisScopeTest.class).build();

	@Test
	public void getResponseScopeTestOK() {
		try {
			String user = "CER4400468";
			String encodedRequestScope = PrismeRequestScope.set()
					.add("UR527", "SNV2-PROD").encode();
			PrismeResponseScope responseScope = PrismeAnaisScope
					.getResponseScope(user, encodedRequestScope);
			// Verification
			Assert.assertEquals(
					"UR527:SNV2-PROD:GESTION_ADMINISTRATIVE_DES_COMPTES_N1",
					responseScope.serialize());
			Assert.assertFalse(responseScope.isEmpty());
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void getResponseScopeTestKO() {
		try {
			String user = "CER4400466";
			String encodedRequestScope = PrismeRequestScope.set()
					.add("UR527", "SNV2-PROD").encode();
			PrismeResponseScope responseScope = PrismeAnaisScope
					.getResponseScope(user, encodedRequestScope);
			// Verification
			Assert.assertTrue(responseScope.isEmpty());
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void getResponseScopeTestAllDroits() {
		try {
			String user = "CER4400468";
			String encodedRequestScope = PrismeRequestScope.set()
					.add("*", "SNV2-PROD").encode();
			PrismeResponseScope responseScope = PrismeAnaisScope
					.getResponseScope(user, encodedRequestScope);
			// Verification
			Assert.assertFalse(responseScope.isEmpty());
			Assert.assertTrue(responseScope
					.isValid("CER44:SNV2-PROD:ASSISTANCE_FONCTIONNELLE_N2"));
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

	@Test
	public void getStatsAndContentCache() {
		try {
			// Ajout valeurs
			String user = "CER4400468";
			// Valeur CodeOrg
			String encodedRequestScope = PrismeRequestScope.set()
					.add("UR527", "SNV2-PROD").encode();
			PrismeAnaisScope.getResponseScope(user, encodedRequestScope);
			// Valeur All
			encodedRequestScope = PrismeRequestScope.set()
					.add("*", "SNV2-PROD").encode();
			PrismeAnaisScope.getResponseScope(user, encodedRequestScope);

			// Stats
			logger.debug(StoreManager.scopeStore.stats());
			// Content
			for (EntryCache entry : StoreManager.scopeStore.list()) {
				logger.debug("key: " + entry.getKey() + ", value: " + entry.getValue());
			}

			// Utilisation StoreManager avec nomStore
			Assert.assertNotNull(StoreManager.getStore("scope-store"));
		} catch (PrismeSystemException e) {
			logger.error(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}
}
