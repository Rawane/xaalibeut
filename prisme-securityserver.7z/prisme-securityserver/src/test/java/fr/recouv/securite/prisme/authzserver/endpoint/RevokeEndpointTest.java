package fr.recouv.securite.prisme.authzserver.endpoint;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * RevokeEndpointTest.
 */
public class RevokeEndpointTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			RevokeEndpointTest.class).build();

	private static final RevokeEndpoint endPoint = new RevokeEndpoint();

	@Test
	public void testPing() {
		LOGGER.debug(" > testPing");
		Assert.assertNotNull(endPoint.ping());
	}

}
