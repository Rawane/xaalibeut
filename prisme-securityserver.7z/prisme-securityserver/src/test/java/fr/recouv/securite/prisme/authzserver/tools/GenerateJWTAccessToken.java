package fr.recouv.securite.prisme.authzserver.tools;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.interfaces.RSAPrivateKey;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import com.google.common.io.Files;

import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisScope;
import fr.recouv.securite.prisme.authzserver.issuer.MD5Generator;
import fr.recouv.securite.prisme.commun.PrismeParams;
import fr.recouv.securite.prisme.commun.claims.consumer.ConsumerType;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeRequestScope;
import fr.recouv.securite.prisme.commun.claims.scope.PrismeResponseScope;
import fr.recouv.securite.prisme.commun.config.service.PrismeContexteDescriptor;
import fr.recouv.securite.prisme.commun.exceptions.ExceptionCode;
import fr.recouv.securite.prisme.commun.exceptions.PrismeInvalidTokenException;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.commun.token.JWTAccessToken;
import fr.recouv.securite.prisme.commun.utils.ScopeUtility;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * GenerateJWTAccessToken <br>
 * Permet de generer des jetons access Token<br>
 * Configurer nbToken et listeUser.
 */
public class GenerateJWTAccessToken {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			GenerateJWTAccessToken.class).build();

	/**
	 * Main : fonction principale.
	 * 
	 * @param args
	 *            String[]
	 */
	public static void main(String[] args) {
		LOGGER.info(" >>> run");
		try {
			// Data
			// NbToken : nbre de token demandes.
			int nbToken = 300;
			// ListeUser : liste des utilisateurs Anais.
			List<String> listeUser = new ArrayList<String>();
			// ListeToken : liste des jetons d'access generes.
			List<JWTAccessToken> listeToken = new ArrayList<JWTAccessToken>();
			// Fichier de sortie.
			String fileName = "liste_access_token.csv";
			// Init
			setUp(listeUser);
			// Boucle GenerateToken sur nbToken
			for (int i = 0; i < nbToken; i++) {
				// Subject
				String subject = getRandomSubject(listeUser);
				// GenerateAccessToken
				JWTAccessToken jwtAccessToken = getAccessToken(subject);
				LOGGER.info(ConsumerType.set()
						.setConsumer(jwtAccessToken.getSubject()).getSubject());
				LOGGER.info(PrismeResponseScope.decode(jwtAccessToken
						.getScope()));
				LOGGER.info(jwtAccessToken.value());
				// Ajout
				listeToken.add(jwtAccessToken);
			}
			// Ecriture token
			write(listeToken, fileName);
		} catch (PrismeSystemException e) {
			LOGGER.error("Exception in run : " + e.getMessage());
		}
		LOGGER.info(" <<< run");
	}

	/**
	 * setUp : Init variables.
	 * 
	 * @param listeUser
	 *            List String
	 */
	private static void setUp(List<String> listeUser) {
		LOGGER.debug("... setUp ...");
		// Demarrage
		PrismeContexteDescriptor.start();
		// Liste User
		listeUser.add("UR21700098");
		listeUser.add("UR21700105");
		listeUser.add("UR21700031");
		listeUser.add("UR82700242");
		listeUser.add("UR82700344");
		listeUser.add("UR82703399");
		listeUser.add("UR74700185");
		listeUser.add("UR74700063");
		listeUser.add("UR74705880");
		listeUser.add("UR42700485");
		listeUser.add("UR42720206");
		listeUser.add("UR42720219");
		listeUser.add("UR31702119");
		listeUser.add("UR31700088");
		listeUser.add("UR31702140");
		listeUser.add("UR91700068");
		listeUser.add("UR91700200");
		listeUser.add("UR91700427");
		listeUser.add("UR53700353");
		listeUser.add("UR53700105");
		listeUser.add("UR53700493");
		listeUser.add("UR73701938");
		listeUser.add("UR73701745");
		listeUser.add("UR73702739");
	}

	/**
	 * Recupere un utilisateur aleatoirement.
	 * 
	 * @param listeUser
	 *            List String
	 * @return String
	 */
	private static String getRandomSubject(List<String> listeUser) {
		Random rdn = new Random();
		int x = 0;
		int y = listeUser.size() - 1;
		if (y == 0) {
			return listeUser.get(0);
		} else {
			return listeUser.get((rdn.nextInt(y - x) + x));
		}
	}

	/**
	 * Genere un JWTAccessToken.
	 * 
	 * @param subject
	 *            String
	 * @return JWTAccessToken
	 * @throws PrismeSystemException
	 * @throws Exception
	 *             exception
	 */
	private static JWTAccessToken getAccessToken(String subject)
			throws PrismeSystemException {
		// Data
		// - Issuer
		String issuer = "cn=USR_READ_NAT_APP_ESBTECH-PARTENAIRE,ou=ESBTECH-PARTENAIRE,ou=Applications,ou=Technique,dc=recouv";
		// - Scope Request / Audience
		String audience = PrismeRequestScope.set()
				.add(PrismeRequestScope.ALL, "SNV2-PROD").encode();
		// - IdStore
		String idStore;
		try {
			idStore = ScopeUtility.encodeIdStore(subject, issuer, "["
					+ audience + "]");
		} catch (IOException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					e.getMessage());
		}
		// - PSSIssuer
		String producteurIssuer = "f4k3n0d31dp5570pr0duc73ur155u3r@PSS_CLIENTID";
		PrismeResponseScope scope;
		scope = PrismeAnaisScope.getResponseScope(subject, audience);
		SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		// - IssueTime
		Date dateIssueTime;
		try {
			dateIssueTime = formater.parse("01/01/2016 00:00:01");
		} catch (ParseException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					e.getMessage());
		}
		// - Exptime
		Date dateExpTime;
		try {
			dateExpTime = formater.parse("31/12/2016 23:59:59");
		} catch (ParseException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					e.getMessage());
		}

		JWTAccessToken jwtAccessToken = new JWTAccessToken();
		// JWTID
		jwtAccessToken.setJWTID(new MD5Generator().generateValue());
		// Issuer
		jwtAccessToken.setIssuer(producteurIssuer);
		// IssueTime
		jwtAccessToken.setIssueTime(dateIssueTime);
		// ExpTime
		jwtAccessToken.setExpirationTime(dateExpTime);
		// Scope
		jwtAccessToken.setScope(scope.encode());
		// Consumer
		ConsumerType consumer = ConsumerType.set().setSubject(subject)
				.setClientId(issuer).build();
		jwtAccessToken.setSubject(consumer.serialize());
		// Id Store
		jwtAccessToken.setCustomClaim(PrismeParams.ID_STORE, idStore);

		// Signer JWTToken avec cle privee PSS
		// recuperation privateKey
		RSAPrivateKey privateKey = PrismeContexteDescriptor.getPrivateKeyFile();
		// signer avec privateKey
		try {
			jwtAccessToken.sign(privateKey);
		} catch (PrismeInvalidTokenException e) {
			throw new PrismeSystemException(ExceptionCode.FUNCTION_FAILURE,
					e.getMessage());
		}

		return jwtAccessToken;
	}

	/**
	 * Ecrit liste dans fichier de sortie.
	 * 
	 * @param listeJWTAccessToken
	 *            List JWTAccessToken
	 * @param fileName
	 *            String
	 * @throws PrismeSystemException
	 *             exception
	 */
	private static void write(List<JWTAccessToken> listeJWTAccessToken,
			String fileName) throws PrismeSystemException {

		try {
			File file = new File(fileName);
			Charset CHARSET = Charset.forName("UTF-8");
			BufferedWriter writer = Files.newWriter(file, CHARSET);
			StringBuilder stBuilder;
			for (JWTAccessToken jwtAccessToken : listeJWTAccessToken) {
				stBuilder = new StringBuilder();
				stBuilder.append(ConsumerType.set()
						.setConsumer(jwtAccessToken.getSubject()).getSubject());
				stBuilder.append(";");
				stBuilder.append(PrismeResponseScope.decode(jwtAccessToken
						.getScope()));
				stBuilder.append(";");
				stBuilder.append(jwtAccessToken.value());
				stBuilder.append("\n");
				writer.write(stBuilder.toString());
			}
			writer.close();
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}

		LOGGER.info("Ecriture dans fichier : " + fileName);
	}
}
