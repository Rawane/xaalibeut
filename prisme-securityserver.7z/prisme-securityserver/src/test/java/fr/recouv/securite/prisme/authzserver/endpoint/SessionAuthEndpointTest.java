package fr.recouv.securite.prisme.authzserver.endpoint;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * SessionAuthEndpointTest.
 */
public class SessionAuthEndpointTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			SessionAuthEndpointTest.class).build();

	private static final SessionAuthEndpoint endPoint = new SessionAuthEndpoint();

	@Test
	public void testPing() {
		LOGGER.debug(" > testPing");
		Assert.assertNotNull(endPoint.ping());
	}

}
