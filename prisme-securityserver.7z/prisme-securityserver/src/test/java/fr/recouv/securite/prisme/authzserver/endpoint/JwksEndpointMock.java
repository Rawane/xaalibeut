/**
 * 
 */
package fr.recouv.securite.prisme.authzserver.endpoint;

import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import net.minidev.json.JSONObject;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisApplication;
import fr.recouv.securite.api.anais.api.source.model.primary.AnaisTechnicalAccount;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisAuthenticator;
import fr.recouv.securite.prisme.authzserver.anais.PrismeAnaisHabilitation;
import fr.recouv.securite.prisme.authzserver.bo.Application;
import fr.recouv.securite.prisme.authzserver.security.PrismeSecurityUtility;
import fr.recouv.securite.prisme.commun.exceptions.PrismeSystemException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * @author CER4495267
 * 
 */
public class JwksEndpointMock extends JwksEndpoint {
	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			JwksEndpoint.class).build();

	/*
	 * (non-Javadoc)
	 * 
	 * @see fr.recouv.securite.prisme.authzserver.endpoint.JwksEndpoint#
	 * generateAndSaveKey(java.util.List)
	 */
	@Override
	protected ResponseBuilder generateAndSaveKey(List<String> listCredentials) {
		ResponseBuilder response;
		try {
			LOGGER.info("recupération des clés de l'application  "
					+ listCredentials.get(0));
			AnaisApplication anaisApplication = PrismeAnaisAuthenticator
					.authenticateClient(listCredentials.get(0),
							listCredentials.get(1));
			// application habilité
			// Recuperation application
			AnaisTechnicalAccount technicalAccount = PrismeAnaisHabilitation
					.getTechnicalAccount(anaisApplication.getCn().value());
			Application application = new Application();
			if (technicalAccount != null) {
				application.parseFrom(technicalAccount);
			}
			// Generation cles
			PrismeSecurityUtility.generateKey(application);
			// La partie sauvegarder est supprimée volontairement
			// pour tester l'authentification du client sans stocker la clé sur Anais			
			JSONObject jsonKey = new JSONObject();
			jsonKey.put("private_key", application.getKeyPrismePrivate());
			jsonKey.put("public_key", application.getKeyPrismePublic());
			response = Response.status(HttpServletResponse.SC_OK).entity(
					jsonKey.toString());
		} catch (PrismeSystemException prismeSystemException) {
			LOGGER.error("erreur authentification", prismeSystemException);
			response = Response
					.status(HttpServletResponse.SC_UNAUTHORIZED)
					.entity("Erreur lors de la recuperation des habilitations Prisme sur Anais.");
		}
		return response;
	}

}
