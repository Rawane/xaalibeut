package fr.recouv.securite.prisme.authzserver.endpoint;

import javax.ws.rs.core.Response;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;

import org.junit.Assert;
import org.junit.Test;

import fr.recouv.securite.prisme.authzserver.bo.JSONRequest;
import fr.recouv.securite.prisme.commun.exceptions.PrismeException;
import fr.recouv.securite.prisme.logger.PrismeLogger;

/**
 * PdpEndpointTest.
 */
public class PdpEndpointTest {

	private static final PrismeLogger LOGGER = new PrismeLogger().in(
			PdpEndpointTest.class).build();

	private static final PdpEndpoint pdpEndPoint = new PdpEndpoint();

	@Test
	public void testPdp() throws PrismeException {
		LOGGER.debug(" > testPdp");
		// Variables
		JSONRequest entry;
		Response resp;
		JSONParser jsonParser = new JSONParser(JSONParser.MODE_JSON_SIMPLE);
		JSONObject response;

		try {
			// Sans parametre
			entry = new JSONRequest();
			// Appel pdp
			resp = pdpEndPoint.pdp(entry);
			response = (JSONObject) jsonParser.parse(resp.getEntity().toString());
			// Verification
			Assert.assertNotNull(response.get("error_code"));
			Assert.assertNotNull(response.get("error_message"));
			LOGGER.debug("error_code: " + response.get("error_code"));
			LOGGER.debug("error_message: " + response.get("error_message"));
		} catch (ParseException e) {
			LOGGER.error("ParseException : " + e.getMessage());
			Assert.fail(e.getMessage());
		}

		// Parametres corrects
		entry = new JSONRequest();
		entry.routage_servicename = "DEDE";
		entry.routage_perimetre = "UR547";

		try {
			// Jeton expire
			entry.assertion = "eyJhbGciOiJSUzUxMiJ9.eyJleHAiOi0xNjQzNTE2MDQwLCJzdWIiOiJDR"
					+ "VI0NDk1MjQwQGNuPVVTUl9SRUFEX05BVF9BUFBfTUlYVEUtTU9DSyxvdT1NSVhURS1"
					+ "NT0NLLG91PUFwcGxpY2F0aW9ucyxPVT1UZWNobmlxdWUsZGM9cmVjb3V2IiwiYXVkI"
					+ "joiSDRzSUFBQUFBQUFBQUFzTk1qUTB0d3IyQ3pQU0RRanlkN0Z5ZHcwTzhmVDNpM2Q"
					+ "wOGZYMDh3d09DWElNOFF4empYZHhEWTUzOXZjTkNBSFNma1lLb1VHbUpzaTZISU9EZ"
					+ "1dvZFwvWnhkNDkzOFwvWnhCSnZpNSt2aTRRdFVha1d3REFNeVI3XC8rWEFBQUEiLCJ"
					+ "pc3MiOiJlNWViYTdiN2QwNmY1NmQ5NjA2MWM0YTg1ODA5OTg2MUBjbj1VU1JfUkVBR"
					+ "F9OQVRfQVBQX1BSSVNNRS1QU1Msb3U9UFJJU01FLVBTUyxvdT1BcHBsaWNhdGlvbnM"
					+ "sb3U9VGVjaG5pcXVlLGRjPXJlY291diIsImlkX3N0b3JlIjoiSDRzSUFBQUFBQUFBQ"
					+ "UhOMkRUSXhzVFExTWpHd1NzNnpEUTBPaWc5eWRYU0o5M01NaVhjTUNJajM5WXdJY2R"
					+ "YMTlYZjIxc2t2dFVYbE9SWVU1R1FtSjVaazV1Y1Y2XC9pSDJvYWtKbWZrWlJhV3B1c"
					+ "WtKTnNXcFNibmw1WXBSbnVZRkhzNndvQ2ZmNlZ6V2FTUHI2V25uM09BbDdGam9MTkx"
					+ "ZcVZabUhNNVNOTFdOaFlBdCt5Z3FJMEFBQUE9IiwianRpIjoiNTgxNjQxMGU3YTU0M"
					+ "mFiMTA0OWQ1MzhlYmY4MDI5NWQiLCJpYXQiOjE0ODMyMjUyMDF9.c0wxQeP0KT9TVp"
					+ "K8G02zO80p9d0hOcUopyxl9I_QsqEAHHSf9wqH7Q0oegDHwec8QDBwRfmvSmKLBgkG"
					+ "zr-meX15jHc_ZJ0lor25ccg2vW-mmPT87aWi3knejRQtbZU1MlXpORDQNwpRakBH5o"
					+ "wE1UzeSFuK-dw14LUh6Hl9VCg";
			// Appel pdp
			resp = pdpEndPoint.pdp(entry);
			response = (JSONObject) jsonParser.parse(resp.getEntity().toString());
			// Verification
			Assert.assertNotNull(response.get("error_code"));
			Assert.assertNotNull(response.get("error_message"));
			LOGGER.debug("error_code: " + response.get("error_code"));
			LOGGER.debug("error_message: " + response.get("error_message"));
		} catch (ParseException e) {
			LOGGER.error("ParseException : " + e.getMessage());
			Assert.fail(e.getMessage());
		}

		// Jeton mal signé
		try {
			entry.assertion = "eyJhbGciOiJSUzUxMiJ9.eyJleHAiOjQ2Njc5MTM5NjAsInN1YiI6IkNFU"
					+ "jQ0OTUyNDBAY249VVNSX1JFQURfTkFUX0FQUF9NSVhURS1NT0NLLG91PU1JWFRFLU1"
					+ "PQ0ssb3U9QXBwbGljYXRpb25zLE9VPVRlY2huaXF1ZSxkYz1yZWNvdXYiLCJhdWQiO"
					+ "iJINHNJQUFBQUFBQUFBQXNOTWpRMHR3cjJDelBTRFFqeWQ3RnlkdzBPOGZUM2kzZDA"
					+ "4ZlgwOHd3T0NYSU04UXh6alhkeERZNTM5dmNOQ0FIU2ZrWUtvVUdtSnNpNkhJT0RnV"
					+ "29kXC9aeGQ0OTM4XC9aeEJKdmk1K3ZpNFF0VWFrV3dEQU15UjdcLytYQUFBQSIsIml"
					+ "zcyI6ImU1ZWJhN2I3ZDA2ZjU2ZDk2MDYxYzRhODU4MDk5ODYxQGNuPVVTUl9SRUFEX"
					+ "05BVF9BUFBfUFJJU01FLVBTUyxvdT1QUklTTUUtUFNTLG91PUFwcGxpY2F0aW9ucyx"
					+ "vdT1UZWNobmlxdWUsZGM9cmVjb3V2IiwiaWRfc3RvcmUiOiJINHNJQUFBQUFBQUFBS"
					+ "E4yRFRJeHNUUTFNakd3U3M2ekRRME9pZzl5ZFhTSjkzTU1pWGNNQ0lqMzlZd0ljZFg"
					+ "xOVhmMjFza3Z0VVhsT1JZVTVHUW1KNVprNXVjVjZcL2lIMm9ha0ptZmtaUmFXcHVxa"
					+ "0pOc1dwU2JubDVZcFJudVlGSHM2d29DZmY2VnpXYVNQcjZXbm4zT0FsN0Zqb0xOTFl"
					+ "xVlptSE01U05MV05oWUF0K3lncUkwQUFBQT0iLCJqdGkiOiI1ODE2NDEwZTdhNTQyY"
					+ "WIxMDQ5ZDUzOGViZjgwMjk1ZCIsImlhdCI6MTQ4MzIyNTIwMX0.FsfSkgxYVmmq5Z2"
					+ "JeMvt6tfq24aRdisO1asncH6DquZa1QdEKUFhjnl6VeHj7JBQJLuy05T2ssLkkIy1H"
					+ "STuluZl42abFleJgGDuK7xQX46eV7WnTndpuF9lqLcPEvz4qiaBYX4Rnr15Bg9viPh"
					+ "hwwkhZUegtT29jn1uzP9gJRY";
			// Appel pdp
			resp = pdpEndPoint.pdp(entry);
			response = (JSONObject) jsonParser.parse(resp.getEntity().toString());
			// Verification
			Assert.assertNotNull(response.get("error_code"));
			Assert.assertNotNull(response.get("error_message"));
			LOGGER.debug("error_code: " + response.get("error_code"));
			LOGGER.debug("error_message: " + response.get("error_message"));
		} catch (ParseException e) {
			LOGGER.error("ParseException : " + e.getMessage());
			Assert.fail(e.getMessage());
		}

		try {
			// Jeton correct
			entry.assertion = "eyJhbGciOiJSUzUxMiJ9.eyJleHAiOjQ2Njc5MTM5NjAsInN1YiI6IkNFU"
					+ "jQ0OTUyNDBAY249VVNSX1JFQURfTkFUX0FQUF9NSVhURS1NT0NLLG91PU1JWFRFLU1"
					+ "PQ0ssb3U9QXBwbGljYXRpb25zLE9VPVRlY2huaXF1ZSxkYz1yZWNvdXYiLCJhdWQiO"
					+ "iJINHNJQUFBQUFBQUFBQXNOTWpRMHR3cjJDelBTRFFqeWQ3RnlkdzBPOGZUM2kzZDA"
					+ "4ZlgwOHd3T0NYSU04UXh6alhkeERZNTM5dmNOQ0FIU2ZrWUtvVUdtSnNpNkhJT0RnV"
					+ "29kXC9aeGQ0OTM4XC9aeEJKdmk1K3ZpNFF0VWFrV3dEQU15UjdcLytYQUFBQSIsIml"
					+ "zcyI6ImU1ZWJhN2I3ZDA2ZjU2ZDk2MDYxYzRhODU4MDk5ODYxQGNuPVVTUl9SRUFEX"
					+ "05BVF9BUFBfUFJJU01FLVBTUyxvdT1QUklTTUUtUFNTLG91PUFwcGxpY2F0aW9ucyx"
					+ "vdT1UZWNobmlxdWUsZGM9cmVjb3V2IiwiaWRfc3RvcmUiOiJINHNJQUFBQUFBQUFBS"
					+ "E4yRFRJeHNUUTFNakd3U3M2ekRRME9pZzl5ZFhTSjkzTU1pWGNNQ0lqMzlZd0ljZFg"
					+ "xOVhmMjFza3Z0VVhsT1JZVTVHUW1KNVprNXVjVjZcL2lIMm9ha0ptZmtaUmFXcHVxa"
					+ "0pOc1dwU2JubDVZcFJudVlGSHM2d29DZmY2VnpXYVNQcjZXbm4zT0FsN0Zqb0xOTFl"
					+ "xVlptSE01U05MV05oWUF0K3lncUkwQUFBQT0iLCJqdGkiOiI1ODE2NDEwZTdhNTQyY"
					+ "WIxMDQ5ZDUzOGViZjgwMjk1ZCIsImlhdCI6MTQ4MzIyNTIwMX0.FbdAACjBUdvpLin"
					+ "OD62gOJIfcrjLHBqltUY23WyhuuSdirx9Wa8tTe2SUoRHEAi7lxlvGckfeJn1QtTZh"
					+ "cogAuSirn4zSEYdXdD1OEiMUGdHv3fnwuzuSQGo7ru_uhwpvuydtlHdh1tofvMR0ci"
					+ "3ABvaD53LZOOULF__GADJvWM";
			// Appel pdp
			resp = pdpEndPoint.pdp(entry);
			response = (JSONObject) jsonParser.parse(resp.getEntity().toString());
			// Verification
			LOGGER.debug("status: " + resp.getStatus());
			Assert.assertEquals(200, resp.getStatus());
			LOGGER.debug("result: " + response.get("result"));
			Assert.assertEquals("TRUE", response.get("result"));
		} catch (ParseException e) {
			LOGGER.error("ParseException : " + e.getMessage());
			Assert.fail(e.getMessage());
		}
	}
}